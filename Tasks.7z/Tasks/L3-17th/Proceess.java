import java.util.*;
class Process{
	public static void main(String[] args){
		String s = "";
		int k=0,m=0;
		int len= 0;
		int count = 0;
		Scanner sc = new Scanner(System.in);
		s = sc.next();
		int l =0;
		int r = s.length()-1;
		while(l<r&&r>1&&l<s.length()-1){
			
			if(s.charAt(l)==s.charAt(r)){
				l++;
				r--;
				count+=2;
		
				if(count == 2){
					k = r;
				}
				if(l==r && m<2){
					
					len+=count;
				
					count =0;
					m +=1;
					l = k+2;
					r = s.length()-1;
				}
			}
			else{
				r--;
			}
			
		}
		len=len+2;
		if(m==2 && len == s.length()){
			System.out.println("Can be split into Palindrome substring");
		}
		else{
			System.out.println("Cannot be split into Palindrome substring");
		}	
	}
	
}