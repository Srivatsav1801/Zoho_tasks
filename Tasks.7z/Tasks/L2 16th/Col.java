import java.util.*;
class Col{
	public static void main(String[] args){
		int result = 0, i = 0;
		String title = "";
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the String: ");
		title = sc.next();
        while(i<title.length()){
            result *= 26;
            result += title.charAt(i) -'A'+ 1;
            i++;
        }
        System.out.println(result);
		
	}
	
}