import java.util.*;
class Wordle{
	public static void main(String[] args){
		int i,j,k=0;
		String[] hidden_words = {"WHERE","ARISE","WORLD","HELLO"};
		Random random = new Random();
		int random_no = random.nextInt(3);
		String hidden_word = hidden_words[random_no];
		
		String guess_word = "";
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your guess word");
		guess_word = sc.next();
		for(i=0;i< guess_word.length();i++){
			if(hidden_word.charAt(i)==guess_word.charAt(i)){
				System.out.print("g");
				k = 1;
			}
			else{
				for(j=0;j<guess_word.length();j++){
					if(guess_word.charAt(i) == hidden_word.charAt(j)){
						System.out.print("y");
						k=1;
						break;
					}
				}
			}
			if(k==1){
					k = 0;
				}
				else{
					System.out.print("-");
				}
		}
	}
}