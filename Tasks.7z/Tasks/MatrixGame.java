import java.util.Scanner;

public class MatrixGame {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the number of rows and columns:");
        int rows = scanner.nextInt();
        int cols = scanner.nextInt();

        System.out.println("Enter the number of atoms:");
        int numAtoms = scanner.nextInt();

        char[][] matrix = new char[rows][cols];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                matrix[i][j] = '-';
            }
        }

        // Input positions of atoms
        System.out.println("Enter the positions of atoms:");
        for (int i = 0; i < numAtoms; i++) {
            int atomRow = scanner.nextInt();
            int atomCol = scanner.nextInt();
            matrix[atomRow - 1][atomCol - 1] = 'X'; // Assuming positions are 1-indexed
        }

        System.out.println("Enter the number of rays:");
        int numRays = scanner.nextInt();

        // Input rays
        System.out.println("Enter the rays:");
        for (int i = 0; i < numRays; i++) {
            String ray = scanner.next();
            handleRay(matrix, ray);
        }

        // Print the final matrix
        System.out.println("Final Matrix:");
        printMatrix(matrix);
    }
    private static void handleRay(char[][] matrix, String ray) {
  
    char direction = ray.charAt(0);
    int index = Integer.parseInt(ray.substring(1)) - 1; // Assuming rays are 1-indexed

    // Apply the rules based on the direction of the ray
    switch (direction) {
        case 'R':
            handleHorizontalRay(matrix, index);
            break;
        case 'C':
            handleVerticalRay(matrix, index);
            break;
        default:
            System.out.println("Invalid ray direction!");
    }
}

// Function to handle horizontal rays
private static void handleHorizontalRay(char[][] matrix, int rowIndex) {
    int numRows = matrix.length;
    int numCols = matrix[0].length;

    // Iterate through the row and handle each cell according to the rules
    for (int j = 0; j < numCols; j++) {
        if (matrix[rowIndex][j] == 'X') {
            matrix[rowIndex][j] = 'H'; // Rule 1: Hit
        }
    }
}

// Function to handle vertical rays
private static void handleVerticalRay(char[][] matrix, int colIndex) {
    int numRows = matrix.length;
    int numCols = matrix[0].length;

    // Iterate through the column and handle each cell according to the rules
    for (int i = 0; i < numRows; i++) {
        if (matrix[i][colIndex] == 'X') {
            matrix[i][colIndex] = 'H'; // Rule 1: Hit
        }
    }
}
     

    // Function to print the matrix
    private static void printMatrix(char[][] matrix) {
        for (char[] row : matrix) {
            for (char cell : row) {
                System.out.print(cell + " ");
            }
            System.out.println();
        }
    }
}
