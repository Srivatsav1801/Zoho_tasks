import java.util.Scanner;

public class Atm {
    private double balance;
    private String accountNumber;
    private String pin;

    public Atm(String accountNumber, String pin, double initialBalance) {
        this.accountNumber = accountNumber;
        this.pin = pin;
        this.balance = initialBalance;
    }

    public double checkBalance() {
        return balance;
    }


    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposit successful. New balance: Rs" + balance);
        } else {
            System.out.println("Invalid deposit amount.");
        }
    }


    public void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println("Withdrawal successful. New balance: Rs" + balance);
        } else {
            System.out.println("Insufficient funds or invalid withdrawal amount.");
        }
    }


    public void changePin(String newPin) {
        this.pin = newPin;
        System.out.println("PIN changed successfully.");
    }

    public static void main(String[] args) {
		
        Atm atm = new Atm("984359933", "4325", 1000);

        Scanner scanner = new Scanner(System.in);


        System.out.println("Welcome to the ATM.");
        System.out.print("Enter account number: ");
        String inputAccountNumber = scanner.nextLine();
        System.out.print("Enter PIN: ");
        String inputPin = scanner.nextLine();


        if (!atm.validateCredentials(inputAccountNumber, inputPin)) {
            System.out.println("Invalid account number or PIN. Exiting...");
            return;
        }

        System.out.println("Login successful.");

        while (true) {
            System.out.println("\nMain Menu:");
            System.out.println("1. Check Balance");
            System.out.println("2. Deposit");
            System.out.println("3. Withdraw");
            System.out.println("4. Change PIN");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("Your balance: Rs" + atm.checkBalance());
                    break;
                case 2:
                    System.out.print("Enter deposit amount: Rs");
                    double depositAmount = scanner.nextDouble();
                    atm.deposit(depositAmount);
                    break;
                case 3:
                    System.out.print("Enter withdrawal amount: Rs");
                    double withdrawAmount = scanner.nextDouble();
                    atm.withdraw(withdrawAmount);
                    break;
                case 4:
                    System.out.print("Enter new PIN: ");
                    String newPin = scanner.next();
                    atm.changePin(newPin);
                    break;
                case 5:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private boolean validateCredentials(String inputAccountNumber, String inputPin) {
        return inputAccountNumber.equals(accountNumber) && inputPin.equals(pin);
    }
}
