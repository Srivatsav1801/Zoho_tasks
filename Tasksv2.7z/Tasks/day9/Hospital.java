/* Create a simple hospital management system using inheritance in Java */
import java.util.*;
class Person {
    protected String name;
    protected int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public void display() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
    }
}

class Doctor extends Person {
    private String specialization;

    public Doctor(String name, int age, String specialization) {
        super(name, age);
        this.specialization = specialization;
    }

    public void display() {
        super.display();
        System.out.println("Specialization: " + specialization);
    }
}

class Patient extends Person {
    private int patientID;

    public Patient(String name, int age, int patientID) {
        super(name, age);
        this.patientID = patientID;
    }

    
    public void display() {
        super.display();
        System.out.println("Patient ID: " + patientID);
    }
}

public class HospitalManagementSystem {
    public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        System.out.println("Enter the doctor name,age and specialization:")
        Doctor doctor = new Doctor(sc.next(), sc.nextInt(),sc.next());
        System.out.println("Doctor Information:");
        doctor.display();

        System.out.println();
		System.out.println("Enter the Patient name,age and Patient ID:")
        Patient patient = new Patient(sc.next(), sc.nextInt(), sc.nextInt());
        System.out.println("Patient Information:");
        patient.display();
    }
}
