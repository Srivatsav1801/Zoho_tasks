class Jump{
	public static void main(String[] args){
		int i,n;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of integers:");
		n = sc.nextInt();
		int[] arr = new int[n];
		for(i = 0;i<n;i++){
			arr = sc.nextInt();
		}
		
	}
}