import java.util.*;
class Subs{
	public static void main(String[] args){
		int i,j,k=0;
		String s = "";
		String t = "";
		String longer = "";
		String shorter = "";
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the first word: ");
		s = sc.next();
		System.out.println("Enter the Second word: ");
		t = sc.next();
		if(s.length()>t.length()){
			longer = s;
			shorter = t;
		}
		else{
			shorter = s;
			longer = t;
		}
		j = 0;
		for(i= 0;i<longer.length();i++){
			if(longer.charAt(i) == shorter.charAt(j)){
				j++;
			}
			if(j == shorter.length()){
				k = 1;
				break;
			}
		}
		if(k == 1){
			System.out.println("true");
		}
		else{
			System.out.println("false");
		}
	}
}