import java.util.*;
class Missing_number{
	public static void main(String[] args){
		int i,n,j=0,temp;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the no of elements in array: ");
		n = sc.nextInt();
		int[] array = new int[n];
		for(i=0;i<n;i++){
			array[i] = sc.nextInt();
		}
		for(j=0;j<n;j++){
			for(i=0;i<n-1;i++){
				if(array[i]>array[i+1]){
					temp = array[i];
					array[i] = array[i+1];
					array[i+1] = temp;
				}
			}
		}
		j=0;
		for(i=0;i<n;i++){
			
			if(array[i]!= j){
				System.out.println(j);
				break;				
			}
			j++;
		}
	}
}