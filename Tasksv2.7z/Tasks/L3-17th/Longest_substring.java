import java.util.*;
class Longest_substring{
	public static void main(String[] args){
		int i,size_of_string,j,max=0,count=0;
		int l,r;
		String s ="";
		Scanner sc = new Scanner(System.in);
		s = sc.next();
		size_of_string = s.length();
		for(i=0;i<size_of_string;i++){
			for(j=i+1;j<size_of_string;j++){
				System.out.println(s.charAt(i)+"+"+s.charAt(j));	
				if(s.charAt(i)==s.charAt(j)){
					l=i;
					r=j;
					while(l<r){
						if(s.charAt(l)!=s.charAt(r)){
							count++;
							System.out.println(count);
						}
						else{
							count =0;
							break;
						}
						l++;
						r++;
					}
				}
				
			}
			if(count>max){
				max = count;
			}
			count=0;
		}
		System.out.println(max);
	}
}