public class LongestWordChain {
    public static int longestStrChain(String[] words) {
        for (int i = 0; i < words.length - 1; i++) {
            for (int j = 0; j < words.length - i - 1; j++) {
                if (words[j].length() > words[j + 1].length()) {
                    String temp = words[j];
                    words[j] = words[j + 1];
                    words[j + 1] = temp;
                }
            }
        }

        int[] dp = new int[words.length];
        int longestChain = 1;
=
        for (int i = 0; i < words.length; i++) {
            dp[i] = 1; 
            for (int j = 0; j < i; j++) {
                if (isPredecessor(words[j], words[i])) {
                    dp[i] = Math.max(dp[i], dp[j] + 1);
                }
            }
            longestChain = Math.max(longestChain, dp[i]);
        }

        return longestChain;
    }

    private static boolean isPredecessor(String word1, String word2) {
        if (word2.length() - word1.length() != 1) {
            return false;
        }
        int i = 0, j = 0;
        boolean foundDifference = false;
        while (i < word1.length() && j < word2.length()) {
            if (word1.charAt(i) != word2.charAt(j)) {
                if (foundDifference) {
                    return false;
                }
                foundDifference = true;
                j++;
            } else {
                i++;
                j++;
            }
        }
        return true;
    }

    public static void main(String[] args) {
        String[] words1 = {"a", "b", "ba", "bca", "bda", "bdca"};
        System.out.println(longestStrChain(words1)); // Output: 4

        String[] words2 = {"xbc", "pcxbcf", "xb", "cxbc", "pcxbc"};
        System.out.println(longestStrChain(words2)); // Output: 5

        String[] words3 = {"abcd", "dbqca"};
        System.out.println(longestStrChain(words3)); // Output: 1
    }
}
