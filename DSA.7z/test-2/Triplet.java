import java.util.*;
class Triplet{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		int i,j,k,max,product;
		
		System.out.println("Enter the length of int array");
		int n = sc.nextInt();
		int[] nums = new int[n];
		System.out.println("Enter array elements");
 		for(i = 0;i<n;i++){
			nums[i]=sc.nextInt();
		}
		nums = ascending(nums);
		max= nums[n-1]*nums[n-2]*nums[n-3];
		/* for(i=0;i<n;i++){
			for(j=i+1;j<n;j++){
				for(k=j+1;k<n;k++){					
					product = nums[i]*nums[j]*nums[k];
					if(product>max){
						max = product;
					}
				}
			}
		} */
		System.out.println(max);	
	
		
	}
	public static int[] ascending(int[] nums) {
        int i=0,j,temp;
		for(j =0;j<nums.length-1;j++){
			for(i=0;i<nums.length-1;i++){
				if(Math.abs(nums[i])>Math.abs(nums[i+1])){
					temp = nums[i];
					nums[i] = nums[i+1];
					nums[i+1] = temp;
				}
			}
		}
		return nums;
	}
}



