import java.util.*;
class Oneplus{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		int i;
		String result ="";
		
		System.out.println("Enter the length of Integer array");
		int n = sc.nextInt();
		char[] num_array = new char[n];
		
		for(i = 0;i<n;i++){
			num_array[i]=sc.next().charAt(0);
		}
		
		System.out.println(Arrays.toString(numPlusOne(num_array)));
	}
    public static char[] numPlusOne(char[] s) {
        String a ="";
		
		int i;
		for(i =0;i<s.length;i++){
			a += s[i];
		}
		int b= Integer.valueOf(a);
		b = b+1;
		a = String.valueOf(b);
		char[] result = new char[a.length()];
		for(i = 0;i<a.length();i++){
			result[i] = a.charAt(i);
		}
		return result;
	}
}



