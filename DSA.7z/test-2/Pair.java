import java.util.*;
class Pair{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		int i,j,count=0;
		
		System.out.println("Enter the length of int array");
		int n = sc.nextInt();
		int[] nums = new int[n];
		System.out.println("Enter array elements");
 		for(i = 0;i<n;i++){
			nums[i]=sc.nextInt();
		}
		System.out.println("Enter the target value:");
		int target = sc.nextInt();
		for(i=0;i<n;i++){
			for(j=i+1;j<n;j++){
				if(Math.abs(nums[i]+nums[j]) == target){
					System.out.print("("+nums[i]+","+nums[j]+"),");
					count++;
				}
			}
		}
		if(count == 0){
			System.out.println("No pair exist for "+ target);	
		}
		
	}
}



