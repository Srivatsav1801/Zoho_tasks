import java.util.*;

public class Duplicate {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int i;
		System.out.println("Enter the length of int array");
		int n = sc.nextInt();
		int[] nums = new int[n];
		System.out.println("Enter array elements");
 		for(i = 0;i<n;i++){
			nums[i]=sc.nextInt();
		}
		duplicate(nums);
	}
	public static void duplicate(int[] arr) {
        int n = arr.length;
		int count =0;

        for (int i = 0; i < n; i++) {
            boolean First_Occurrence = true;
            for (int j = 0; j < i; j++) {
                if (arr[j] == arr[i]) {
                    First_Occurrence = false;
                    break;
                }
				count++;
            }
            if (First_Occurrence) {
                System.out.print(arr[i] + ", ");
            }
        }
		for(int i = 1; i<count;i++){
			System.out.print("_, ");
		}
    }


  
}