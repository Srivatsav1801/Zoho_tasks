import java.util.*;
class Dual_sort{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		int i,e=0,o=0;
		
		System.out.println("Enter the length of String array");
		int n = sc.nextInt();
		int[] nums = new int[n];
		int[] nums2 = new int[n];
 		for(i = 0;i<n;i++){
			nums[i]=sc.nextInt();
		}
		nums = ascending(nums);
		o= n-1;
		e =0;
		
		for(i =0 ; i<n;i++){
			if(i%2 !=0){
				nums2[i]= nums[o];
				o--;
			}
			else{
				nums2[i] = nums[e];
				e++;
			}
			
		}
		for(i = 0;i<n;i++){
			System.out.print(nums2[i]+" ");
		}
		
		
	}
    public static int[] ascending(int[] nums) {
        int i=0,j,temp;
		for(j =0;j<nums.length-1;j++){
			for(i=0;i<nums.length-1;i++){
				if(nums[i]>nums[i+1]){
					temp = nums[i];
					nums[i] = nums[i+1];
					nums[i+1] = temp;
				}
			}
		}
		return nums;
	}
}



