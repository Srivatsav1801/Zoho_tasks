import java.util.*;
public class Baseball {
    public static int Record(char[] array, int[] rec) {
        int k =0,sum = 0;
        for (char ch : array) {
            if(ch == 'C'){
				if(k-1>-1){
					rec[k-1] =0;
					k = k-1;
				}
			}
			else if(ch == 'D'){
				if(k-1>-1){
					rec[k] = rec[k-1]*2;
					k++;
				}
			}
			else if(ch == '+'){
				if(k-2>-1){
					
					rec[k] = rec[k-1]+rec[k-2];
					k++;
				}
			}
			else{
				rec[k] = Character.getNumericValue(ch);
				k++;
			}
        }
        for(int i =0;i<rec.length;i++){
			sum += rec[i];
		}
		System.out.println(Arrays.toString(rec));
		return sum;
    }

    public static void main(String[] args) {
        int i,n,amount;
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter the no of elements :");
		n = sc.nextInt();
		char[] array = new char[n];
		int[] rec = new int[n];
		for(i =0 ;i<n;i++){
			rec[i] = 0;
		}
		System.out.println("Enter the array elements:");
		for(i = 0;i< n;i++){
			array[i] = sc.next().charAt(0);
		}
		System.out.println(Record(array,rec));
    }
}
