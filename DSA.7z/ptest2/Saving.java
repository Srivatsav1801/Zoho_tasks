import java.util.*;
public class Saving {
	public static void main(String[] args){
		int n;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the no of days");
		n = sc.nextInt();
		System.out.println("Total money = "+ totalMoney(n));
	}
	
	
    public static int totalMoney(int n) {
		int i,j,k,total=0;
        int week_count = n / 7;
        int remaining_days = n % 7;
		
        
		for(i=1;i<week_count+1;i++){
			k=i;
			for(j=0;j<7;j++){
				total+=k;
				
				k++;
				
			}
		}
		if(week_count>0){
			k = week_count+1;
		}
		else{
			k = 1;
		}
        
		for(i =0;i<remaining_days;i++){
			total+=k;
			
			k++;
		}
        return total;
    }
}