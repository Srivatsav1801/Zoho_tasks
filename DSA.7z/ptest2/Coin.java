import java.util.*;
public class Coin {
    public static int change(int amount, int[] coins) {
        int[] dp = new int[amount + 1];
        dp[0] = 1;
        
        for (int coin : coins) {
            for (int i = coin; i <= amount; i++) {
                dp[i] += dp[i - coin];
				
            }
        }
        
        return dp[amount];
    }

    public static void main(String[] args) {
        int i,n,amount;
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter the target amount:");
		amount = sc.nextInt();
		System.out.println("Enter the no of coins :");
		n = sc.nextInt();
		int[] coins = new int[n];
		System.out.println("Enter the coins available:");
		for(i = 0;i< n;i++){
			coins[i] = sc.nextInt();
		}
		System.out.println(change(amount,coins));
		
    }
}
