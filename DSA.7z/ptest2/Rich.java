import java.util.*;
public class Rich {
	public static void main(String[] args){
		int n ,m,i,j;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the no of rows in grid: ");
		n = sc.nextInt();
		System.out.println("Enter the no of cols in grid: ");
		m = sc.nextInt();
		System.out.println("Enter the grid data:");
		int[][] grid = new int[n][m];
		for(i = 0;i < n; i++){
			for(j=0;j<m;j++){
				grid[i][j] = sc.nextInt();
			}
		}
		System.out.println(richest(grid));
		
	}
	
    public static int richest(int[][] account) {
		int i,j,max=0,sum=0;
		for(i=0;i<account.length;i++){
			for(j=0;j<account[0].length;j++){
				sum+=account[i][j];
			}
			if(sum>max){
				max = sum;
			}
			sum =0;
		}
        return max;
    }
}

