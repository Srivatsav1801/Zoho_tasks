import java.util.*;
import java.io.*;
class Customer{
	private int custId;
	private int accountNo;
	private String name;
	private int balance;
	private String encrypted_password;

	Customer(int custId,int accountNo,String name,int balance,String encrypted_password){
		this.custId = custId;
		this.accountNo = accountNo;
		this.name = name;
		this.balance = balance;
		this.encrypted_password = encrypted_password;
	}
	
	public void set_custId(int custId){
		this.custId = custId;
	}
	
	public void set_accountNo(int accountNo){
		this.accountNo = accountNo;
	}
	
	public void set_name(String name){
		this.name = name;
	}
	
	public void set_balance(int balance){
		this.balance = balance;
	}
	
	public void set_Encrypted_password(String Encrypted_password){
		this.encrypted_password = encrypted_password;
	}
	
	public int get_custId(){
		return this.custId;
	}
	
	public int get_accountNo(){
		return this.accountNo;
	}
	
	public String get_name(String name){
		return this.name;
	}
	
	public int get_balance(){
		return this.balance;
	}
	
	public String get_Encrypted_password(){
		return this.encrypted_password ;
	}
	
	public void deposit(int amount) {
        this.balance += amount;
		System.out.println("The amount deposited: "+amount +"\nThe Balance available: "+this.balance);
		
    }
	
    public boolean withdraw(int amount) {
        if (this.balance >= amount ) {
			if((this.balance - amount) < 1000){
				System.out.println("The amount is less than min balance");
				return false;
			}
            this.balance -= amount;
			System.out.println("The amount withdrawn: "+amount +"\nThe Balance available: "+balance);
            return true;
        }
		else{
			System.out.println("Insufficient funds!!");
		}
        return false;
    }
}

class Bank_app{
	private Map<Integer, Customer> customers;

    public Bank_app() {
        customers = new HashMap<>();
    }

	
	public boolean read_file(String filename){
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
			br.readLine();
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("\t");
                int custId = Integer.parseInt(parts[0]);
                int accountNo = Integer.parseInt(parts[1]);
                String name = parts[2];
                int balance = Integer.parseInt(parts[3]);
                String encryptedPassword = parts[4];
                customers.put(custId, new Customer(custId, accountNo, name, balance, decrypt(encryptedPassword)));
            }
			return true;
        } catch (IOException e) {
            System.out.println(e);
			return false;
        }
    }
	
	public void addCustomer() {
		
		int custId = generateCustomerId();
		int accountNo = generateAccountNumber();

		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter name: ");
		String name = scanner.next();
		System.out.print("Enter password: ");
		String password = scanner.next();
		scanner.nextLine();
		
		
		String reTypedPassword;
		do {
			System.out.print("Please re-type your password: ");
			reTypedPassword = scanner.nextLine();
			if (!password.equals(reTypedPassword)) {
				System.out.println("Passwords do not match. Please try again.");
			}
		} while (!password.equals(reTypedPassword));

		System.out.println("Your custId is: " + custId);

		int balance = 10000;

		String encryptedPassword = encrypt(password);

		Customer newCustomer = new Customer(custId, accountNo, name, balance, encryptedPassword);

		customers.put(custId, newCustomer);

		try (BufferedWriter writer = new BufferedWriter(new FileWriter("bank_db.txt", true))) {
			writer.write(custId + "\t" + accountNo + "\t" + name + "\t" + balance + "\t" + encryptedPassword + "\n");
		} catch (IOException e) {
			System.out.println(e);
		}
	}
	
	
	private String encrypt(String password) {
		StringBuilder encryptedPassword = new StringBuilder();
		for (char c : password.toCharArray()) {
			if (Character.isLetter(c)) {
				if (c == 'z') {
					encryptedPassword.append('a');
				} else if (c == 'Z') {
					encryptedPassword.append('A');
				} else {
					encryptedPassword.append((char) (c + 1));
				}
			} else if (Character.isDigit(c)) {
				if (c == '9') {
					encryptedPassword.append('0');
				} else {
					encryptedPassword.append((char) (c + 1));
				}
			} else {
				encryptedPassword.append(c);
			}
		}
		return encryptedPassword.toString();
	}
	
	
	private String decrypt(String encryptedPassword) {
		StringBuilder decryptedPassword = new StringBuilder();
		for (char c : encryptedPassword.toCharArray()) {
			if (Character.isLetter(c)) {
				if (c == 'a') {
					decryptedPassword.append('z');
				} else if (c == 'A') {
					decryptedPassword.append('Z');
				} else {
					decryptedPassword.append((char) (c - 1));
				}
			} else if (Character.isDigit(c)) {
				if (c == '0') {
					decryptedPassword.append('9');
				} else {
					decryptedPassword.append((char) (c - 1));
				}
			} else {
				decryptedPassword.append(c);
			}
		}
		return decryptedPassword.toString();
	}

	private int generateCustomerId() {
        Random rand = new Random();
        return rand.nextInt(99);
    }

    private int generateAccountNumber() {
        Random rand = new Random();
        return rand.nextInt(99999);
    }
	public Customer authCustomer(int custId, String password) {
        for (Customer customer : customers.values()) {
            if (customer.get_custId() == custId) {
                String decryptedPassword = decrypt(customer.get_Encrypted_password());
                if (password.equals(decryptedPassword)) {
					System.out.println("Logged in successfully!!");
                    return customer;
                }
				else{
				}
            }
			
        }
        return null;
    }
	
	/* public boolean deposit(int amount) {
        if (customers.containsKey(custId)) {
            customers.get(custId).deposit(amount);
            return true;
        }
        return false;
    } */

  /*   public boolean withdraw(int amount) {
        if (customers.containsKey(customer.custId)) {
            return customers.get(custId).withdraw(amount);
        }
        return false;
    } */
	
	
	public void home(Customer customer){
		Scanner scanner = new Scanner(System.in);
		char choice;
		int amount;
		System.out.println("choose among the options");
		boolean flag = false;
		System.out.println("a.ATM Withdrawal\nb.Cash Deposit\nc.Account Transfer");
		choice = scanner.next().charAt(0);
		while(!flag){
			switch(choice){
				case 'a':
					System.out.println("ATM Withdrawal");
					System.out.println("Enter the amount to withdrawn");
					amount = scanner.nextInt();
					customer.withdraw(amount);
				
				case 'b':
					System.out.println("Cash Deposit");
					System.out.println("Enter the amount to be deposited");
					amount = scanner.nextInt();
					customer.deposit(amount);
			}
		}
	}

	
	public static void main(String[] args){
		Scanner scanner = new Scanner(System.in);
		Bank_app bank = new Bank_app();
		int choice;
		bank.read_file("bank_db.txt");
		boolean flag = false;
		System.out.println("\t\t\tBanking Application\t\t\t");
		while(!flag){
			System.out.println("Choose among the following:");
			System.out.println("1.Login\n2.Add Customer\n3.Exit");
			choice = scanner.nextInt();
			switch(choice){
				case 1:
					System.out.println("Login");
					System.out.println("Enter the custId:");
					int custId = scanner.nextInt();
					System.out.println("Enter the password:");
					String password = scanner.next();
					Customer customer = bank.authCustomer(custId,password);
					if(customer != null){
						System.out.println("Logged in sucessfully");
						bank.home(customer);
					}
					else{
						System.out.println("Login falied");
					}
					break;
				
				case 2:
					System.out.println("Add customer:");
					bank.addCustomer();
					break;
					
				case 3:
					System.out.println("exiting Application");
					flag = true;
					break;
				
				default:
					System.out.println("Enter a vaild option");
			}
		}
		
	}
	
}
