import java.io.*;
import java.util.*;

// User class to store user details
class User {
    private String fullName;
    private String email;
    private String mobileNumber;
    private String hID;
    private String password;
    private double initialRCDeposit;
    private String zID;
    private double rcBalance;
    private double zCoinBalance;

    // Constructor
    public User(String fullName, String email, String mobileNumber, String hID, String password, double initialRCDeposit) {
        this.fullName = fullName;
        this.email = email;
        this.mobileNumber = mobileNumber;
        this.hID = hID;
        this.password = password;
        this.initialRCDeposit = initialRCDeposit;
        this.zID = "";
        this.rcBalance = initialRCDeposit;
        this.zCoinBalance = 0.0;
    }

    // Method to save user data to file
    public void saveToFile() {
        try (PrintWriter writer = new PrintWriter(new FileWriter("userdata.txt", true))) {
            writer.println(fullName + "," + email + "," + mobileNumber + "," + hID + "," + password + "," + initialRCDeposit + "," + zID + "," + rcBalance + "," + zCoinBalance);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Method to load user data from file
    public static Map<String, User> loadFromFile() {
        Map<String, User> users = new HashMap<>();
        try (BufferedReader reader = new BufferedReader(new FileReader("userdata.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                User user = new User(data[0], data[1], data[2], data[3], data[4], Double.parseDouble(data[5]));
                user.setzID(data[6]);
                user.rcBalance = Double.parseDouble(data[7]);
                user.zCoinBalance = Double.parseDouble(data[8]);
                users.put(user.getEmail(), user);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return users;
    }

    // Getters and setters...
    // Methods for deposit, withdraw, transfer, etc...
}

public class ZCoinExchange {
    private Map<String, User> users;
    private List<User> pendingUserRequests;
    private double rcToZCoinExchangeRate;
    private double totalCommission;
    private double totalZCoinsInUniverse;

    // Constructor
    public ZCoinExchange() {
        users = new HashMap<>();
        pendingUserRequests = new ArrayList<>();
        rcToZCoinExchangeRate = 2.0; // Initial exchange rate
        totalCommission = 0.0;
        totalZCoinsInUniverse = 0.0;
        loadUserData(); // Load existing user data from file
    }

    // Method to load existing user data from file
    private void loadUserData() {
        users = User.loadFromFile();
    }

    // Method to save user data to file
    private void saveUserData() {
        for (User user : users.values()) {
            user.saveToFile();
        }
    }

    // Other methods...
    // Signup, login, approveUserRequest, getTotalCommission, getTotalZCoinsInUniverse, etc...
    // Additional functionalities as per requirements...
    
    // Main method
    public static void main(String[] args) {
        ZCoinExchange exchange = new ZCoinExchange();
        // Test your functionalities here...
    }
}
