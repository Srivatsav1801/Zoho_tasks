import java.util.*;
public class Ball {

    public static int Arrange(int r, int b, int g, char c) {
        if (r < 0 || b < 0 || g < 0) 
			return 0; 
		
        if (r == 0 && b == 0 && g == 0) 
			return 1;
		
        int count = 0;
        if (c != 'r') 
            count += Arrange(r - 1, b, g, 'r');
        
        if (c != 'b') 
            count += Arrange(r, b - 1, g, 'b');
        
        if (c != 'g') 
            count += Arrange(r, b, g - 1, 'g');

        return count;
    }
	public static void main(String[] args) {
        int r,b,g;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter no of red balls:");
		r = sc.nextInt();
		System.out.println("Enter no of blue balls:");
		b = sc.nextInt();
		System.out.println("Enter no of green balls:");
		g = sc.nextInt();
        System.out.println("Total number of arrangements are " + Arrange(r, b, g,' '));
        
    }
}
