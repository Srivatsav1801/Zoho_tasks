import java.util.*;
public class LtoR {
    public int last(int n) {
        int step = 1;
        int start = 1;
        boolean direction = true;

        while (n > 1) {
            if (direction || n % 2 == 1) {
                start += step;
            }
            n /= 2;
            step *= 2;
            direction = !direction;
        }
        
        return start;
    }

    public static void main(String[] args) {
        LtoR lr = new LtoR();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter N value:");
		int n = sc.nextInt();
		System.out.println(lr.last(n));
    }
}
