import java.util.*;
public class Snake_and_ladder{
	public static void main(String[] args){
		Scanner scanner = new Scanner(System.in);
		String placement;
		Snake_and_ladder sl = new Snake_and_ladder();
		
		
		String[][] matrix = new String[10][10];
		int i,j,k=100;
		boolean direction = false,win = false;
		for(i = 0;i<10;i++){
			for(j=0;j<10;j++){
				if(!direction){
					matrix[i][j] = String.valueOf(k);
					k--;
				}
				else{
					matrix[i][9-j] = String.valueOf(k);
					k--;
				}
			}
			direction = !direction;
		}
		sl.place_snakes_main(matrix);
		sl.place_ladders_main(matrix);
		String ch = "A";
		String last = matrix[9][0];
		matrix[9][0] = "A";
		sl.print_mat(matrix);
		while(!win){
			if(sl.wincheck(matrix,ch)){
				System.out.println("Winner!!"+ ch);
				win = true;
				break;
			}
			int spaces = sl.roll_dies();
			System.out.println("No of spaces to be moved: "+spaces+"\n");
			last = sl.move(matrix,spaces,last,ch);
			sl.print_mat(matrix);
			scanner.nextLine();	
		}
	}
	
	public int roll_dies(){
		Random rand = new Random();
		Scanner scanner = new Scanner(System.in);
		int spaces = scanner.nextInt();
		if(spaces == 0){
			spaces = spaces + 1;
		}
		return spaces ;
	}
	
	public void print_mat(String[][] matrix){
		for(int i =0;i<10;i++){
			for(int j =0;j<10;j++){
				System.out.print(matrix[i][j]+" ");
			}
			System.out.println();
		}
	}
	
	public String move(String[][] matrix,int spaces,String last,String ch){
		Snake_and_ladder sl = new Snake_and_ladder();
		int temp;
		String t1;
		boolean direction = false;
		boolean flag = false;
		for(int i=9;i>=0;i--){
			for(int j=0;j<10;j++){
				if(matrix[i][j].equals(ch)){
					matrix[i][j] = last;					
					if(!direction){
						if(j+spaces >9){
							i-=1;
							j = 9-((j+spaces)-9)-1;
						}
						else{
							j = j+spaces;
						}
					}
					else{
						if(j-spaces <0){
							i-=1;
							temp = j;
							j = Math.abs(j-spaces+1);
							if(i<0){
								i++;
								j = temp;
							}
						}
						else{
							j = j -spaces;
						}
					}
					if(matrix[i][j].charAt(0)== 's'){
						last = matrix[i][j];
						System.out.println("Snake bite!!");
						flag = sl.checksnake(matrix,i,j,ch);
						
					}
					if(matrix[i][j].charAt(0)== 'l'){
						last = matrix[i][j];	
						System.out.println("ladder found!!");
						flag = sl.checkladder(matrix,i,j,ch);
					}
					if(flag == false){
						last = matrix[i][j];
						matrix[i][j] = ch;
					}
					return last;
				}
			}
			direction = !direction;
		}
		return "0";
	}
	
	public boolean wincheck(String[][] matrix,String ch){
		if(matrix[0][0] == ch){
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public void place_snakes_main(String[][] matrix){
		place_snakes_ladders(matrix,"s1","40","3");
		place_snakes_ladders(matrix,"s2","43","18");
		place_snakes_ladders(matrix,"s3","27","5");
		place_snakes_ladders(matrix,"s4","54","31");
		place_snakes_ladders(matrix,"s5","89","53");
		place_snakes_ladders(matrix,"s6","66","45");
		place_snakes_ladders(matrix,"s7","76","58");
		place_snakes_ladders(matrix,"s8","99","41");
		
	}
	public void place_ladders_main(String[][] matrix){
		place_snakes_ladders(matrix,"l1","25","4");
		place_snakes_ladders(matrix,"l2","46","13");
		place_snakes_ladders(matrix,"l3","49","33");
		place_snakes_ladders(matrix,"l4","69","50");
		place_snakes_ladders(matrix,"l5","63","42");
		place_snakes_ladders(matrix,"l6","81","62");
		place_snakes_ladders(matrix,"l7","92","74");
		
	}
	
	public void place_snakes_ladders(String[][] matrix,String placement,String h,String t){
		for(int i = 0;i<10;i++){
			for(int j = 0;j<10;j++){
				if(matrix[i][j].equals(h)){
					matrix[i][j] = placement;
				}
				else if(matrix[i][j].equals(t)){
					matrix[i][j] = placement;
				}
			}
		}
	}
	
	public boolean checksnake(String[][] matrix,int k,int l,String ch){
		int i,j;
		String last= "";
		String key = matrix[k][l];
		boolean direction = false;
		if(k+1%2==0){
			direction = true;
		}
		if(k+1>10){
			return false;
		}
		for(i=k+1;i<10;i++){
			if(!direction){
				j=9;
				do{
					if(matrix[i][j]== key){
						last = matrix[i][j];
						matrix[i][j] = ch;
						return true;
					}
					j--;
				}while(j>=0);
			}
			else{
				j=0;
				do{
					if(matrix[i][j]== key){
						last = matrix[i][j];
						matrix[i][j] = ch;
						return true;
					}
					j++;
				}while(j<10);
				
			}
		}
		return false;
	}
	
	public boolean checkladder(String[][] matrix,int k,int l,String ch){
		int i,j;
		String last= "";
		String key = matrix[k][l];
		boolean direction = false;
		if(k-1%2==0){
			direction = true;
		}
		if(k-1<0){
			return false;
		}
		for(i=k-1;i>=0;i--){
			if(!direction){
				j=9;
				do{
					if(matrix[i][j] == key){
						last = matrix[i][j];
						matrix[i][j] = ch;
						return true;
					}
					j--;
				}while(j>=0);
			}
			else{
				j=0;
				do{
					if(matrix[i][j]== key){
						last = matrix[i][j];
						matrix[i][j] = ch;
						return true;
					}
					j++;
				}while(j<10);
				
			}
		}
		return false;
	}
	
}