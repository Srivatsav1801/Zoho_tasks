import java.util.*;
class Min_sum{
	public static void main(String[] args){
		int i ,min = Integer.MAX_VALUE,sum=0;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Array size:");
		int n = scanner.nextInt();
		
		int[] arr1 = new int[n];
		int[] arr2 = new int[n];
		
		System.out.println("Array 1 elements:");
		for(i =0;i<n;i++){
			arr1[i] = scanner.nextInt();			
		}
		System.out.println("Array 2 elements:");
		for(i = 0;i<n;i++){
			arr2[i] = scanner.nextInt();
		}
		int j = 0;
		for(i=0;i<n;i++){
			for(j=i+1;j<n;j++){
				sum = arr1[i]+arr2[j];
				if(sum<min){
					min = sum;
				}
				sum = arr1[j]+ arr2[i];
				if(sum<min){
					min = sum;
				}
			}
		}
	
		System.out.println(min);
	}
}