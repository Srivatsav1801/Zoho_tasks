import java.util.*;
class Zero{
	public static void main(String[] args){
		int temp;
		int i,n,j;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the size of the array:");
		n = scanner.nextInt();
		int[] arr1 = new int[n];
		System.out.println("Array elements:");
		for(i =0;i<n;i++){
			arr1[i] = scanner.nextInt();			
		}
		
		for(i =0;i<n-1;i++){
			for(j= 0;j<n-1;j++){			
				if(arr1[j]== 0){
					temp = arr1[j];
					arr1[j] = arr1[j+1];
					arr1[j+1] = temp;
				}
			}
		}
		System.out.println(Arrays.toString(arr1));
	}
}