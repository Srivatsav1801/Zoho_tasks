import java.util.*;
class Combine{
	public static void main(String[] args){
		int i ;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Array size:");
		int n = scanner.nextInt();
		
		int[] arr1 = new int[n];
		int[] arr2 = new int[n];
		int[] arr3 = new int[n+n];
		
		System.out.println("Array 1 elements:");
		for(i =0;i<n;i++){
			arr1[i] = scanner.nextInt();			
		}
		System.out.println("Array 2 elements:");
		for(i = 0;i<n;i++){
			arr2[i] = scanner.nextInt();
		}
		int j = 0;
		for(i=0;i<n;i++){
			arr3[j] = arr1[i];
			j++;
			arr3[j] = arr2[i];
			j++;
			
		}
		System.out.println(Arrays.toString(arr3));
	}
}