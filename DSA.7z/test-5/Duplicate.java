import java.util.*;
class Duplicate{
	public static void main(String[] args){
		String input;
		Scanner scanner = new Scanner(System.in);
		input = scanner.next();
		int[] arr = new int[input.length()];
		for(int i =0;i<input.length();i++){
			for(int j = i+1;j<input.length();j++){
				if(input.charAt(i)== input.charAt(j)){
					arr[j]+=1;
				}
			}
		}
		for(int i=0;i<arr.length;i++){
			if(arr[i] == 0){
				System.out.print(input.charAt(i));
			}
		}
	}
}