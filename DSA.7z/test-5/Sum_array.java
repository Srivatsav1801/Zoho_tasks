import java.util.*;
class Sum_array{
	public static void main(String[] args){
		int i ,j, sum1= 0,sum2 =0,l=0,r;
		boolean flag = false;
		Scanner scanner = new Scanner(System.in);
		System.out.println("No of test cases: ");
		int t = scanner.nextInt();
		boolean[] arr1 = new boolean[t];
			for(j =0;j<t;j++){
			System.out.println("Array size:");
			int n = scanner.nextInt();
			int[] arr = new int[n];
			System.out.println("Array elements:");
			for(i =0;i<n;i++){
				arr[i] = scanner.nextInt();			
			}
			arr1[j] = check(arr);
			
			
		}
		for(i=0;i<t;i++){
			if(arr1[i]){
				System.out.println("YES");
			}
			else{
				System.out.println("NO");
			}
		}
	}
	
	public static boolean check(int[] arr){
		int sum1=0,sum2 =0,l=0,r=arr.length-1;
		do{
			sum1 += arr[l];
			if(sum1 == sum2){
				return true;
			}
			l +=1;
			sum2 += arr[r];
			if(sum1 == sum2){
				return true;
			}
			r-=1;
		}while(r>l);
		return false;
		
	}
}