import java.util.*;
public class Pairs{
	public static void main(String[] args){
		int i,n;
		List<String> list = new ArrayList<String>();
		Scanner scanner = new Scanner(System.in);
		System.out.print("n: ");
		n = scanner.nextInt();
		add_bracket(list, "", 0, 0, n);
		System.out.println(list);
		
	}
	
    public static void add_bracket(List<String> list, String str, int open, int close, int max){
        
        if(str.length() == max*2){
            list.add(str);
            return;
        }
        if(open < max)
            add_bracket(list, str+"(", open+1, close, max);
        if(close < open)
            add_bracket(list, str+")", open, close+1, max);
    }
}