import java.util.*;

public class SubstringConcatenation {
    public List<Integer> findSubstring(String s, String[] words) {
        List<Integer> result = new ArrayList<>();
        if (s == null || s.length() == 0 || words == null || words.length == 0)
            return result;

        int wordLength = words[0].length();
        int totalLength = wordLength * words.length;

        int[] wordCount = new int[words.length];
        for (int i = 0; i < words.length; i++) {
            wordCount[i] = countOccurrences(words, words[i]);
        }

        for (int i = 0; i <= s.length() - totalLength; i++) {
            int[] seen = new int[words.length];
            int j = 0;
            while (j < words.length) {
                String word = s.substring(i + j * wordLength, i + (j + 1) * wordLength);
                int index = findIndex(words, word);
                if (index == -1)
                    break;
                seen[index]++;
                if (seen[index] > wordCount[index])
                    break;
                j++;
            }
            if (j == words.length)
                result.add(i);
        }

        return result;
    }

    private int countOccurrences(String[] words, String word) {
        int count = 0;
        for (String w : words) {
            if (w.equals(word))
                count++;
        }
        return count;
    }

    private int findIndex(String[] words, String word) {
        for (int i = 0; i < words.length; i++) {
            if (words[i].equals(word))
                return i;
        }
        return -1;
    }
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        SubstringConcatenation solution = new SubstringConcatenation();
        
        System.out.println("Enter the input string: ");
        String s = scanner.nextLine();
        
        System.out.println("Enter the number of words: ");
        int n = scanner.nextInt();
        scanner.nextLine(); 
        
        String[] words = new String[n];
        System.out.println("Enter the words:");
        for (int i = 0; i < n; i++) {
            words[i] = scanner.nextLine();
        }
        
        List<Integer> indices = solution.findSubstring(s, words);
        System.out.println("Starting indices of substring(s): " + indices);
        
        scanner.close();
    }
}
