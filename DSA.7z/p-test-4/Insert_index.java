import java.util.*;
public class Insert_index{
	public static void main(String[] args){
		int i,n,target;
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter size of the int array: ");
		n = scanner.nextInt();
		int[] arr = new int[n];
		System.out.println("Enter the int array elements: ");
		for(i = 0;i<n;i++){
			arr[i] = scanner.nextInt();
		}
		System.out.println("Enter the target: ");
		target = scanner.nextInt();
		for(i = 0;i<n;i++){
			if(arr[i] >= target){
				System.out.println(i);
				break;
			}
			if(i+1==n){
				System.out.println(i+1);
				break;
			}
			
		}
	}
}