import java.util.*;
public class NQueen{

	void printSolution(char board[][],int n)
	{
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++){
				System.out.print(" "+ board[i][j]+" ");
			}
			System.out.println();
		}
		System.out.println();
		System.out.println();
	}

	boolean isSafe(char board[][], int row, int col,int n)
	{
		
		int i, j;
		for (i = 0; i < col; i++)
			if (board[row][i] == 'Q')
				return false;

		for (i = row, j = col; i >= 0 && j >= 0; i--, j--)
			if (board[i][j] == 'Q')
				return false;

		for (i = row, j = col; j >= 0 && i < n; i++, j--)
			if (board[i][j] == 'Q')
				return false;
			
		return true;
	}
	
	boolean solveNQUtil(char board[][], int col,int n)
	{
		if (col >= n){
			printSolution(board,n);
			return true;
		}
		for (int i = 0; i < n; i++) {
			if (isSafe(board, i, col,n)) {
				board[i][col] = 'Q';
				if (solveNQUtil(board, col + 1,n) == true)
					return true;
				board[i][col] = '.'; 
			}
		}
		return false;
	}
	
	boolean solveNQ(int n)
	{
		char[][] board = new char[n][n];
		
		for(int i =0;i<n;i++){
			for(int j=0;j<n;j++){
				board[i][j] = '.';
			}
		}

		if (solveNQUtil(board, 0,n) == false) {
			System.out.print("Solution does not exist");
			return false;
		}
		printSolution(board,n);
		return true;
	}

	public static void main(String args[])
	{
		Scanner scanner = new Scanner(System.in);
		NQueen Queen = new NQueen();
		System.out.print("N= ");
		int n = scanner.nextInt();
		Queen.solveNQ(n);
	}
}

