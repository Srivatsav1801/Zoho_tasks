import java.util.*;

class Patient {
    String name;
    String bloodType;
    int age;
    String healthIssue;
	int patient_id = 100;
    long arrivalTime;
    long startTime;
    long endTime;

    public Patient(String name, String bloodType, int age, String healthIssue) {
        this.name = name;
        this.bloodType = bloodType;
        this.age = age;
        this.healthIssue = healthIssue;
        this.arrivalTime = System.currentTimeMillis();
		this.patient_id = this.patient_id++;
    }
}

class Hospital {
    Queue<Patient> queue = new LinkedList<>();
    List<Patient> records = new ArrayList<>();

    void arrive(Patient p) {
        if (!records.contains(p)) {
            records.add(p);
        }
        queue.add(p);
    }

    void process() {
        while (!queue.isEmpty()) {
            Patient p = queue.poll();
			int time = 0;
            p.startTime = System.currentTimeMillis();
            time = medical_professional(time);
            time = doctor_meetup(time);
            time = pharmacy(time);
            p.endTime = System.currentTimeMillis();
            System.out.println("Sorry for the wait, " + p.name);
        }
    }
	
	int medical_professional(int time){
		time += 5;
		return time;
	}
	
	int doctor_meetup(int time){
		Random random = new Random();
		time += random.next(20);
		return time;
	}
	
	int pharmacy(int time){
		time += 5;
		return time;
	}
	
	
    int getTotalRecords() {
        return records.size();
    }

    int getQueueSize() {
        return queue.size();
    }

    void addPatientRecord(String name, String bloodType, String age, String healthIssue) {
        Patient newPatient = new Patient(name, bloodType, age, healthIssue);
        records.add(newPatient);
        queue.add(newPatient);
    }

    Patient searchPatientByName(int patient_id) {
        for (Patient p : records) {
            if (p.patient_id == patient_id) {
                return p;
            }
        }
        return null; 
    }

    void removePatient(Patient p) {
        queue.remove(p);
    }
	
    void getPatientDetails(Patient p) {
		Patient getPatientDetails(int patient_id) {
		for (Patient p : records) {
			if (p.patient_id == patient_id_genss){
					return p;
				}
			}
			return null;
		}
    }

    long calculateTotalTime(Patient p) {
        return p.endTime - p.arrivalTime;
    }
}

public class Main {
    public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
        Hospital hospital = new Hospital();
		System.out.println("Welcome to Hospital O.P.D Management System");
		System.out.println("Are you existing patient: (yes/no)");
		String decision = scanner.next().toLowerCase();
		if(decision.equals("yes")){
			System.out.println("Enter your patient id:");
			int patient_id = scanner.nextInt();
			
			
		}
		else{
			System.out.println("Enter patient name:");
			String name = scanner.next();
			System.out.println("enter patient age");
			int age = scanner.nextInt();
			System.out.println("Enter patient blood type");
			String blood = scanner.next();
			System.out.println("Enter patient healthIssue");
			String healthIssue = scanner.next();
			addPatientRecord(name, bloodType, age, healthIssue);
			
			
		}
		
    }
}
