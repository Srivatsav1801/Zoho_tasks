import java.util.*;
class RomanToInt{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string:");
		String s = sc.next();
		System.out.println(Roman(s));
	}
	public static int Roman(String s){
		int[] arr1 = {1,5,10,50,100,500,1000};
		char[] arr2 = {'I','};
	}
}



