import java.util.Scanner;

class ListNode {
    int val;
    ListNode next;
    
    ListNode(int val) {
        this.val = val;
    }
}

public class MergeSortedLinkedLists {
    public ListNode mergeTwoLists(ListNode l1, ListNode l2) {
        ListNode dummy = new ListNode(0);
        ListNode current = dummy;
        
        while (l1 != null && l2 != null) {
            if (l1.val < l2.val) {
                current.next = l1;
                l1 = l1.next;
            } else {
                current.next = l2;
                l2 = l2.next;
            }
            current = current.next;
        }
        
        if (l1 != null) {
            current.next = l1;
        }
        if (l2 != null) {
            current.next = l2;
        }
        
        return dummy.next;
    }
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Enter elements of the first sorted linked list (separated by spaces):");
        String[] input1 = scanner.nextLine().split(" ");
        ListNode l1 = createList(input1);
        
        System.out.println("Enter elements of the second sorted linked list (separated by spaces):");
        String[] input2 = scanner.nextLine().split(" ");
        ListNode l2 = createList(input2);
        
        MergeSortedLinkedLists merger = new MergeSortedLinkedLists();
        ListNode mergedList = merger.mergeTwoLists(l1, l2);
        
        System.out.println("Merged sorted linked list:");
        while (mergedList != null) {
            System.out.print(mergedList.val + " ");
            mergedList = mergedList.next;
        }
        
        scanner.close();
    }
    
    private static ListNode createList(String[] input) {
        ListNode dummy = new ListNode(0);
        ListNode current = dummy;
        
        for (String s : input) {
            int val = Integer.parseInt(s);
            current.next = new ListNode(val);
            current = current.next;
        }
        
        return dummy.next;
    }
}
