import java.util.*;
class Valid{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string:");
		String s = sc.next();
		System.out.println(valid_parenthesis(s));
		
		
	}
    public static boolean valid_parenthesis(String s) {
		int countb=0,countc=0,counts=0,extra =0;
		for(int i = 0;i<s.length();i++){
			if(s.charAt(i)== '('){
				countb++;
			}
			else if(s.charAt(i)==')'){
				if(countb>0){
					countb--;
				}
				else{
					extra ++;
				}
			}
			else if(s.charAt(i)== '{'){
				countc++;
			}
			else if(s.charAt(i)=='}'){
				if(countc>0){
					countc--;
				}
				else{
					extra ++;
				}
			}
			else if(s.charAt(i)== '['){
				counts++;
			}
			else if(s.charAt(i)==']'){
				if(counts>0){
					counts--;
				}
				else{
					extra ++;
				}
			}
		}
		if(countb == 0 && countc == 0 && counts ==0 && extra ==0){
			return true;
		}
		else{
			return false;
		}
        
    }
}



