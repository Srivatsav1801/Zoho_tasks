import java.util.Scanner;

public class Mine {
    static int n, m;
    static char[][] grid;
    static boolean[][] visited;
    static int[] dx = {-1, 0, 1, 0};
    static int[] dy = {0, 1, 0, -1};

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int t = scanner.nextInt();
        while (t-- > 0) {
			System.out.println("No of rows:");
            n = scanner.nextInt();
            m = scanner.nextInt();
            grid = new char[n][m];
            visited = new boolean[n][m];
            for (int i = 0; i < n; i++) {
				for(int j = 0;j<m;j++){
					grid[i][j] = scanner.next().charAt(0);
				}
            }
            boolean isPossible = true;
            for (int i = 0; i < n && isPossible; i++) {
                for (int j = 0; j < m && isPossible; j++) {
                    if (grid[i][j] == '.' && !visited[i][j]) {
                        isPossible = dfs(i, j);
                    }
                }
            }
            System.out.println(isPossible ? "YES" : "NO");
			for (int i = 0; i < n; i++) {
				for(int j = 0;j<m;j++){
					System.out.print(grid[i][j]+" ");
				}
				System.out.println();
            }
        }
    }

    static boolean dfs(int x, int y) {
        visited[x][y] = true;
        for (int i = 0; i < 4; i++) {
            int nx = x + dx[i], ny = y + dy[i];
            if (nx >= 0 && nx < n && ny >= 0 && ny < m && grid[nx][ny] == '.') {
                if (!visited[nx][ny]) {
                    if (!dfs(nx, ny)) {
                        return false;
                    }
                } else {
                    grid[x][y] = '#';
                }
            }
        }
        return true;
    }
}
