import java.util.Scanner;

public class Craft{

    static char[][] grid;
    static int n, m;

    static boolean isValid(int x, int y) {
        return x >= 0 && x < n && y >= 0 && y < m;
    }

    static boolean dfs(int x, int y) {
        if (!isValid(x, y) || grid[x][y] == '.') {
            return false;
        }

        grid[x][y] = '.';
        
        if (x == n - 1) {
            return true;
        }

        boolean blocked = true;
        int[] dx = {0, 1, 0, -1};
        int[] dy = {1, 0, -1, 0};

        for (int i = 0; i < 4; i++) {
            int nx = x + dx[i];
            int ny = y + dy[i];
            blocked &= dfs(nx, ny);
        }

        return blocked;
    }

    static void solveTestCase() {
        n = scanner.nextInt();
        m = scanner.nextInt();
        grid = new char[n][m];

        for (int i = 0; i < n; i++) {
            String row = scanner.next();
            for (int j = 0; j < m; j++) {
                grid[i][j] = row.charAt(j);
            }
        }

        boolean wallPossible = true;
        for (int j = 0; j < m; j++) {
            if (grid[0][j] == '#') {
                wallPossible &= dfs(0, j);
            }
        }

        if (wallPossible) {
            System.out.println("YES");
            for (char[] row : grid) {
                System.out.println(row);
            }
        } else {
            System.out.println("NO");
        }
		for(int i = 0;i<n;i++){
			for(int j =0;j<m;j++){
				System.out.print(grid[i][j]+" ");
			}
			System.out.println();
		}
		
    }

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int t = scanner.nextInt();
        for (int i = 0; i < t; i++) {
            solveTestCase();
			
        }
        scanner.close();
    }
}
