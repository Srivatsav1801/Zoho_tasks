import java.util.*;
class Long{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		int i ,count=0;
		String result ="";
		
		System.out.println("Enter the length of String array");
		int n = sc.nextInt();
		String[] strs = new String[n];
		
		for(i = 0;i<n;i++){
			strs[i]=sc.next();
		}
	
		count = longestCommonPrefix(strs);
		for(i=0;i<count;i++){
			result += strs[0].charAt(i);
		}
		System.out.println(result);
		
		
	}
    public static int longestCommonPrefix(String[] strs) {
        Arrays.sort(strs);
        String a = strs[0];
        String b = strs[strs.length-1];
        int count = 0;
        while(count < a.length() && count < b.length()){
            if(a.charAt(count) != b.charAt(count)){
                break;
            } else {
                count++;
            }
        }
        return count;
    }
}



