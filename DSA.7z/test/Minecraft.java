import java.util.*;
class Minecraft{
	public static void main(String[] args){
		int n,i,j,m,l=0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the no of rows:");
		n = sc.nextInt();
		System.out.println("Enter the no of columns:");
		m = sc.nextInt();
		char[][] mat = new char[n][m];
		for(i = 0;i<n;i++){
			for(j = 0;j<m;j++){
				mat[i][j]=sc.next().charAt(0);
			}
		}
		l = dfs(mat,n-1,0);
		for(i = 0;i<n;i++){
			for(j = 0;j<m;j++){
				System.out.print(mat[i][j] + " ");
			}
			System.out.println();
		}
			
		
	}
	public static int dfs(char[][] mat,int i,int j){
		int k =1;
		if(i<0||i>=mat.length||j<0||j>=mat[0].length){
			System.out.println("i= "+i+"j= "+j);
			return 0;
		}
		else if(mat[i][j] == '#'){
			
			return 1;
		}
		System.out.println("k="+k);
		k = dfs(mat,i-1,j);
		
		if(k==0){
			System.out.println("Changed");
			mat[i][j]='#';
		}
		k = dfs(mat,i,j+1);
		if(k==0){
			mat[i][j]='#';
		}
		k = dfs(mat,i+1,j);
		if(k==0){
			mat[i][j]='#';
		}
		k = dfs(mat,i,j+1);
		if(k==0){
			mat[i][j]='#';
		}
		return 0;
	}

}