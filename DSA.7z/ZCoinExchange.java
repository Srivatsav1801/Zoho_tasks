import java.io.*;
import java.util.*;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class ZCoinExchange{
    public static void clearScreen() {  
        try {
            new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        }
		catch(Exception e){
            System.out.println(e);
        }
    }  
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;
        boolean exit = false;

        while (!exit) {
            clearScreen();
            System.out.println("----------------------------------------------------");
            System.out.println("\t\tZe\t\t");
            System.out.println("\n\nCreate a New Account Here!!! Press 1");
            System.out.println("\n\nAlready have an Account? Press 2 to Login\t");
            System.out.println("\t\t\tPress 2 to Login");
            System.out.println("\n\nPress 3 to Close the App");
            System.out.println("----------------------------------------------------");
            System.out.print("\n\n\nEnter Your Choice: ");
            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    register();
                    break;
                case 2:
					System.out.println("\t\t\t\tLOGIN\t\t\t\t\t");
					System.out.print("\n\t\t\tChoose from choice:\n1.Normal User\n2.ZE user");
					choice = scanner.nextInt();
					switch(choice){
						case 1:
							clearScreen();
							System.out.print("Normal user login");
							System.out.print("\n\t\t\tUsername: ");
							String username = scanner.nextLine();
							System.out.print("\n\t\t\tPassword: ");
							String password = scanner.nextLine();
							
							String currentUserUsername = validateNU(username,password);
							if (currentUserUsername != null) {
								homeNU(currentUserUsername);
							}	
							
							
						case 2:
							clearScreen();
							System.out.print("Normal user login");
							System.out.print("\n\t\t\tUsername: ");
							String username = scanner.nextLine();
							System.out.print("\n\t\t\tPassword: ");
							String password = scanner.nextLine();
							String currentUserUsername = validateZE(username,password);
							if (currentUserUsername != null) {
								homeZE(currentUserUsername);
							}	
							
							
						default:
							System.out.println("Invalid choice. Please try again....");
							break;
						
						
					}
                    String currentUserUsername = login();
					if (currentUserUsername != null) {
						home(currentUserUsername);
					}
                    break;
                case 3:
                    System.out.println("Closing the app...");
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }
    }
	
	private static String validateNU(String username,String password){
		if (validateCredentials(username, password)) {
			return username;
		} else {
			System.out.println("\n\t\t\tInvalid username or password or Not yet approved. Please try again.");
			System.out.println("\n\t\t\tPress Enter to return to the main menu...");
			scanner.nextLine();
			return null;
		}
	}
	private static String validateZE(String username,String password){
		if (validateCredentials_ZE(username, password)) {
			return username;
		} else {
			System.out.println("\n\t\t\tInvalid username or password. Please try again.");
			System.out.println("\n\t\t\tPress Enter to return to the main menu...");
			scanner.nextLine();
			return null;
		}
	}	
	
	
	private static boolean validateCredentials_ZE(String username, String password) {
		try (BufferedReader reader = new BufferedReader(new FileReader("userdata.txt"))) {
			String line;
			while ((line = reader.readLine()) != null) {
				String[] userData = line.split(",");
				if (userData.length >= 6 && userData[0].equals(username) && userData[4].equals(password) && userData[7].equals("ZE")) {
					return true;
				}
			}
		} catch (IOException e) {
			System.out.println("Error reading user data: " + e.getMessage());
		}
		return false;
	}
	
	private static boolean validateCredentials(String username, String password) {
		try (BufferedReader reader = new BufferedReader(new FileReader("userdata.txt"))) {
			String line;
			while ((line = reader.readLine()) != null) {
				String[] userData = line.split(",");
				if(!userData[9]){
					System.out.print("Not yet Approved!!");
					return false;
				}
				if (userData.length >= 6 && userData[1].equals(username) && userData[4].equals(password) && userData[7].equals("NU")) {
					return true;
				}
			}
		} catch (IOException e) {
			System.out.println("Error reading user data: " + e.getMessage());
		}
		return false;
	}
	
	private double rcToZCoinExchangeRate = 2.0;

    public void setRcToZCoinExchangeRate(double rate) {
        this.rcToZCoinExchangeRate = rate;
    }

    public double getRcToZCoinExchangeRate() {
        return rcToZCoinExchangeRate;
    }
	
    public double convertRCtoZCoin(double rcAmount) {
        return rcAmount / rcToZCoinExchangeRate;
    }
	
    public double convertZCointoRC(double zCoinAmount) {
        return zCoinAmount * rcToZCoinExchangeRate;
    }
	
	public double withdrawZCoinToRC(double zCoinAmount) {
        
        double commission = zCoinAmount * 0.0015; // 0.15% commission
       
        double amountAfterCommission = zCoinAmount - commission;
        
        double rcAmount = amountAfterCommission * rcToZCoinExchangeRate;
        
        if (user.withdrawRC(rcAmount)) {
            
            totalCommission += commission;
         
            return rcAmount;
        } else {
            
            return 0.0;
        }
    }

   
    public double getTotalCommission() {
        return totalCommission;
    }


    private static void register() {
        clearScreen();
        Scanner scanner = new Scanner(System.in);
        System.out.println("SIGN UP to ZCoinExchange");
        System.out.print("\nFull Name: ");
        String fullname = scanner.next();
		System.out.print("Enter your H_Id: ");
		String H_Id = scanner.next();
        String email;
        do {
            System.out.print("\nEmail: ");
            email = scanner.nextLine();
            if (!isValidEmail(email)) {
                System.out.println("Invalid email format. Please try again.");
            }
        } while (!isValidEmail(email));

        long mobileNumber;
        do {
            System.out.print("\nMobile Number: ");
            mobileNumber = scanner.nextLong();
            scanner.nextLine();
            if (!isValidMobileNumber(mobileNumber)) {
                System.out.println("Invalid mobile number format. Please try again.");
            }
        } while (!isValidMobileNumber(mobileNumber));


        String password;
        do {
            System.out.print("\nCreate a Password (at least 8 characters, It should contain AlphaNumeric with Mixed Case and limited special character(!#%?><&*)): ");
            password = scanner.nextLine();
            if (!isValidPassword(password)) {
                System.out.println("Invalid password format. Please try again.");
            }
        } while (!isValidPassword(password));

        String gender;
        do {
            System.out.print("\nGender (Male/Female/Other): ");
            gender = scanner.nextLine().toLowerCase(); 
            if (!isValidGender(gender)) {
                System.out.println("Invalid gender. Please enter Male, Female, or Other.");
            }
        } while (!isValidGender(gender));

        String dateOfBirth;
        do {
            System.out.print("\nDate of Birth (YYYY-MM-DD): ");
            dateOfBirth = scanner.nextLine();
            if (!isValidDateOfBirth(dateOfBirth)) {
                System.out.println("Invalid date of birth format. Please enter in YYYY-MM-DD format.");
            }
        } while (!isValidDateOfBirth(dateOfBirth));
		String user_type;
		int choice;
		do{
			System.out.print("Enter your choice: \n1.normal user\n.ZE user: ");
			int choice = scanner.nextInt();
			boolean approval;
			if(choice == 1){
				user_type = "NU";
				approval = false;
			}
			else if(choice == 2){
				user_type = "ZE";
				approval = true;
			}
		}while(choice>2||choice<1);

		System.out.print("Enter the intial deposit amount: ");
		double initialRcDeposit = scanner.nextDouble();		
		double zCoinAmount = convertRCtoZCoin(initialRcDeposit);
		
		sendApprovalRequest(fullname);
        saveUserData(fullname, email, mobileNumber, H_Id, password, gender, dateOfBirth,user_type,initialRcDeposit,zCoinAmount,approval);
    }

    private static boolean isValidGender(String gender) {
        return gender.equals("male") || gender.equals("female") || gender.equals("other");
    }

    private static boolean isValidDateOfBirth(String dateOfBirth) {
        String dateRegex = "^\\d{4}-\\d{2}-\\d{2}$"; 
        return dateOfBirth.matches(dateRegex);
    }
	public static boolean isValidPassword(String password) {
			String regex = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[!#%?><&*])[a-zA-Z\\d!#%?><&*]{8,}$";
			Pattern pattern = Pattern.compile(regex);
			Matcher matcher = pattern.matcher(password);
			return matcher.matches();
		}
		
	private static void saveUserData(String fullName, String email, long mobileNumber,String H_Id, String password, String gender, String dateOfBirth,String user_type,double zCoinAmount) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("userdata.txt", true))) {
            writer.write(fullname + "," + email + "," + mobileNumber + ","+ H_Id + "," + password + "," + gender + "," + dateOfBirth+","+user_type+","+initialRcDeposit+","+ zCoinAmount +","+approval+","+"-");
            writer.newLine();
        } catch (IOException e) {
            System.out.println("Error saving user data: " + e.getMessage());
        }
    }
	
	private static void sendApprovalRequest(String senderUsername) {
		String receiverUsername = "ZE";
		try (BufferedWriter writer = new BufferedWriter(new FileWriter("approvalrequest.txt", true))) {
			writer.write(senderUsername + "," + receiverUsername);
			writer.newLine();
			System.out.println("Approval request sent to " + receiverUsername);
		} catch (IOException e){
			System.out.println("Error sending Approval request: " + e.getMessage());
		}
	}
	
	
	private static void Approval_pending(String currentUserUsername) {
		Scanner scanner = new Scanner(System.in);
		clearScreen();		
		System.out.println("\t\t\t\t\t-------------------------------\t\t\t\t\t\t");
		System.out.println("\t\t\t\t\tUser Request Pending\t\t\t\t\t\t");
		System.out.println("\t\t\t\t\t-------------------------------\t\t\t\t\t\t");
		try (BufferedReader reader = new BufferedReader(new FileReader("Approvalrequests.txt"))) {
			String line;
			List<String> requests = new ArrayList<>();
			while ((line = reader.readLine()) != null) {
				String[] data = line.split(",");
				if (data[1].equals(currentUserUsername)) {
					requests.add(data[0]);
				}
			}
			if (requests.isEmpty()) {
				System.out.println("No pending Approval requests.");
				System.out.println("Press any key to continue...");
				scanner.nextLine();
				
				return;
			}
			
			for (String request : requests) {
				System.out.println("You have a Approval request from: " + request);
				System.out.print("Do you want to approve this user request? (yes/no): ");
				String choice = scanner.nextLine();
				if (choice.equalsIgnoreCase("yes")) {
					acceptApprovalRequest(currentUserUsername, request);
					
				} else if (choice.equalsIgnoreCase("no")) {
					System.out.println("Approval request from " + request + " is rejected.");
				} else {
					System.out.println("Invalid choice. Please enter 'yes' or 'no'.");
				}
			}
		} catch (IOException e) {
			System.out.println("Error reading pending approval requests: " + e.getMessage());
		}
	}

	private static void acceptApprovalRequest(String currentUserUsername, String senderUsername) {
		try {
			List<String> lines = new ArrayList<>();
			File file = new File("Approvalrequests.txt");
			BufferedReader reader = new BufferedReader(new FileReader(file));
			String line;
			while ((line = reader.readLine()) != null) {
				String[] data = line.split(",");
				if (!(data[0].equals(senderUsername) && data[1].equals(currentUserUsername))) {
					lines.add(line);
				}
			}
			reader.close();

			BufferedWriter writer = new BufferedWriter(new FileWriter(file));
			for (String newLine : lines) {
				writer.write(newLine);
				writer.newLine();
			}
			writer.close();
			
			List<String> lines2 = new ArrayList<>();
			File file2 = new File("userdata.txt");
			BufferedReader reader = new BufferedReader(new FileReader(file2));
			String line2;
			while ((line2 = reader.readLine()) != null) {
				String[] data = line2.split(",");
				if (!(data[0].equals(senderUsername))) {
					lines2.add(line2);
				}
				else{
					data[10] = String.valueOf(true);
					data[11] = String.valueOf(Random.nextInt(9999));
					line2 = Arrays.toString(data);
					lines2.add(line2);
				}
			}
			reader.close();

			BufferedWriter writer = new BufferedWriter(new FileWriter(file));
			for (String newLine : lines2) {
				writer.write(newLine);
				writer.newLine();
			}
			writer.close();
			
			
		} catch (IOException e) {
			System.out.println("Error accepting approval request: " + e.getMessage());
		}
	}
	
	private static void homeZE(String currentUserUsername){
		int choice;
		boolean exit = false;
		while (!exit) {
			clearScreen();
			Scanner scanner = new Scanner(System.in);
			System.out.println("\t\t\t\t\t\tDashboard\t\t\t\t\t\t");
			System.out.println("\t\t\t1.Show Pending Request");
			System.out.println("\t\t\t2.Search user information");
			System.out.println("\t\t\t3.Transaction");
			System.out.println("\t\t\t4.Logout");
			choice = scanner.nextInt();
			switch (choice) {
					case 1:
						acceptApprovalRequest(currentUserUsername); 
						break;
					case 2:
						search(currentUserUsername);
						break;
					case 3:
						System.out.println("Transaction");
						break;
					case 4:
						System.out.println("Closing the app...");
						exit = true;
						break;
					default:
						System.out.println("Invalid choice. Please try again.");
						break;
				}
		}
	}
	
	private static void homeNU(String currentUserUsername){
		int choice;
		boolean exit = false;
		while (!exit) {
			clearScreen();
			Scanner scanner = new Scanner(System.in);
			System.out.println("\t\t\tDashboard\t\t\t\t\t\t");
			System.out.println("\t\t\t1.Your Profile\t\t\t\t\t\t");
			System.out.println("\t\t\t2.Transaction History\t\t\t\t\t\t");
			System.out.println("\t\t\t3.Change Password\t\t\t\t\t\t");
			System.out.println("\t\t\t4.RC Transactions\t\t\t\t\t\t");
			System.out.println("\t\t\t5.ZCoin Transactions\t\t\t\t\t\t");			
			System.out.println("\t\t\t7.Logout");
			choice = scanner.nextInt();
			switch (choice) {
					case 1:
						// profile(currentUserUsername);
						break;
					case 2:
						//ChangePasword(currentUserUsername);
						break;
					case 3:
						// friend_req_pending(currentUserUsername); 
						break;
					case 4:
						// removeFriend(currentUserUsername);
						break;
					case 5:
						// search(currentUserUsername);
						break;
					case 6:
						// profile(currentUserUsername);
						break;
					case 7:
						System.out.println("Closing the app...");
						exit = true;
						break;
					default:
						System.out.println("Invalid choice. Please try again.");
						break;
				}
		}
	}
	
	private static void search(String currentUserUsername) {
		Scanner scanner = new Scanner(System.in);
		clearScreen();		
		System.out.println("\t\t\t\t\t-------------------------------\t\t\t\t\t\t");
		System.out.println("\t\t\t\t\t\tSearch People\t\t\t\t\t\t");
		System.out.println("\t\t\t\t\t-------------------------------\t\t\t\t\t\t");
		System.out.print("Enter the username you want to search for: ");
		String searchUsername = scanner.nextLine();

		try (BufferedReader reader = new BufferedReader(new FileReader("userdata.txt"))) {
			String line;
			boolean userFound = false;
			while ((line = reader.readLine()) != null) {
				String[] userData = line.split(",");
				if (userData.length >= 5 && userData[4].equals(searchUsername)) {
					userFound = true;
					System.out.println("User found:");
					System.out.println("\t\t\t\t\tFirst Name: " + userData[0]);
					System.out.println("\t\t\t\t\tLast Name: " + userData[1]);
					System.out.println("\t\t\t\t\tEmail: " + userData[2]);
					System.out.println("\t\t\t\t\tMobile Number: " + userData[3]);
					System.out.println("\t\t\t\t\tGender: " + userData[6]);
					System.out.println("\t\t\t\t\tDate of Birth: " + userData[7]);
					System.out.println("Press any key to go back...");
					scanner.nextLine();
					break;
				}
				
			}
			if (!userFound) {
				System.out.println("\t\t\t\t\t-------------------------------\t\t\t\t\t\t");
				System.out.println("\t\t\t\t\t\tUser profile not found\t\t\t\t\t\t");
				System.out.println("\t\t\t\t\t-------------------------------\t\t\t\t\t\t");
				System.out.println("Press any key to go back...");
				scanner.nextLine();
			}
		} catch (IOException e) {
			System.out.println("Error searching for user: " + e.getMessage());
		}
	}
	private static void profile(String currentUserUsername) {
		clearScreen();
		Scanner scanner = new Scanner(System.in);
		try (BufferedReader reader = new BufferedReader(new FileReader("userdata.txt"))) {
			String line;
			boolean userFound = false;
			List<String> updatedUserData = new ArrayList<>();
			while ((line = reader.readLine()) != null) {
				String[] userData = line.split(",");
				if (userData.length >= 5 && userData[4].equals(currentUserUsername)) {
					userFound = true;
					System.out.println("\t\t\t\t\t-------------------------------\t\t\t\t\t\t");
					System.out.println("\t\t\t\t\t\tUser Profile\t\t\t\t\t\t");
					System.out.println("\t\t\t\t\t-------------------------------\t\t\t\t\t\t");
					System.out.println("\t\t\t\t\tFullName: " + userData[0]);
					System.out.println("\t\t\t\t\tEmail: " + userData[1]);
					System.out.println("\t\t\t\t\tMobile Number: " + userData[2]);
					System.out.println("\t\t\t\t\tH_Id: " + userData[3]);
					System.out.println("\t\t\t\t\tGender: " + userData[5]);
					System.out.println("\t\t\t\t\tDate of Birth: " + userData[6]);
					System.out.println("\t\t\t\t\tRC currency: " + userData[8]);
					System.out.println("\t\t\t\t\tZCoin: " + userData[9]);
					System.out.println("\t\t\t\t\t-------------------------------\t\t\t\t\t\t");
				}
				if (!userFound) {
					System.out.println("\t\t\t\t\t-------------------------------\t\t\t\t\t\t");
					System.out.println("\t\t\t\t\t\tUser profile not found\t\t\t\t\t\t");
					System.out.println("\t\t\t\t\t-------------------------------\t\t\t\t\t\t");
					System.out.println("Press any key to go back...");
					scanner.nextLine();
					return;
				}
			}
		}
	}
}
		


