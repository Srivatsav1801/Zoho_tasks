import java.util.*;
public class Sliding_window {
    public static void main(String[] args) {
		int i,r,l = 0,max = 0;
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Enter the size of array:");
        int n = scanner.nextInt();
        
        int[] arr = new int[n];
		
        
        System.out.println("Enter the elements of the array:");
        for (i = 0; i < n; i++) {
			arr[i] = scanner.nextInt();
        }
        System.out.println("Enter window size: ");
		int k = scanner.nextInt();
		int[] result = new int[n-k+1];
		r = l+k-1;
		while(r<n){
			max = 0;
			for(i = l;i<=r;i++){
				if(max< arr[i]){
					max = arr[i];
				}
			}
			result[l] = max;
			System.out.println("l= "+l+"r= "+r);
			l++;
			r++;
		}
		System.out.println(Arrays.toString(result));
	}
		

    
}
