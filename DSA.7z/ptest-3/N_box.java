import java.util.*;
public class N_box {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Enter the no of boxes:");
        
		String boxes = scanner.next();
		System.out.println(Arrays.toString(minOperations(boxes)));
    }

	public static int[] minOperations(String boxes) {
        int len = boxes.length();
        int[] ans = new int[len];
        for(int i=0;i<len;i++){
            int cost = 0;
            for(int j=0;j<len;j++){
                if(boxes.charAt(j)=='1') cost += Math.abs(i-j);
            }
            ans[i] = cost;
        }
        return ans;
    }
}
