import java.util.*;

public class Dia_mat {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Enter the number of rows in the matrix:");
        int M = scanner.nextInt();
        
        System.out.println("Enter the number of columns in the matrix:");
        int N = scanner.nextInt();
        
        int[][] matrix = new int[M][N];
        
        System.out.println("Enter the elements of the matrix:");
        for (int i = 0; i < M; i++) {
            for (int j = 0; j < N; j++) {
                matrix[i][j] = scanner.nextInt();
            }
        }
        
		print_diagonally(matrix);
    }

    public static void print_diagonally(int[][] matrix) {
        if (matrix.length == 0) {
            System.out.println(0);
        }
        int M = matrix.length;
        int N = matrix[0].length;
        int row = 0, col = 0;
        for (int i = 0; i < M * N; i++) {
            System.out.print(matrix[row][col]+" ");
            if ((row + col) % 2 == 0) { 
                if (col == N - 1) {
					row++; 
				}
                else if (row == 0) {
					col++; 
				}
                else { 
					row--; 
					col++; 
				}
            } else { 
                if (row == M - 1) { 
					col++; 
					}
                else if (col == 0) {
					row++; 
					}
                else { 
				row++; col--;
				}
            }   
        }   
    }
}
