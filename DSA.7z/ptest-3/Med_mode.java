import java.util.*;

public class Med_mode {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Enter the size of array:");
        int n = scanner.nextInt();
        
        int[] arr = new int[n];
        
        System.out.println("Enter the elements of the array:");
        for (int i = 0; i < n; i++) {
			arr[i] = scanner.nextInt();
        }
        
		median_mode(arr);
    }

    public static void median_mode(int[] arr) {
		int i,j,n,temp,median,max=0,idx=0;
		n = arr.length;
        if (arr.length == 0) {
            System.out.println(0);
        }
        for(i=0;i<n;i++){
			for(j=i+1;j<n;j++){
				if(arr[i]>arr[j]){
					temp = arr[i];
					arr[i] = arr[j];
					arr[j] = temp;
				}
			}
		}
		int[] c = new int[10];
		for(i = 0;i<n;i++){
			c[arr[i]] +=1;
		}
		if(n%2 == 0){
			median = (arr[n-1/2]+arr[(n-1/2)+1])/2;
			System.out.println("Medians: "+median);
		}
		else{
			median = arr[n/2];
			System.out.println("Median: "+median);
		}
		
		for(i = 0;i<arr[n-1];i++){
			if(max < c[i]){
				max = c[i];
				idx = i;
			}
		}
		System.out.println("Mode: "+ idx);
    }
}
