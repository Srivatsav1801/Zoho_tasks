import java.util.*;
class Mat{
	
	Mat(){
		
	
	
	
}


public class Q2{
	Q2(){
		int k = 1;
		for(int i = 0;i<3;i++){
			for(int j= 0;j<3;j++){
				this.grid[i][j] = String.valueOf(k).charAt(0);
				k++;
			}
		}
	}
	}
	public static void setgrid(char h,int i,int j){
		this.grid[i][j] = h;
	}
	public static char getgrid(int i , int j){
		return this.grid[i][j];
	}
	public static char[][] getgrid(){
		return this.grid;
	}
	
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		int i,j,n=3,k=1;
		boolean win = false;
		for(i = 0;i<n;i++){
			for(j= 0;j<n;j++){
				System.out.print(getgrid(i,j)+" ");
			}
			System.out.println();
		}
		
		while(!win){
			char[][] temp = new char[3][3];
			System.out.println("X's turn;enter a slot number to place X in:");
			pos(sc.nextInt(),'X',getgrid());
			temp = getgrid();
			if(winner(temp,'X')== 3){
				System.out.println("X wins");
				win = true;
			}
			System.out.println("O's turn;enter a slot number to place O in:");
			pos(sc.nextInt(),'O',getgrid());
			temp = getgrid();
			if(winner(temp,'O')== 3){
				System.out.println("O wins");
				win = true;
			}
		}
	}
	
	public static void pos(int n,char h,char[][] grid){
		int i,j;
		for(i = 0;i<3;i++){
			for(j= 0;j<3;j++){
				if(grid[i][j] == String.valueOf(n).charAt(0)){
					setgrid(h,i,j);
					System.out.println(getgrid(i,j));
				}
			}
		}
		for(i = 0;i<3;i++){
			for(j= 0;j<3;j++){
				System.out.print(getgrid(i,j)+" ");
			}
			System.out.println();
		}
		
	}
	
	
	
    public static int winner(char[][] temp,char h) {
		int count;
        for (int i = 0 ; i < temp.length ; i++){
            for (int j = 0 ; j < temp[0].length ; j++){
                if (temp[i][j]== h){
                    count = check(temp,i,j,h);
                }
            }
        }
        return 0;
    }
    
    public static int check(char[][] temp, int i, int j,char h){
        if (i < 0 || i >= temp.length || j < 0 || j >= temp[0].length){
			return 0;
			}
        if (temp[i][j] == h){
			temp[i][j] = 'a';
            return 1;
        }
        if (temp[i][j] == 'a'){
			return 0;
			};
        
        int count = 0;
        temp[i][j] = 'a';
        
        count += check(temp, i-1, j,h);
        count += check(temp, i, j-1,h);
        count += check(temp, i, j+1,h);
        count += check(temp, i+1, j,h);
		count += check(temp, i+1, j+1,h);
		count += check(temp, i-1, j-1,h);
        
        return count;
        
    }
}