import java.util.*;

public class Q3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = 3;
        char[][] grid = new char[n][n];

        int k = 1;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                grid[i][j] = Character.forDigit(k++, 10);
            }
        }

        printGrid(grid);

        boolean win = false;
        while (!win) {
            System.out.println("X's turn; enter a slot number to place X in:");
            int xChoice = sc.nextInt();
            grid = pos(xChoice, 'X', grid);
            printGrid(grid);
            if (winner(grid, 'X')) {
                System.out.println("X wins");
                win = true;
                break;
            }
            if (isGridFull(grid)) {
                System.out.println("It's a draw!");
                break;
            }

            System.out.println("O's turn; enter a slot number to place O in:");
            int oChoice = sc.nextInt();
            grid = pos(oChoice, 'O', grid);
            printGrid(grid);
            if (winner(grid, 'O')) {
                System.out.println("O wins");
                win = true;
                break;
            }
            if (isGridFull(grid)) {
                System.out.println("It's a draw!");
                break;
            }
        }
		
		
    }

    public static char[][] pos(int n, char h, char[][] grid) {
        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[0].length; j++) {
                if (grid[i][j] == Character.forDigit(n, 10)) {
                    grid[i][j] = h;
                    return grid;
                }
            }
        }
        return grid; 
    }

    public static boolean winner(char[][] grid, char h) {
        for (int i = 0; i < 3; i++) {
            if ((grid[i][0] == h && grid[i][1] == h && grid[i][2] == h) || (grid[0][i] == h && grid[1][i] == h && grid[2][i] == h)) {
                return true;
            }
        }
        if ((grid[0][0] == h && grid[1][1] == h && grid[2][2] == h) || (grid[0][2] == h && grid[1][1] == h && grid[2][0] == h)) {
            return true;
        }
        return false;
    }

    public static boolean isGridFull(char[][] grid) {
        for (char[] row : grid) {
            for (char cell : row) {
                if (Character.isDigit(cell)) {
                    return false;
                }
            }
        }
        return true;
    }

    public static void printGrid(char[][] grid) {
        for (char[] row : grid) {
            for (char cell : row) {
                System.out.print(cell + " ");
            }
            System.out.println();
        }
    }
}
