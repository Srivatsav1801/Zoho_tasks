import java.util.*;

public class Tictactoedfs {
    private static final int N = 3;
    
    private static final char[] PLAYERS = {'X', 'O'};
  
    private char[][] board;
    
    public Tictactoedfs() {
        board = new char[N][N];
        char cellNum = '1';
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                board[i][j] = cellNum++;
            }
        }
    }
    
    private void printBoard() {
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                System.out.print(board[i][j] + " ");
            }
            System.out.println();
        }
        System.out.println();
    }
    
    private boolean checkWin(char player) {
        // Check rows and columns
        for (int i = 0; i < N; i++) {
            boolean rowWin = true;
            boolean colWin = true;
            for (int j = 0; j < N; j++) {
                if (board[i][j] != player) {
                    rowWin = false;
                }
                if (board[j][i] != player) {
                    colWin = false;
                }
            }
            if (rowWin || colWin) {
                return true;
            }
        }
        
        boolean diagonal1Win = true;
        boolean diagonal2Win = true;
        for (int i = 0; i < N; i++) {
            if (board[i][i] != player) {
                diagonal1Win = false;
            }
            if (board[i][N - i - 1] != player) {
                diagonal2Win = false;
            }
        }
        if (diagonal1Win || diagonal2Win) {
            return true;
        }
        
        return false;
    }
    
    private boolean dfs(int depth, char player) {
        if (depth == N * N) {
            return false; //no moves
        }
        
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                if (board[i][j] >= '1' && board[i][j] <= '9') {
                    board[i][j] = player;
                    if (checkWin(player)) {
                        return true;
                    }
                    if (dfs(depth + 1, PLAYERS[(depth + 1) % 2])) {
                        return true;
                    }
                    board[i][j] = (char) ('0' + (i * N + j + 1)); 
                }
            }
        }
        
        return false;
    }
    
    public void play() {
        System.out.println("Starting Tic Tac Toe...");
        Scanner scanner = new Scanner(System.in);
        
        char currentPlayer = PLAYERS[0];
        int moveCount = 0;
        
        while (true) {
            printBoard();
            System.out.println("Player " + currentPlayer + "'s turn");
            System.out.print("Enter cell number (1-9): ");
            int cell = scanner.nextInt();
            
            int row = (cell - 1) / N;
            int col = (cell - 1) % N;
            
            if (cell < 1 || cell > N * N || board[row][col] < '1' || board[row][col] > '9') {
                System.out.println("Invalid move! Try again.");
                continue;
            }
            
            board[row][col] = currentPlayer;
            moveCount++;
            
            if (checkWin(currentPlayer)) {
                printBoard();
                System.out.println("Player " + currentPlayer + " wins!");
                break;
            }
            
            if (moveCount == N * N) {
                printBoard();
                System.out.println("It's a draw!");
                break;
            }
            
            currentPlayer = PLAYERS[moveCount % 2];
        }
        
        scanner.close();
    }
    
    public static void main(String[] args) {
        Tictactoedfs game = new Tictactoedfs();
        game.play();
    }
}
