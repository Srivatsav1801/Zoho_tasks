import java.util.*;


public class Q1{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		
		int i,j,n=3,k=1;
		boolean win = false;
		char [][] grid = new char[n][n];
		for(i = 0;i<n;i++){
			for(j= 0;j<n;j++){
				grid[i][j] = String.valueOf(k).charAt(0);
				k++;
			}
		}
		for(i = 0;i<n;i++){
			for(j= 0;j<n;j++){
				System.out.print(grid[i][j]+" ");
			}
			System.out.println();
		}
		
		while(!win){
			char[][] temp = new char[3][3];
			System.out.println("X's turn;enter a slot number to place X in:");
			grid = pos(sc.nextInt(),'X',grid);
			for(i = 0;i<n;i++){
				for(j= 0;j<n;j++){
					temp[i][j] = grid[i][j];
				}
			}
			if(winner(temp,'X')== 3){
				System.out.println("X wins");
				win = true;
			}
			System.out.println("O's turn;enter a slot number to place O in:");
			grid = pos(sc.nextInt(),'O',grid);
			for(i = 0;i<n;i++){
				for(j= 0;j<n;j++){
					temp[i][j] = grid[i][j];
				}
			}
			if(winner(temp,'O')== 3){
				System.out.println("O wins");
				win = true;
			}
		}
	}
	
	public static char[][] pos(int n,char h,char[][] temp){
		int i,j;
		for(i = 0;i<3;i++){
			for(j= 0;j<3;j++){
				if(temp[i][j] == String.valueOf(n).charAt(0)){
					temp[i][j] = h;
					System.out.println(temp[i][j]);
				}
			}
		}
		for(i = 0;i<3;i++){
			for(j= 0;j<3;j++){
				System.out.print(temp[i][j]+" ");
			}
			System.out.println();
		}
		return temp;
	}
	
	
	
    public static int winner(char[][] temp,char h) {
		int count;
        for (int i = 0 ; i < temp.length ; i++){
            for (int j = 0 ; j < temp[0].length ; j++){
                if (temp[i][j]== h){
                    count = check(temp,i,j,h);
                }
            }
        }
        return 0;
    }
    
    public static int check(char[][] temp, int i, int j,char h){
        if (i < 0 || i >= temp.length || j < 0 || j >= temp[0].length){
			return 0;
			}
        if (temp[i][j] == h){
			temp[i][j] = 'a';
            return 1;
        }
        if (temp[i][j] == 'a'){
			return 0;
			};
        
        int count = 0;
        temp[i][j] = 'a';
        
        count += check(temp, i-1, j,h);
        count += check(temp, i, j-1,h);
        count += check(temp, i, j+1,h);
        count += check(temp, i+1, j,h);
		count += check(temp, i+1, j+1,h);
		count += check(temp, i-1, j-1,h);
        
        return count;
        
    }
}