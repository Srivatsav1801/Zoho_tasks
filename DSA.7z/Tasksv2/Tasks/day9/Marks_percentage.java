/* We have to calculate the percentage of marks obtained in three subjects (each out of 100) by student A and in four subjects (each out of 100) by student B. 
Create an abstract class 'Marks' with an abstract method 'getPercentage'. 
It is inherited by two other classes 'A' and 'B' each having a method with the same name which returns the percentage of the students. 
The constructor of student A takes the marks in three subjects as its parameters and the marks in four subjects as its parameters for student B.
Create an object for each of the two classes and print the percentage of marks for both the students. */

import java.util.*;

abstract class Marks {
    abstract double getPercentage();
}
class A extends Marks {
	int mark_1,mark_2,mark_3;
	
	A(int mark_1,int mark_2,int mark_3)
	{
		this.mark_1 = mark_1;
		this.mark_2 = mark_2;
		this.mark_3 = mark_3;
	}
	
    double getPercentage() {
        return ((mark_1+mark_2+mark_3)/3);
    }
}

class B extends Marks {
	int mark_1,mark_2,mark_3,mark_4;
	
	B(int mark_1,int mark_2,int mark_3,int mark_4)
	{
		this.mark_1 = mark_1;
		this.mark_2 = mark_2;
		this.mark_3 = mark_3;
		this.mark_4 = mark_4;
	}
    double getPercentage() {
        return ((mark_1+mark_2+mark_3+mark_4)/4);
    }
}

public class Marks_percentage{
    public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.println("Enter the student_A marks in 3 Subjects: ");
        A student_A = new A(input.nextInt(),input.nextInt(),input.nextInt());
		System.out.println("Enter the student_B marks in 4 Subjects: ");
        B student_B = new B(input.nextInt(),input.nextInt(),input.nextInt(),input.nextInt());

        System.out.println("The percentage of Student A: "+student_A.getPercentage());
        System.out.println("The percentage of Student B: "+student_B.getPercentage());
    }
}

