/* Write a program to create a package p1 and import it in circle class from other package p2. */

package p2;
import java.util.*;
import p1.Circle;

class Circle_area{
    public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the radius:");
        Circle circle = new Circle(sc.nextInt());
        System.out.println("The area of the circle is " + circle.getArea());
    }
}
