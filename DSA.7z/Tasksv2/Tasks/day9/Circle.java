/* Write a program to create a package p1 and import it in circle class from other package p2. */
package p1;

public class Circle{
    private double radius;

    public Circle(double radius) {
        this.radius = radius;
    }

    public double getArea() {
        return Math.PI * radius * radius;
    }
}
