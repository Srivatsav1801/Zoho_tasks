/* Implement a Queue and perform the operations Insert, Delete, Update and Traverse using LL */
import java.util.*;
class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class Queue{
    private Node front, rear;

    public Queue() {
        this.front = this.rear = null;
    }

    public void insert(int data) {
        Node newNode = new Node(data);

        if (rear == null) {
            front = rear = newNode;
            return;
        }

        rear.next = newNode;
        rear = newNode;
    }

    public void delete() {
        if (front == null)
            return;

        Node temp = front;
        front = front.next;

        if (front == null)
            rear = null;
    }

    public void update(int oldValue, int newValue) {
        Node current = front;
        while (current != null) {
            if (current.data == oldValue) {
                current.data = newValue;
                break;
            }
            current = current.next;
        }
    }
	
    public void traverse() {
        Node current = front;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}

public class Queue_LL {
    public static void main(String[] args) {
        Queue queue = new Queue();
		System.out.println("Enter no of values you want to insert in the queue:");
		Scanner sc = new Scanner(System.in);
		int n= sc.nextInt();	
		for(int i=0;i<n;i++){
			queue.insert(sc.nextInt());
		}

        System.out.println("Queue elements:");
        queue.traverse();

		System.out.println("Enter the value to be replaced and value to be replaced with:");
        queue.update(sc.nextInt(), sc.nextInt());

        System.out.println("Queue elements after update:");
        queue.traverse();

        queue.delete();

        System.out.println("Queue elements after deletion:");
        queue.traverse();
    }
}
