/* Create a BMI calculator by using packages and it should follows,

Create a package file 1 that contains a class that accepts a basic data members need for your calculator.

Create a crisp method to calculate a BMI and return the result

Create another package file and create an object for the file 1 class and pass the respective arguments then call the method */

package bmicalculator;
import bmi_cal.Bmi_cal;
import java.util.*;
public class Bmi_calculator{
	public static void main(String[] args)
	{
		System.out.println("BMI calculator");
		Scanner sc = new Scanner(System.in);
		Bmi_cal bmi = new Bmi_cal();
		System.out.println("Enter the height in centimeters: ");
		bmi.setHeight(sc.nextDouble());
		System.out.println("Enter the weight in Kg: ");
		bmi.setWeight(sc.nextDouble());
		System.out.println("Your BMI is "+bmi.bmicalculate());
	}
}