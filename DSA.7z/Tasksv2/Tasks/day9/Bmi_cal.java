/* Create a BMI calculator by using packages and it should follows,

Create a package file 1 that contains a class that accepts a basic data members need for your calculator.

Create a crisp method to calculate a BMI and return the result

Create another package file and create an object for the file 1 class and pass the respective arguments then call the method */

package bmi_cal;
public class Bmi_cal{
	private double height;
	private double weight;
	
	public void setHeight(double height)
	{
		this.height = height;
	}
	public void setWeight(double weight)
	{
		this.weight = weight;
	}
	public double bmicalculate()
	{
		return (weight / ((height*height)/100))*100;
	}
}