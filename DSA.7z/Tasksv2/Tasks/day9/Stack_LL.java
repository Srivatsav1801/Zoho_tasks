/* Implement a Stack and perform the operations Insert, Delete, Update and Traverse using Array */
import java.util.*;
class Stack {
    public static int size = 100;
    public int[] stackArray;
    public int top;

    public Stack() {
        stackArray = new int[size];
        top = -1;
    }

    public void push(int data) {
        if (top == size - 1) {
            System.out.println("Stack Overflow");
            return;
        }
        stackArray[++top] = data;
    }

    public int pop() {
        if (top == -1) {
            System.out.println("Stack Underflow");
            return -1; 
        }
        return stackArray[top--];
    }

    public void traverse() {
        System.out.println("Stack elements:");
        for (int i = top; i >= 0; i--) {
            System.out.println(stackArray[i]);
        }
    }
}

public class Stack_LL {
    public static void main(String[] args) {
        Stack stack = new Stack();
        System.out.println("Enter no of values you want to insert in the queue:");
		Scanner sc = new Scanner(System.in);
		int n= sc.nextInt();	
		
		for(int i=0;i<n;i++){
			stack.push(sc.nextInt());
		}
        
        stack.traverse();
		
        int deletedElement = stack.pop();
        System.out.println("Deleted element: " + deletedElement);

        stack.traverse();
    }
}
