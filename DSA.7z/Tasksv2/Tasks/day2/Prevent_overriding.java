/* Can we prevent overriding? if yes code it and explain it
1.private method
2.static method
3.final class
4.final method
 */
class Parent {
    
    final void finalMethod() {
        System.out.println("This method cannot be overridden");
    }
}

class Child extends Parent {
   
    // void finalMethod() {
    //     System.out.println("It will result in complie time error");
    // }
}


public class Prevent_overriding {
    public static void main(String[] args) {
        Child child = new Child();

        child.finalMethod();
    }
}
