/* Write a program for demonstrating Multiple Inheritance in java */

interface Engine {
    void start();
    void stop();
}

interface Navigation {
    void navigate();
}

class Car implements Engine, Navigation {
   
    public void start() {
        System.out.println("Engine started");
    }

    public void stop() {
        System.out.println("Engine stopped");
    }

    public void navigate() {
        System.out.println("Vehicle navigating");
    }

    void horn() {
        System.out.println("Car honking");
    }
}

public class Multi_inheritance {
    public static void main(String[] args) {
 
        Car car = new Car();
		
        car.start();
        car.stop();  
        car.horn();  
        car.navigate();
    }
}
