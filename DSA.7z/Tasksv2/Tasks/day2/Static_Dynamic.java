/* Write a program for dynamic binding and static binding in Java
static = complile time
dynamic = runtime time */

class Animal {
    static void staticMethod() {
        System.out.println("Static method in Animal class");
    }
	
    void dynamicMethod() {
        System.out.println("Dynamic method in Animal class");
    }
}

class Dog extends Animal {
    
    static void staticMethod() {
        System.out.println("Static method in Dog class");
    }

  
    void dynamicMethod() {
        System.out.println("Dynamic method in Dog class");
    }
}

public class BindingExample {
    public static void main(String[] args) {
        Animal animal = new Animal();
        Animal dog = new Dog();

        
        animal.staticMethod(); 
        dog.staticMethod();   

    
        animal.dynamicMethod(); 
        dog.dynamicMethod();    
}
