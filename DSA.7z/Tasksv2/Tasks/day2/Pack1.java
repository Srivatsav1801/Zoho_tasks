package Pack1;

public class Pack1 {
    public void display() {
        System.out.println("This is from Pack1");
    }
}
