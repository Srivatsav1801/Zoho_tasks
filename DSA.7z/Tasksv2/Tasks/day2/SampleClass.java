import Pack1.Pack1;

public class SampleClass {
    public static void main(String[] args) {
        Pack1 obj = new Pack1();
        obj.display();
    }
}
