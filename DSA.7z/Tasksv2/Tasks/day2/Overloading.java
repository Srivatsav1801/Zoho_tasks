class Calculator {
    int addIntegers(int a, int b) {
        return a + b;
    }

    int addIntegers(int a, int b, int c) {
        return a + b + c;
    }

    double addDoubles(double a, double b) {
        return a + b;
    }
}

public class Overloading {
    public static void main(String[] args) {
        Calculator calculator = new Calculator();

        int sum1 = calculator.addIntegers(5, 10);
        System.out.println("Sum of 5 and 10 is: " + sum1);

        int sum2 = calculator.addIntegers(5, 10, 15);
        System.out.println("Sum of 5, 10, and 15 is: " + sum2);

        double sum3 = calculator.addDoubles(2.5, 3.5);
        System.out.println("Sum of 2.5 and 3.5 is: " + sum3);
    }
}
