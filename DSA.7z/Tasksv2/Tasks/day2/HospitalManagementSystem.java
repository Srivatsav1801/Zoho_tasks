/* Create a simple hospital management system using inheritance in Java */

import java.util.*;

class Person {
    private String name;
    private int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public void displayInfo() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
    }
}

class Doctor extends Person {
    private String specialization;

    public Doctor(String name, int age, String specialization) {
        super(name, age);
        this.specialization = specialization;
    }

    public void displayInfo() {
        super.displayInfo();
        System.out.println("Specialization: " + specialization);
    }
}

class Patient extends Person {
    private String illness;
    private List<Appointment> appointments;

    public Patient(String name, int age, String illness) {
        super(name, age);
        this.illness = illness;
        this.appointments = new ArrayList<>();
    }

    public void displayInfo() {
        super.displayInfo();
        System.out.println("Illness: " + illness);
    }

    public void addAppointment(Appointment appointment) {
        appointments.add(appointment);
    }

    public List<Appointment> getAppointments() {
        return appointments;
    }
}

class Appointment {
    private Doctor doctor;
    private Patient patient;
    private String date;
    private double fee;

    public Appointment(Doctor doctor, Patient patient, String date, double fee) {
        this.doctor = doctor;
        this.patient = patient;
        this.date = date;
        this.fee = fee;
    }

    public void displayInfo() {
        System.out.println("Doctor: " + doctor.name);
        System.out.println("Patient: " + patient.name);
        System.out.println("Date: " + date);
        System.out.println("Fee: Rs" + fee);
    }

    public double getFee() {
        return fee;
    }
}

class Billing {
    public static double calculateTotalFee(List<Appointment> appointments) {
        double totalFee = 0;
        for (Appointment appointment : appointments) {
            totalFee += appointment.getFee();
        }
        return totalFee;
    }
}


public class HospitalManagementSystem {
    public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the doctor name, age and specialization:")
        Doctor doctor = new Doctor(sc.next(), sc.nextInt(),sc.next());
        
		System.out.println("Enter the Patient name,age and Illness:")
        Patient patient = new Patient(sc.next(), sc.nextInt(), sc.nextInt());
		
        

        Appointment appointment1 = new Appointment(doctor, patient, "2024-04-28", 100);
        Appointment appointment2 = new Appointment(doctor, patient, "2024-05-05", 100);
        patient.addAppointment(appointment1);
        patient.addAppointment(appointment2);
        System.out.println("Appointments for " + patient.name + ":");
        List<Appointment> appointments = patient.getAppointments();
        for (Appointment appointment : appointments) {
            appointment.displayInfo();
            System.out.println();
        }

        double totalFee = Billing.calculateTotalFee(appointments);
        System.out.println("Total Fee: Rs" + totalFee);
    }
}
