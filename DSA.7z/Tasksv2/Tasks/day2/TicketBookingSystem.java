
class TrainTicket {
    private String destination;
    private double price;
    private int distance; 

    public TrainTicket(String destination, double price, int distance) {
        this.destination = destination;
        this.price = price;
        this.duration = duration;
    }

    public double calculateFare() {
        return price + (0.2 * distance);
    }

    public void display() {
        System.out.println("Destination: " + destination);
        System.out.println("Price: Rs" + price);
        System.out.println("Fare: Rs" + calculateFare());
    }
}

class BusTicket {
    private String destination;
    private double price;
    private int distance; 

    public BusTicket(String destination, double price, int distance) {
        this.destination = destination;
        this.price = price;
        this.distance = distance;
    }

    public double calculateFare() {
        return price + (0.1 * distance);
    }

    public void display() {
        System.out.println("Destination: " + destination);
        System.out.println("Price: Rs" + price);
        System.out.println("Fare: Rs" + calculateFare());
    }
}


public class TicketBookingSystem {
    public static void main(String[] args) {
        TrainTicket trainTicket = new TrainTicket("Salem", 50.0,245);
        BusTicket busTicket = new BusTicket("Bangalore", 30.0, 450);

        System.out.println("Train Ticket Details:");
        trainTicket.display();
        System.out.println();

        System.out.println("Bus Ticket Details:");
        busTicket.display();
    }
}
