/* Write a program to create a directory and check whether the directory is created. */
import java.io.File;

public class New_dir{
    public static void main(String[] args) {
        String directoryPath = "new_dir";

        File directory = new File(directoryPath);

        boolean isCreated = directory.mkdir();

        if (isCreated) {
            System.out.println("Directory created successfully.");
        } else {
            System.out.println("Failed to create directory or directory already exists.");
        }
    }
}
