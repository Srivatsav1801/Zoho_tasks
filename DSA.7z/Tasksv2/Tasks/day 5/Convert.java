/* Write a program to accept a specified number of characters as input and 
converts them into uppercase characters.in java */

import java.util.Scanner;

public class Convert{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
		
        System.out.print("Enter the number of characters: ");
        int numChars = scanner.nextInt();

        if (numChars <= 0) {
            System.out.println("Number of characters should be greater than 0.");
            return;
        }

        scanner.nextLine();

        System.out.println("Enter " + numChars + " characters:");

        StringBuilder result = new StringBuilder();

        for (int i = 0; i < numChars; i++) {
            char ch = scanner.nextLine().charAt(0);
            result.append(Character.toUpperCase(ch));
        }

        System.out.println("Uppercase result: " + result.toString());

        scanner.close();
    }
}
