/* Write a program to rename the given file, after renaming the file delete the renamed file. 
(Accept the file name using command line arguments.) */
import java.io.File;

public class RenameAndDeleteFile {
    public static void main(String[] args) {
        if (args.length != 1) {
            System.out.println("Usage: java RenameAndDeleteFile <filename>");
            return;
        }

        String filename = args[0];

        String renamedFilename = filename + "_renamed";
        File file = new File(filename);
        File renamedFile = new File(renamedFilename);

        if (file.exists()) {
            if (file.renameTo(renamedFile)) {
                System.out.println("File renamed to: " + renamedFilename);
				
                if (renamedFile.delete()) {
                    System.out.println("Renamed file deleted successfully.");
                } else {
                    System.out.println("Failed to delete the renamed file.");
                }
            } else {
                System.out.println("Failed to rename the file.");
            }
        } else {
            System.out.println("File does not exist.");
        }
    }
}
