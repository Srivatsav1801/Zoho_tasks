import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class Create_file_write {
    public static void main(String[] args) {
        String filePath = "example.txt";
        String data = "Hello, this is the data to be written into the file.";

        try {
            OutputStream outputStream = new FileOutputStream(filePath);

            byte[] bytes = data.getBytes();
            outputStream.write(bytes);

            outputStream.close();

            System.out.println("Data has been written to the file successfully.");
        } catch (IOException e) {
            System.out.println("An error occurred while writing to the file: " + e.getMessage());
        }
    }
}
