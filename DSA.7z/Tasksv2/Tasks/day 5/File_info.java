/* Write a program to create a text file in the path c:\java\abc.txt and check whether that file is exists. 
Using the command exists(), isDirectory(), isFile(), getName() and getAbsolutePath() */

import java.io.*;
import java.util.*;
class File_read_write{
	public static void main(String[] args){
		try{
			File fp = new File("c:\\java\\abc.txt");
			if(fp.createNewFile()){
				System.out.println("File created: "+ fp.getName()+" File exist: "+ fp.exists()+" Directory: "+ fp.isDirectory()+" File: "+fp.isFile()+" Absolute path: "+fp.getAbsolutePath());
			}
			else{
				System.out.println("File already exist");
			}
			x	
		}
		catch(IOException e){
			System.out.println(e.toString());
		}
	}
}