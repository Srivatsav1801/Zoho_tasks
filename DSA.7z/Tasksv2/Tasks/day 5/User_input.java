/* 
Write a program to get the input from the user and store it into file. Using Reader and Writer file.
in java 
*/

import java.io.*;

public class User_Input{
    public static void main(String[] args) {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

            System.out.print("Enter text to store in the file (type 'exit' to finish): ");

            FileWriter fileWriter = new FileWriter("user_input.txt");

            BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);

            String input;
            while (!(input = reader.readLine()).equalsIgnoreCase("exit")) {
                bufferedWriter.write(input);
                bufferedWriter.newLine(); 
            }

            bufferedWriter.close();

            System.out.println("Input has been successfully written to the file 'user_input.txt'.");
        } catch (IOException e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }
}
