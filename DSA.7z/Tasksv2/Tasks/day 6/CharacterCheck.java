/* Write a Java program to check whether a string contains only a 
certain set of characters (in this case a-z, A-Z and 0-9). */

import java.util.regex.Pattern;
import java.util.regex.Matcher;

public class CharacterCheck {
    public static void main(String[] args) {
        String input = "Hello123";
        String pattern = "^[a-zA-Z0-9]*$"; 

        Pattern p = Pattern.compile(pattern);

        Matcher m = p.matcher(input);

        if (m.matches()) {
            System.out.println("String contains only a-z, A-Z, and 0-9 characters.");
        } else {
            System.out.println("String contains characters other than a-z, A-Z, and 0-9.");
        }
    }
}
