import java.util.*;

public class List_to_array {
    public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);
        
        LinkedList<String> students = new LinkedList<String>();
		
		System.out.println("Enter the number of students from Chennai:");
        int numStudents = scanner.nextInt();
        scanner.nextLine();  

        for(int i = 0; i < numStudents; i++) {
            System.out.println("Enter the name of student " + (i+1) + ":");
            String name = scanner.nextLine();
            students.add(name);
        }
        System.out.println("List of students: " + students);

        String[] array = students.toArray(new String[0]);

        System.out.println("Array of students: " + Arrays.toString(array));
    }
}
