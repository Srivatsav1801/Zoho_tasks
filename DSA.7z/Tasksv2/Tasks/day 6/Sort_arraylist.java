/* Sorts the ArrayList A in ascending order */
import java.util.ArrayList;
import java.util.Scanner;

public class Sort_arraylist {
    public static ArrayList<Integer> bubbleSort(ArrayList<Integer> A) {
        int n = A.size();
        for (int i = 0; i < n; i++) {
            for (int j = i+1; j < n; j++) {
                if (A.get(i) > A.get(j)) {
                    int temp = A.get(i);
                    A.set(i, A.get(j));
                    A.set(j, temp);
                }
            }
        }
        return A;
    }

    public static void main(String[] args) {
        ArrayList<Integer> A = new ArrayList<Integer>();
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the no of elements in the arraylist: ");
		int n = scanner.nextInt();
		
		for(int i = 0;i<n; i++){
			A.add(scanner.nextInt());
		}


        System.out.println("Unsorted ArrayList: " + A);

        A = bubbleSort(A);

        System.out.println("Sorted ArrayList: " + A);
    }
}
