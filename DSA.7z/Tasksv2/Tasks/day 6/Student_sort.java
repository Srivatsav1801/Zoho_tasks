import java.util.*;

public class Student_sort {
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);

        LinkedList<String> students = new LinkedList<String>();

        System.out.println("Enter the number of students from Chennai:");
        int numStudents = scanner.nextInt();
        scanner.nextLine();  

        for(int i = 0; i < numStudents; i++) {
            System.out.println("Enter the name of student " + (i+1) + ":");
            String name = scanner.nextLine();
            students.add(name);
        }

        Collections.sort(students, new Comparator<String>() {
            public int compare(String s1, String s2) {
                return s1.length() - s2.length();
            }
        });

        System.out.println("Students sorted by the length of their names:");
        for(String name : students) {
            System.out.println(name);
        }

        scanner.close();
    }
}
