/* 
Create a multi threaded program by creating a subclass of Thread and then creating, initializing, and staring two Thread objects from your class.
 The threads will execute concurrently and display Java is hot, aromatic, and invigorating to the console window. */

class JavaThread extends Thread {
    public void run() {
        System.out.println("Java is hot, aromatic, and invigorating");
    }
}

public class About_java {
    public static void main(String args[]) {
        JavaThread thread1 = new JavaThread();
        JavaThread thread2 = new JavaThread();

        thread1.start();
        thread2.start();
    }
}
