import java.util.Scanner;
import java.util.Vector;

public class Vector_program {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Vector<String> vector = new Vector<>();

        char choice;
        do {
            System.out.print("Enter an element to add to the vector: ");
            String element = scanner.nextLine();
            
            vector.add(element);
            System.out.print("Do you want to add more elements? (y/n): ");
            choice = scanner.next().charAt(0);
            scanner.nextLine(); 

        } while (choice == 'y' || choice == 'Y');

        System.out.println("Elements in the vector: " + vector);

        scanner.close();
    }
}