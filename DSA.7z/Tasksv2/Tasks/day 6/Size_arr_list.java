/* Prints the size of the ArrayList */
import java.util.ArrayList;
import java.util.Scanner;

public class Size_arr_list {
    public static void main(String[] args) {
        ArrayList<Integer> list = new ArrayList<Integer>();
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the no of elements in the arraylist: ");
		int n = scanner.nextInt();
		
		for(int i = 0;i<n; i++){
			list.add(scanner.nextInt());
		}

        System.out.println("Size of the ArrayList: " + list.size());
    }
}
