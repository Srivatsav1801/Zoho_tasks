import java.util.*;

public class Map_eg {
    public static void main(String[] args) {
		
        Scanner scanner = new Scanner(System.in);

        Map<String, Integer> map = new HashMap<String, Integer>();

        System.out.println("Enter three names and ages for the map:");
        for(int i = 0; i < 3; i++) {
            System.out.print("Enter name: ");
            String name = scanner.next();
            System.out.print("Enter age: ");
            int age = scanner.nextInt();
            map.put(name, age);
        }

        System.out.println("Initial Map: " + map);

        System.out.print("Enter a name to get the age: ");
        String name = scanner.next();
        if(map.containsKey(name)) {
            int age = map.get(name);
            System.out.println("Age of " + name + ": " + age);
        } else {
            System.out.println(name + " does not exist in the map.");
        }

        System.out.print("Enter a name to remove from the map: ");
        name = scanner.next();
        map.remove(name);

        System.out.print("Enter a name to check its presence in the map: ");
        name = scanner.next();
        boolean exists = map.containsKey(name);
        System.out.println("Does " + name + " exist in the map: " + exists);

        System.out.println("Updated Map: " + map);
        scanner.close();
    }
}
