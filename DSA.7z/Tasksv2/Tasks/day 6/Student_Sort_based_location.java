import java.util.*;

public class Student_Sort_based_location {
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);

        Map<String, String> students = new TreeMap<String, String>();

        System.out.println("Enter the number of students:");
        int numStudents = scanner.nextInt();
        scanner.nextLine(); 

        for(int i = 0; i < numStudents; i++) {
            System.out.println("Enter the name of student " + (i+1) + ":");
            String name = scanner.nextLine();
            System.out.println("Enter the location of student " + (i+1) + ":");
            String location = scanner.nextLine();
            students.put(location, name);
        }

        System.out.println("Students sorted by location:");
        for(Map.Entry<String, String> entry : students.entrySet()) {
            System.out.println("Name: " + entry.getValue() + ", Location: " + entry.getKey());
        }

        scanner.close();
    }
}
