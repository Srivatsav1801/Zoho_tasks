import java.util.*;

public class Arr_to_arrlist {
    public static void main(String[] args) {
		int n,i;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the no of String elements in the array");
		n = scanner.nextInt();
        String[] array = new String[n];
		System.out.println("Enter the elements:");
		for(i=0;i<n;i++){
			array[i] = scanner.next();
		}
		

        System.out.println("Array: " + Arrays.toString(array));

        List<String> list = new ArrayList<String>(Arrays.asList(array));

        System.out.println("ArrayList: " + list);
    }
}
