import java.util.*;

public class Stack_and_queue {
    public static void main(String[] args) {
		int i =0;
        
        Scanner scanner = new Scanner(System.in);

        Stack<Integer> stack = new Stack<Integer>();

        System.out.println("Enter three numbers for the stack:");
		for(i = 0;i<3;i++){
			stack.push(scanner.nextInt());
		}
		System.out.println("Stack : " + stack);

        System.out.println("Enter a number to search in the stack: ");
        int num = scanner.nextInt();
		
        int index = stack.search(num);
        System.out.println("Position of " + num + " in stack: " + index);
		System.out.println("Popping the top element in the stack: " + stack.pop());
		System.out.println("Stack after popping: " + stack);

        System.out.println("Enter a number to replace the second element in the stack:");
        stack.set(1, scanner.nextInt());

        System.out.println("Updated Stack: " + stack);

        Queue<Integer> queue = new LinkedList<Integer>();

        System.out.println("Enter three numbers for the queue:");
        queue.add(scanner.nextInt());
        queue.add(scanner.nextInt());
        queue.add(scanner.nextInt());
		
		System.out.println("Queue:\n" + queue);

        System.out.println("Enter a number to check its presence in the queue:");
        num = scanner.nextInt();
        boolean found = queue.contains(num);
        System.out.println("Is " + num + " present in queue: " + found);
		System.out.println("pop an element in queue: "+queue.poll());
		
        Integer[] arr = queue.toArray(new Integer[0]);
		
        System.out.println("Enter a number to replace the first element in the queue:");
        arr[0] = scanner.nextInt(); 
        queue = new LinkedList<Integer>(Arrays.asList(arr));

        System.out.println("Updated Queue: " + queue);

        scanner.close();
    }
}
