/* Create a multi threaded program as in the previous exercise by creating the MyThread subclass of Thread. 
But create threads as objects of the class MyClass, which is not a subclass of Thread. 
MyClass will implement the runnable interface and objects of MyClass will be executed as 
threads by passing them as arguments to the Thread constructor. */


class MyClass implements Runnable {
    public void run() {
        System.out.println("Java is hot, aromatic, and invigorating");
    }
}

public class Threading {
    public static void main(String args[]) {
        MyClass myObject1 = new MyClass();
        MyClass myObject2 = new MyClass();

        Thread thread1 = new Thread(myObject1);
        Thread thread2 = new Thread(myObject2);

        thread1.start();
        thread2.start();
    }
}
