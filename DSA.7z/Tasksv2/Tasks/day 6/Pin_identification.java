import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Pin_identification {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a PIN: ");
        String pin = scanner.nextLine();
        scanner.close();

        boolean isValid = validatePIN(pin);
        if (isValid) {
            System.out.println("Valid PIN");
        } else {
            System.out.println("Invalid PIN");
        }
    }

    public static boolean validatePIN(String pin) {
        Pattern pattern = Pattern.compile("^\\d{4}|\\d{6}|\\d{8}$");
        Matcher matcher = pattern.matcher(pin);
        return matcher.matches();
    }
}