/* Write a program to illustrate creation of threads using runnable class.
(start method start each of the newly created threads. Inside the run method there is sleep() for suspend the thread for 500 milliseconds). */

import java.io.*;
class thread_runnable implements Runnable{
	public void run(){
		for(int i = 0;i<10;i++){
			try{
				Thread.sleep(500);
				System.out.println("Hello");
			}
			catch(Exception e)
			{
			System.out.println(e.toString());
			}
		}
		
	}
	
	
	public static void main(String[] args){
		thread_runnable thd = new thread_runnable();
		Thread td = new Thread(thd);
		
		td.start();
	}
}