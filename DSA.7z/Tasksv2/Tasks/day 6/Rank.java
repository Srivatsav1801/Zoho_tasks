package main;

import university.RankCalculator;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Rank {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Get the number of students from the user
        System.out.print("Enter the number of students: ");
        int numStudents = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        // Get student names and scores from the user
        Map<String, Integer> studentScores = new HashMap<>();
        for (int i = 0; i < numStudents; i++) {
            System.out.print("Enter name of student " + (i + 1) + ": ");
            String name = scanner.nextLine();
            System.out.print("Enter score of student " + (i + 1) + ": ");
            int score = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            studentScores.put(name, score);
        }

        scanner.close();

        // Calculate ranks
        RankCalculator rankCalculator = new RankCalculator();
        Map<String, Integer> ranks = rankCalculator.calculateRanks(studentScores);

        // Print ranks
        System.out.println("Ranks:");
        for (Map.Entry<String, Integer> entry : ranks.entrySet()) {
            System.out.println(entry.getKey() + " - Rank: " + entry.getValue());
        }
    }
}