/* Make a searching, inserting,deleting and updating operation in Linked list */
import java.util.LinkedList;
import java.util.Scanner;

public class Linked_list_func {
    public static void main(String[] args) {
        LinkedList<String> linkedList = new LinkedList<>();
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter no of items to be added in linkedList:");
		int n = scanner.nextInt();
		for(int i = 0;i<n;i++){
			linkedList.add(scanner.next());
		}

        System.out.println("Elements in the LinkedList: " + linkedList);
		System.out.println("Enter the element to be searched");
        String searchItem = scanner.next();
        int index = linkedList.indexOf(searchItem);
        if (index != -1) {
            System.out.println(searchItem + " found at index: " + index);
        } else {
            System.out.println(searchItem + " not found in the LinkedList.");
        }
		System.out.println("Enter the index where the element to be inserted: ");
		int idx = scanner.nextInt();
		System.out.println("Enter the element to be added to the linkedList: ");
        String addItem = scanner.next();
        linkedList.add(idx, addItem);
        System.out.println("After inserting"+ addItem+" at index " +idx+  linkedList);
		
		System.out.println("Enter the element to be remove to the linkedList: ");
        String remove = scanner.next();
			
        linkedList.remove(remove);
        System.out.println("After deleting "+ remove+" : " + linkedList);
		
		System.out.println("Enter the index of element to be remove to the linkedList: ");
        idx = scanner.nextInt();
		
        linkedList.remove(idx);
        System.out.println("After deleting element at index "+idx+ " : " + linkedList);
		
		System.out.println("Enter the element to be updated in the linkedList: ");
        String replace = scanner.next();
		
		System.out.println("Enter the element to be repaced with : ");
        String update = scanner.next();



        int updateIndex = linkedList.indexOf(replace);
        if (updateIndex != -1) {
            linkedList.set(updateIndex, update);
            System.out.println("After updating "+ replace +" to "+ update +" : " + linkedList);
        } else {
            System.out.println( replace +" not found in the LinkedList.");
        }
    }
}