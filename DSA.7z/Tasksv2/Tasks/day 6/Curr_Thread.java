/* Write a program to get the reference to the current thread by calling currentThread() method. */
class Curr_Thread extends Thread{
	Curr_Thread(){
		this.start();
	}
	public void run(){
		try{
			for(int i = 0;i<10;i++){
				System.out.println("i="+i+"Thread Id:"+Thread.currentThread().getId());
				Thread.sleep(1000);
			}
			System.out.println(Thread.currentThread().getId());
			System.out.println(Thread.currentThread().getName());
		}catch(Exception e){
			System.out.println(e.toString());
		}
	}
	public static void main(String[] args){
		Curr_Thread two = new Curr_Thread();
		Curr_Thread three = new Curr_Thread();
	}
}