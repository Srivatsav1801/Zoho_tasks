import java.util.ArrayList;
import java.util.Scanner;

public class Space_sep {
    public static void main(String[] args) {
        ArrayList<Integer> list = new ArrayList<Integer>();

        Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the no of elements in the arraylist: ");
		int n = scanner.nextInt();
		
		for(int i = 0;i<n; i++){
			list.add(scanner.nextInt());
		}
		
        for (int element : list) {
            System.out.print(element + " ");
        }
    }
}
