import java.util.Scanner;

public class Ip_address {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter an IP address: ");
        String ipAddress = scanner.nextLine();
        scanner.close();

        String cleanedIpAddress = removeLeadingZeros(ipAddress);
        System.out.println("Cleaned IP Address: " + cleanedIpAddress);
    }

    public static String removeLeadingZeros(String ipAddress) {
        String[] parts = ipAddress.split("\\.");
        StringBuilder result = new StringBuilder();

        for (String part : parts) {       
            part = part.replaceFirst("^0+(?!$)", "");
            result.append(part).append(".");
        }

     
        result.deleteCharAt(result.length() - 1);
        return result.toString();
    }
}