import java.util.Scanner;

public class Remove_vowels {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a string: ");
        String inputString = scanner.nextLine();
        scanner.close();

        String result = removeVowels(inputString);
        System.out.println("String without vowels: " + result);
    }

    public static String removeVowels(String input) {
        return input.replaceAll("[aeiouAEIOU]", "");
    }
}