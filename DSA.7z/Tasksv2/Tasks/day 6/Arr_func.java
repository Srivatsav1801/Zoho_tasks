import java.util.ArrayList;
import java.util.Collections;

public class  Arr_func{
    public static void main(String[] args) {
        ArrayList<String> arrayList = new ArrayList<>();

        arrayList.add("Apple");
        arrayList.add("Banana");
        arrayList.add("Orange");

        System.out.println("Elements in the ArrayList: " + arrayList);

        arrayList.add(1, "Mango");
        System.out.println("After adding Mango at index 1: " + arrayList);

        arrayList.remove("Banana");
        System.out.println("After removing Banana: " + arrayList);

        arrayList.remove(0);
        System.out.println("After removing element at index 0: " + arrayList);

        System.out.println("Size of the ArrayList: " + arrayList.size());

        System.out.println("Contains Mango? " + arrayList.contains("Mango"));

        
        Collections.sort(arrayList);
        System.out.println("After sorting: " + arrayList);

       
        Collections.reverse(arrayList);
        System.out.println("After reversing: " + arrayList);

        
        arrayList.clear();
        System.out.println("After clearing: " + arrayList);
    }
}