import java.util.*;

public class JoinArrayLists {
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);

        ArrayList<String> list1 = new ArrayList<String>();
        ArrayList<String> list2 = new ArrayList<String>();

        System.out.println("Enter the number of students for the first list:");
        int numStudents1 = scanner.nextInt();
        scanner.nextLine(); 

        System.out.println("Enter the names of the students for the first list:");
        for(int i = 0; i < numStudents1; i++) {
            String name = scanner.nextLine();
            list1.add(name);
        }

        System.out.println("Enter the number of students for the second list:");
        int numStudents2 = scanner.nextInt();
        scanner.nextLine();  

        System.out.println("Enter the names of the students for the second list:");
        for(int i = 0; i < numStudents2; i++) {
            String name = scanner.nextLine();
            list2.add(name);
        }
		
        System.out.println("Initial ArrayLists:");
        System.out.println("List1: " + list1);
        System.out.println("List2: " + list2);

        list1.addAll(list2);

        System.out.println("Joined ArrayList: " + list1);

        scanner.close();
    }
}
