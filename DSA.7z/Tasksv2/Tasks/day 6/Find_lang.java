import java.util.Scanner;

public class Find_lang {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a string: ");
        String inputString = scanner.nextLine();
        scanner.close();

        String result = findLanguage(inputString);
        System.out.println("Preferred language: " + result);
    }

    public static String findLanguage(String input) {
        if (input.toLowerCase().contains("python")) {
            return "Java";
        } else {
            return "C++";
        }
    }
}