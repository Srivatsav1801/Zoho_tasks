package university;
import java.util.HashMap;
import java.util.Map;



public class RankCalculator {
    public Map<String, Integer> calculateRanks(Map<String, Integer> studentScores) {
        Map<String, Integer> ranks = new HashMap<>();
        int rank = 1;
        for (Map.Entry<String, Integer> entry : sortByValue(studentScores).entrySet()) {
            ranks.put(entry.getKey(), rank++);
        }
        return ranks;
    }

    private static Map<String, Integer> sortByValue(Map<String, Integer> map) {
        List<Map.Entry<String, Integer>> list = new LinkedList<>(map.entrySet());

        list.sort(Map.Entry.comparingByValue());

        Map<String, Integer> sortedMap = new LinkedHashMap<>();
        for (Map.Entry<String, Integer> entry : list) {
            sortedMap.put(entry.getKey(), entry.getValue());
        }

        return sortedMap;
    }
}