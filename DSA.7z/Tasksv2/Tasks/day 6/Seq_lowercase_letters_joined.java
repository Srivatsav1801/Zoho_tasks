import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Seq_lowercase_letters_joined {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter a string: ");
        String input = scanner.nextLine();

        String pattern = "\\b[a-z]+_[a-z]+\\b"; 
		
        Pattern p = Pattern.compile(pattern);

        Matcher m = p.matcher(input);

        while (m.find()) {
            System.out.println("Match: " + m.group());
        }

        scanner.close();
    }
}
