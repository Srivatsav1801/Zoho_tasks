import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class P_anyletter_ends_with_Q{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter a string: ");
        String input = scanner.nextLine();

        String pattern = "p.*q"; 

        Pattern p = Pattern.compile(pattern);

        Matcher m = p.matcher(input);

        if (m.matches()) {
            System.out.println("String matches the pattern: 'p' followed by anything, ending in 'q'.");
        } else {
            System.out.println("String does not match the pattern: 'p' followed by anything, ending in 'q'.");
        }

        scanner.close();
    }
}
