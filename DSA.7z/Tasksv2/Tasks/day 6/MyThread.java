/* Write a program to create a class MyThread in this class a constructor, call the base class constructor, using super and starts the thread. 
	The run method of the class starts after this. It can be observed that both the main thread and the created child thread are executed concurrently. */

class MyThread extends Thread {
    public MyThread() {
        super();
    }

    public void run() {
        try {
            Thread.sleep(500);
        } catch (Exception e) {
            System.out.println(e.toString());
        }
        System.out.println("Child thread is running.");
    }

    public static void main(String[] args) {
        MyThread childThread = new MyThread();
        childThread.start();
        System.out.println("Main thread is running concurrently.");
    }
}
