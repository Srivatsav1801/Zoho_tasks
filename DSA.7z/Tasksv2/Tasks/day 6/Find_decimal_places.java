import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Find_decimal_places {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a number: ");
        double number = scanner.nextDouble();
        scanner.close();

        int decimalPlaces = countDecimalPlaces(number);
        System.out.println("Number of decimal places: " + decimalPlaces);
    }

    public static int countDecimalPlaces(double number) {
        String numberStr = Double.toString(Math.abs(number));

        Pattern pattern = Pattern.compile("\\.(\\d+)");
        Matcher matcher = pattern.matcher(numberStr);

        if (matcher.find()) {
            return matcher.group(1).length();
        } else {
            return 0;
        }
    }
}