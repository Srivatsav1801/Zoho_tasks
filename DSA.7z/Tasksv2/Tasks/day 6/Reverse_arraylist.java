/* Reverses the ArrayList A */
import java.util.ArrayList;
import java.util.Scanner;

public class Reverse_arraylist {
    public static ArrayList<Integer> reverseArrayList(ArrayList<Integer> A) {
        int n = A.size();
        for (int i = 0; i < n / 2; i++) {
            int temp = A.get(i);
            A.set(i, A.get(n - i - 1));
            A.set(n - i - 1, temp);
        }
        return A;
    }

    public static void main(String[] args) {
        ArrayList<Integer> A = new ArrayList<Integer>();
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the no of elements in the arraylist: ");
		int n = scanner.nextInt();
		
		for(int i = 0;i<n; i++){
			A.add(scanner.nextInt());
		}

        System.out.println("Original ArrayList: " + A);

        A = reverseArrayList(A);

        System.out.println("Reversed ArrayList: " + A);
    }
}
