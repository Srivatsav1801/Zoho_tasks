import java.util.Scanner;

public class RatAndCheese {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
		int i,j,m,n,k;
        int t = sc.nextInt(); 
		int[] result = new int[t];
        for ( k = 0; k < t; k++) {
            n = sc.nextInt(); 
            m = sc.nextInt(); 
            int[][] maze = new int[n][m]; 

            for (i = 0; i < n; i++) {
                for (j = 0; j < m; j++) {
                    maze[i][j] = sc.nextInt();
                }
            }
			result[k] = rat_route(maze, 0, 0);
        }
		for(i=0;i<t;i++){
			System.out.println(result[i]);
		}

        sc.close();
    }
	
	public static int rat_route(int[][] maze, int i, int j){
			int n = maze.length;
			int m = maze[0].length;
            if (i == n - 1 && j == m - 1){
                return 1;
            }
			if (maze[i][j] == -1) {
                return 0;
			}
			maze[i][j] = -1;
			
			if (i + 1 < n && maze[i + 1][j] == 1 && rat_route(maze,i + 1, j) == 1) {
				return 1;
			}
            if (j + 1 < m && maze[i][j + 1] == 1 && rat_route(maze, i, j + 1) == 1) {
				return 1;
			}
			
            
            return 0;

        }
}
