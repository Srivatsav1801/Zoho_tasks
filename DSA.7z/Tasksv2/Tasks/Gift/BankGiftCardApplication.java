import java.util.*;
class Transaction {
    public static final int TOP_UP = 1;
    public static final int PURCHASE = 2;
    public static final int REDEEM_POINTS = 3;
    public static final int BLOCK = 4;

    private int type;
    private double amount;

    public Transaction(int type, double amount) {
        this.type = type;
        this.amount = amount;
    }

    // Getters
    public int getType(){
        return type;
    }

    public double getAmount() {
        return amount;
    }
}

class GiftCard {
    private int cardNumber;
    private int pin;
    private double balance;
    private boolean blocked;
    private List<Transaction> transactions;

    public GiftCard(int cardNumber, int pin) {
        this.cardNumber = cardNumber;
        this.pin = pin;
        this.balance = 0.0;
        this.blocked = false;
        this.transactions = new ArrayList<>();
    }

    public void blockCard() {
        blocked = true;
        transactions.add(new Transaction(Transaction.BLOCK, 0.0));
    }

    public boolean isBlocked() {
        return blocked;
    }

    public void topUp(double amount) {
        if (!blocked) {
            balance += amount;
            transactions.add(new Transaction(Transaction.TOP_UP, amount));
        } else {
            System.out.println("Gift Card is blocked. Cannot top up.");
        }
    }

    public boolean purchase(double amount) {
        if (!blocked) {
            if (amount > balance) {
                System.out.println("Insufficient balance");
                return false;
            }
            balance -= amount;
            transactions.add(new Transaction(Transaction.PURCHASE, amount));
            // Add reward points
            int rewardPoints = (int) (amount / 100); // 1 point per 100 rupees
            if (rewardPoints > 0) {
                System.out.println("Reward Points Earned: " + rewardPoints);
            }
            return true;
        } else {
            System.out.println("Gift Card is blocked. Cannot make a purchase.");
            return false;
        }
    }

    // Method to redeem reward points
    public void redeemPoints(int points) {
        double amountToAdd = points / 10.0;
        balance += amountToAdd;
        transactions.add(new Transaction(Transaction.REDEEM_POINTS, amountToAdd));
    }

    // Method to get transaction history
    public List<Transaction> getTransactionHistory() {
        return transactions;
    }

    // Getter for balance
    public double getBalance() {
        return balance;
    }

    // Getter for card number
    public int getCardNumber() {
        return cardNumber;
    }
}

class Customer {
    private int customerId;
    private String password;
    private double mainAccountBalance; 
    private List<GiftCard> giftCards;

    public Customer(int customerId, String password, double mainAccountBalance) {
        this.customerId = customerId;
        this.password = encryptPassword(password);
        this.mainAccountBalance = mainAccountBalance;
        this.giftCards = new ArrayList<>();
    }

    public void createGiftCard(int cardNumber, int pin) {
        giftCards.add(new GiftCard(cardNumber, pin));
    }

    public void topUpGiftCard(int cardNumber, double amount) {
        for (GiftCard giftCard : giftCards) {
            if (giftCard.getCardNumber() == cardNumber) {
                giftCard.topUp(amount);
                return;
            }
        }
        System.out.println("Gift Card not found");
    }

    public boolean topUpGiftCardFromMainAccount(int cardNumber, double amount) {
        for (GiftCard giftCard : giftCards) {
            if (giftCard.getCardNumber() == cardNumber) {
                if (mainAccountBalance >= amount) {
                    mainAccountBalance -= amount;
                    giftCard.topUp(amount);
                    return true;
                } else {
                    return false; // Insufficient main account balance
                }
            }
        }
        System.out.println("Gift Card not found");
        return false;
    }
	
    public boolean purchaseWithGiftCard(int cardNumber, double amount) {
        for (GiftCard giftCard : giftCards) {
            if (giftCard.getCardNumber() == cardNumber) {
                return giftCard.purchase(amount);
            }
        }
        System.out.println("Gift Card not found");
        return false;
    }

    public boolean purchaseFromMainAccount(double amount) {
        if (mainAccountBalance >= amount) {
            mainAccountBalance -= amount;
            return true;
        } else {
            return false; 
        }
    }
	
    public void redeemPointsForGiftCard(int cardNumber, int points) {
        for (GiftCard giftCard : giftCards) {
            if (giftCard.getCardNumber() == cardNumber) {
                giftCard.redeemPoints(points);
                return;
            }
        }
        System.out.println("Gift Card not found");
    }

    public List<Transaction> getGiftCardTransactionHistory(int cardNumber) {
        for (GiftCard giftCard : giftCards) {
            if (giftCard.getCardNumber() == cardNumber) {
                return giftCard.getTransactionHistory();
            }
        }
        System.out.println("Gift Card not found");
        return null;
    }

    public GiftCard getGiftCardByCardNumber(int cardNumber) {
        for (GiftCard giftCard : giftCards) {
            if (giftCard.getCardNumber() == cardNumber) {
                return giftCard;
            }
        }
        return null;
    }

    private String encryptPassword(String password) {
        StringBuilder encryptedPassword = new StringBuilder();
        for (char ch : password.toCharArray()) {
            if (Character.isDigit(ch)) {
                encryptedPassword.append((char) ((ch - '0' + 1) % 10 + '0'));
            } else if (Character.isLowerCase(ch)) {
                encryptedPassword.append((char) ((ch - 'a' + 1) % 26 + 'a'));
            } else if (Character.isUpperCase(ch)) {
                encryptedPassword.append((char) ((ch - 'A' + 1) % 26 + 'A'));
            } else {
                encryptedPassword.append(ch);
            }
        }
        return encryptedPassword.toString();
    }

    public int getCustomerId() {
        return customerId;
    }

    public double getMainAccountBalance() {
        return mainAccountBalance;
    }

    public boolean checkPassword(String password) {
        return encryptPassword(password).equals(this.password);
    }

    public List<GiftCard> getGiftCards() {
        return giftCards;
    }

}

public class BankGiftCardApplication {
    public static void main(String[] args) {
		int card,pin,customerId=0;
		boolean flag = false;
		Random random = new Random();
		Scanner sc = new Scanner(System.in);
		Customer customer1 = new Customer(1, "World12", 1000);
        Customer customer2 = new Customer(2, "Helo2", 2000);
        Customer customer3 = new Customer(3, "water4", 3000);
        customer1.createGiftCard(random.nextInt(99999), random.nextInt(9999));
        customer2.createGiftCard(random.nextInt(99999), random.nextInt(9999));
        Customer loggedInCustomer = null;
		System.out.println("Welcome to bank giftcard Application");
		System.out.println("Choose among the options:\n1.Account Login \n2.Purchase");
		switch(sc.nextInt()){
			case 1:
				System.out.println("Log in:");
				System.out.println("Enter ID:");
				customerId = sc.nextInt();
				System.out.println("Enter password:");
				String password = sc.next();
				
				if (customerId == customer1.getCustomerId() && customer1.checkPassword(password)) {
					loggedInCustomer = customer1;
					flag = true;
				} 
				else if (customerId == customer2.getCustomerId() && customer2.checkPassword(password)) {
					loggedInCustomer = customer2;
					flag = true;
				}
				else if (customerId == customer3.getCustomerId() && customer3.checkPassword(password)) {
					loggedInCustomer = customer3;
					flag = true;
				} 
				else {
					System.out.println("Invalid Customer ID or Password");
					flag = false;
				}

				System.out.println("Login successful!");
				System.out.println("Main Account Balance: " + loggedInCustomer.getMainAccountBalance());
				System.out.println("Gift Cards for Customer ID: " + loggedInCustomer.getCustomerId());
				for (GiftCard giftCard : loggedInCustomer.getGiftCards()) {
					System.out.println("Card Number: " + giftCard.getCardNumber() + ", Balance: " + giftCard.getBalance());
				}
				
				break;
				
			
			case 2:
				System.out.println("Purchase");
				System.out.println("Login using card Number:");
				card = sc.nextInt();
				System.out.println("Enter the pin of the card");
				pin = sc.nextInt();
				System.out.println("");
				break;
				
		}

        if(flag == true){
			System.out.println("Choose among the options");
			System.out.println("1.Create Gift card\n2.Topup\n3.Transaction history\n4.Block\n5.logout");
			switch(sc.nextInt()){
				case 1:
					System.out.println("You have choosen to Create Gift Card:");
					int card_number = random.nextInt(99999);
					loggedInCustomer.createGiftCard(card_number, random.nextInt(9999));
					break;
				case 2:
					System.out.println("You have choosen to Topup: ");
					System.out.println("Enter the card number:");
					card = sc.nextInt();
					System.out.println("Enter the amount to be topped up");
					loggedInCustomer.topUpGiftCard(card, sc.nextDouble()); 
					break;
				case 3:
					System.out.println("You have choosen to see the transactionHistory:");
					break;
					
				case 4:
					System.out.println("You have choosen to block a card:");
					System.out.println("Enter the card Number:");	
					card = sc.nextInt();
					GiftCard cardToBlock = loggedInCustomer.getGiftCardByCardNumber(card);
					if (cardToBlock != null) {
						cardToBlock.blockCard();
						System.out.println("Gift Card with card number "+ card +" is blocked.");
					}
					
					
			}
		}

        
    }
}
