/* Write a program to illustrate the size or range of various data types.*/

public class PropertyOfDatatypes{
	public static void main(String[] args){
		System.out.println("Size of Integer :"+Integer.SIZE+" Integer Range:Max value:"+Integer.MAX_VALUE+" Min value:"+Integer.MIN_VALUE+"\n");
		System.out.println("Size of Float :"+Float.SIZE+" Float Range:Max value:"+Float.MAX_VALUE+" Min value:"+Float.MIN_VALUE+"\n");
		System.out.println("Size of Character :"+Character.SIZE+" Character Range:Max value:"+(int)Character.MAX_VALUE+" Min value:"+(int)Character.MIN_VALUE+"\n");
		System.out.println("Size of Short :"+Short.SIZE+" Short Range:Max value:"+Short.MAX_VALUE+" Min value:"+Short.MIN_VALUE+"\n");
		System.out.println("Size of Long :"+Long.SIZE+" Long Range:Max value:"+Long.MAX_VALUE+" Min value:"+Long.MIN_VALUE+"\n");
		System.out.println("Size of Double :"+Double.SIZE+" Double Range:Max value:"+Double.MAX_VALUE+" Min value:"+Double.MIN_VALUE+"\n");
		System.out.println("Size of Byte :"+Byte.SIZE+" Byte Range:Max value:"+Byte.MAX_VALUE+" Min value:"+Byte.MIN_VALUE+"\n");
	}
}