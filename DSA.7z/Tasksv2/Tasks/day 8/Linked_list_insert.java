/* Write a Java program to insert the specified element at the specified position in the linked list*/
 import java.util.*;

public class Linked_list_insert {
    public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
        LinkedList<Integer> list = new LinkedList<>();
		
		System.out.println("Enter the no of element to be inserted!:");
		int n = scanner.nextInt();
		System.out.println("Enter the number elements:");
		
        for(int i = 0; i<n;i++){
			list.add(scanner.nextInt());
		}
		
        System.out.println("Original linked list:");
        System.out.println(list);
		System.out.println("Enter the location in which the number to be inserted:");
		int position = scanner.nextInt();
		
		System.out.println("Enter the value to be inserted: ");
		int data = scanner.nextInt();
		
		insertAtPosition(list, data, position);
        System.out.println("\nLinked list after insertion: ");
        System.out.println(list);
    }

    public static void insertAtPosition(LinkedList<Integer> list, int data, int position) {
        list.add(position, data);
    }
}
