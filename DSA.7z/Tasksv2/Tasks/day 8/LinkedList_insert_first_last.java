/* Write a Java program to insert elements into the linked list at the first and last position. */

import java.util.*;

public class LinkedList_insert_first_last {
    public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
        
        LinkedList<String> list = new LinkedList<>();

		System.out.println("Enter the no of element to be inserted!:");
		int n = scanner.nextInt();
		System.out.println("Enter the String elements:");
		
        for(int i = 0; i<n;i++){
			list.add(scanner.next());
		}
        System.out.println("Linked list: " + list);
		
		System.out.println("Enter the element to be inserted at first: ");

        list.addFirst(scanner.next());
		
		System.out.println("Enter the element to be inserted at last: ");

        list.addLast(scanner.next());

        System.out.println("Updated Linked list: " + list);
    }
}
