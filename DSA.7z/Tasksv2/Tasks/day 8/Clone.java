/* Write a Java program to clone an array list to another array list */

import java.util.*;

public class Clone {
    public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the no of element to be inserted!:");
		int n = scanner.nextInt();
        ArrayList<String> originalList = new ArrayList<String>();
        for(int i = 0; i<n;i++){
			originalList.add(scanner.next());
		}

        System.out.println("Original ArrayList: " + originalList);
		
		ArrayList<String> clonedList = new ArrayList<String>(originalList);


        System.out.println("Cloned ArrayList: " + clonedList);
    }
}
