import java.util.*;
class Pos_neg{
	public static void main(String[] args){
		int i,n,temp;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the size of the array: ");
		n = scanner.nextInt();
		System.out.println("Enter the array numbers: ");
		int[] arr = new int[n];
		for(i =0; i<n;i++){
			arr[i] = scanner.nextInt();
		}
		int l=n-2,r = n-1;
		while(l>0&&r>0){
			if(arr[r]<0){
				l--;
				r--;
			}
			else if(arr[l]<0){
				while(l != r){
					temp = arr[l];
					arr[l] = arr[l+1];
					arr[l+1] = temp;
					l++;
				}
				l--;
				l--;
				r--;
			}
			l--;
		}
		System.out.println(Arrays.toString(arr));
	}
}