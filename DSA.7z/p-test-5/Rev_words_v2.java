import java.util.Scanner;

public class Rev_words_v2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter the string: ");
        String S = scanner.nextLine();
        
        String reversedString = reverseWords(S);
        
        System.out.println("Output: " + reversedString);
        
        scanner.close();
    }
    
    public static String reverseWords(String str) {
        StringBuilder reversedString = new StringBuilder();
        StringBuilder word = new StringBuilder();
        
        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);
            if (c == '.') {
                reversedString.insert(0, word.toString() + ".");
                word.setLength(0);
            } else {
                word.append(c);
            }
        }
        
        reversedString.insert(0, word.toString());
        
        return reversedString.toString();
    }
}
