import java.util.*;
class Pangram{
	public static void main(String[] args){
		String s;
		int i;
		Scanner scanner = new Scanner(System.in);
		s = scanner.nextLine().toLowerCase().replaceAll("\\s", "");
		System.out.println(s);
		boolean pan = true;
		boolean[] flag = new boolean[26];
		for(i = 0;i<s.length();i++){
			if(Character.isLetter(s.charAt(i))){
				int letter = s.charAt(i)- 'a';
				flag[letter] = true;
			}
		}
		for(i = 0; i<flag.length;i++){
			if(!flag[i]){
				pan = false;
			}
		}
		if(pan){
			System.out.println("1");
		}
		else{
			System.out.println("0");
		}
	}
}