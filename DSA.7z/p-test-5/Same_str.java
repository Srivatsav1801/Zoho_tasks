import java.util.Scanner;

public class Same_str {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter string a: ");
        String a = scanner.nextLine();
        
        System.out.print("Enter string b: ");
        String b = scanner.nextLine();
        
        if (isRotatedByTwoPlaces(a, b)) {
            System.out.println("1");
        } else {
            System.out.println("0");
        }
        
        scanner.close();
    }
    
    public static boolean isRotatedByTwoPlaces(String a, String b) {
        if (a.length() != b.length()) {
            return false;
        }
        
        String clockwiseRotated = rotateClockwise(a);
        
        String anticlockwiseRotated = rotateAntiClockwise(a);
        
        return clockwiseRotated.equals(b) || anticlockwiseRotated.equals(b);
    }
    
    public static String rotateClockwise(String str) {
        char[] charArray = str.toCharArray();
        int length = charArray.length;
        
        char temp1 = charArray[length - 1];
        char temp2 = charArray[length - 2];
        
        for (int i = length - 1; i >= 2; i--) {
            charArray[i] = charArray[i - 2];
        }
        
        charArray[0] = temp2;
        charArray[1] = temp1;
        
        return new String(charArray);
    }
    
    public static String rotateAntiClockwise(String str) {
        char[] charArray = str.toCharArray();
        int length = charArray.length;
        
        char temp1 = charArray[0];
        char temp2 = charArray[1];
        
        for (int i = 0; i < length - 2; i++) {
            charArray[i] = charArray[i + 2];
        }
        
        charArray[length - 2] = temp1;
        charArray[length - 1] = temp2;
        
        return new String(charArray);
    }
}
