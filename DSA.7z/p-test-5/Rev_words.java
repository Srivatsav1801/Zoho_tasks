import java.util.*;
class Rev_words{
	public static void main(String[] args){
		String s;
		String result ="";
		Scanner scanner = new Scanner(System.in);
		s = scanner.next();
		String[] arr = s.split("\\.");
		for(int i =arr.length-1;i>=0;i--){
			if(i!= 0){
				result += arr[i]+".";
			}
			else{
				result += arr[i];
			}
		}
		System.out.println(result);
	}
}