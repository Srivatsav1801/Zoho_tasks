import java.util.Scanner;

public class Pangram_v2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter the string: ");
        String S = scanner.nextLine();
        
        if (isPangram(S)) {
            System.out.println("Output: 1");
        } else {
            System.out.println("Output: 0");
        }
        
        scanner.close();
    }
    
    public static boolean isPangram(String str) {
        boolean[] present = new boolean[26];
        
        for (int i = 0; i < str.length(); i++) {
            char c = str.charAt(i);
            if (c >= 'A' && c <= 'Z') {
                c = (char)(c - 'A' + 'a');
            }
            if (c >= 'a' && c <= 'z') {
                present[c - 'a'] = true;
            }
        }
        for (boolean isPresent : present) {
            if (!isPresent) {
                return false;
            }
        }
        return true;
    }
}
