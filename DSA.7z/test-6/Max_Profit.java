import java.util.*;
class Max_Profit{
	public static void main(String[] args){
		int i,j,n,max = 0,profit;
		System.out.println("Enter the size of the array");
		Scanner scanner = new Scanner(System.in);
		n = scanner.nextInt();
		int[] arr = new int[n];
		for(i=0;i<n;i++){
			arr[i]= scanner.nextInt();
		}
		for(i = 0;i<n;i++){
			for(j = i+1;j<n;j++){
				profit = arr[j] - arr[i];
				if(profit>max){
					System.out.println(arr[j] + "-" + arr[i]);
					max = profit;
				}
			}
		}
		System.out.println("Max Profit: "+ max);
		
	}
}