import java.util.*;
class Split{
	public static void main(String[] args){
		int i,j,n,count=0;
		String p="";
		String q="";
		System.out.println("Enter the String: ");
		Scanner scanner = new Scanner(System.in);
		String s = scanner.next();
		for(i = 0;i<s.length();i++){
			p += s.charAt(i);
			q =""; 
			for(j = i+1;j<s.length();j++){
				
				q+= s.charAt(j);
			}
			count = count + Split.check(p,q);
		}
		System.out.println(count);
	}
	
	public static int check(String p,String q){
		int count1=0,count2=0;
		char arr1[] = p.toCharArray();
		char arr2[] = q.toCharArray();
		sort(arr1);
		sort(arr2);
		if(arr1.length>0 && arr2.length>0){
			
			for(int i = 0;i<arr1.length-1;i++){
				if(arr1[i] != arr1[i+1]){
					count1++;
				}
			}
			for(int i = 0;i<arr2.length-1;i++){
				if(arr2[i] != arr2[i+1]){
					count2++;
				}
			}
			
			if(count1 == count2){
				return 1;
			}
			else{
				return 0;
			}
		
		}
		return 0;
	}
	
	
	public static void sort(char arr3[]){
		char temp;
		for(int i = 0; i<arr3.length-1;i++){
			for(int j = 0;j<arr3.length-1;j++){
				if(arr3[i]>arr3[i+1]){
					temp = arr3[i];
					arr3[i]= arr3[i+1];
					arr3[i+1]= temp;
				}
			}
		}
		return;
	}
	
}