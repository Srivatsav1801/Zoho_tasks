import java.util.Scanner;

public class Square_garden {
        public static void main(String[] args) {
            Scanner sc = new Scanner(System.in);
			int max = 0;
            System.out.println("Enter the size of rows in the array");
            int rows = sc.nextInt();
            System.out.println("Enter the size of cols in the array");
            int cols = sc.nextInt();
			int area[][] = {{1,1,1,0,0,0},{0,2,0,0,0,0},{1,1,1,0,0,0},{0,0,0,2,2,2},{0,0,0,0,1,0},{0,0,0,2,2,2}};
            /* int[][] area = new int[rows][cols];
            for (int i = 0 ; i < rows ; i++){
                for (int j = 0 ; j < cols; j++){
                    area[i][j] = sc.nextInt();
                    }
                }
				*/
            for(int i = 0 ; i < 5; i++){
                for (int j = 0 ; j < 5; j++){
                    if (area[i][j] != 0) {
						int val = getApples(area,i,j);
						if(val > max){
							max = val;
							System.out.println(val);
						}
                        
                    }
                }
            } 
			System.out.println(max);
        }

        public static int getApples(int[][] area, int i, int j){
			int k = 0;
            if (i < 0 || i >= area.length || j < 0 || j >= area[0].length){
                return 0;
            }
            if (area[i][j] == 0) {
                return k;
            }
            if (area[i][j] == -1) {
                return k;
            }
			if(area[i][j]!= 0){
				k += area[i][j];
			}
            int count = 0;
            area[i][j] = -1;
            count += getApples(area, i-1, j);
            count += getApples(area, i, j-1);
            count += getApples(area, i, j+1);
            count += getApples(area, i+1, j);

            return count;

        }
}

