import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

class Person {
    String name;
    int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }
}

class Student extends Person {
    int rollNo;
    float averageMarks;

    public Student(String name, int age, int rollNo, float averageMarks) {
        super(name, age);
        this.rollNo = rollNo;
        this.averageMarks = averageMarks;
    }
}

class GraduateStudent extends Student {
    String subject;
    boolean employed;

    public GraduateStudent(String name, int age, int rollNo, float averageMarks, String subject, boolean employed) {
        super(name, age, rollNo, averageMarks);
        this.subject = subject;
        this.employed = employed;
    }
}

public class GraduationReport {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter year: ");
        int year = scanner.nextInt();
        System.out.print("Enter number of working graduates: ");
        int numWorking = scanner.nextInt();
        System.out.print("Enter number of non-working graduates: ");
        int numNonWorking = scanner.nextInt();
        int totalGraduates = numWorking + numNonWorking;
        System.out.print("percentage of non-working graduates (in decimal): ");
        float xPercent = (((float)numNonWorking/totalGraduates)*100);
		System.out.println(xPercent);
        System.out.print("percentage of working graduates (in decimal): ");
        float nPercent = (((float)numWorking/totalGraduates)*100);
		System.out.println(nPercent);

        GraduateStudent[] students = new GraduateStudent[totalGraduates];
		try (BufferedWriter writer_db = new BufferedWriter(new FileWriter("Student_db.txt"))) {
			writer_db.write("Report for year " + year + ":\n");
			for (int i = 0; i < totalGraduates; i++) {
				System.out.println("\nEnter details for student " + (i + 1) + ":");
				System.out.print("Name: ");
				String name = scanner.next();
				System.out.print("Age: ");
				int age = scanner.nextInt();
				System.out.print("Roll No: ");
				int rollNo = scanner.nextInt();
				System.out.print("Average Marks: ");
				float avgMarks = scanner.nextFloat();
				System.out.print("Subject: ");
				String subject = scanner.next();
				System.out.print("Employed(true/false): ");
				boolean employed = scanner.nextBoolean();

				students[i] = new GraduateStudent(name, age, rollNo, avgMarks, subject, employed);
			}
		}catch(IOException e){
			System.out.println("Error writing to file: " + e.getMessage());
		}

        GraduateStudent topScorer = findTopScorer(students);

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("report.txt"))) {
            writer.write("Report for year " + year + ":\n");
            writer.write("Number of working graduates: " + numWorking + "\n");
            writer.write("Number of non-working graduates: " + numNonWorking + "\n");
            writer.write("Top Scorer:\n");
            writer.write("Name: " + topScorer.name + "\n");
            writer.write("Age: " + topScorer.age + "\n");
            writer.write("Subject: " + topScorer.subject + "\n");
            writer.write("Average Marks: " + topScorer.averageMarks + "\n");
            writer.write(String.format("%.2f%% of the graduates this year are non-working and %.2f%% are working graduates.\n", xPercent , nPercent));
            System.out.println("Report generated successfully!");
        } catch (IOException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }
    }

    public static GraduateStudent findTopScorer(GraduateStudent[] students) {
        GraduateStudent topScorer = students[0];
        for (int i = 1; i < students.length; i++) {
            if (students[i].averageMarks > topScorer.averageMarks) {
                topScorer = students[i];
            }
        }
        return topScorer;
    }
}
