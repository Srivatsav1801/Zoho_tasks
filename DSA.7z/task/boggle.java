import java.util.*;

public class BoggleGame {
    private static boolean dfs(char[][] board, String s, int i, int j, int n, int m, int idx) {
        if (i < 0 || i >= n || j < 0 || j >= m) {
            return false;
        }
        if (s.charAt(idx) != board[i][j]) {
            return false;
        }
        if (idx == s.length() - 1) {
            return true;
        }
        char temp = board[i][j];
        board[i][j] = '*';

        boolean a = dfs(board, s, i, j + 1, n, m, idx + 1);
        boolean b = dfs(board, s, i, j - 1, n, m, idx + 1);
        boolean c = dfs(board, s, i + 1, j, n, m, idx + 1);
        boolean d = dfs(board, s, i - 1, j, n, m, idx + 1);
        boolean e = dfs(board, s, i + 1, j + 1, n, m, idx + 1);
        boolean f = dfs(board, s, i - 1, j + 1, n, m, idx + 1);
        boolean g = dfs(board, s, i + 1, j - 1, n, m, idx + 1);
        boolean h = dfs(board, s, i - 1, j - 1, n, m, idx + 1);

        board[i][j] = temp;
        return a || b || c || e || f || g || h || d;
    }

    private static void wordBoggle(char[][] board, String[] dictionary) {
        int n = board.length;
        int m = board[0].length;
        Set<String> ans = new HashSet<>();
        Set<String> store = new HashSet<>();
        for (String s : dictionary) {
            int l = s.length();
            for (int i = 0; i < n; i++) {
                for (int j = 0; j < m; j++) {
                    if (dfs(board, s, i, j, n, m, 0)) {
                        store.add(s);
                    }
                }
            }
        }
        for (String i : store) {
            System.out.println(i);
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the number of rows in the Boggle board: ");
        int numRows = scanner.nextInt();

        System.out.print("Enter the number of columns in the Boggle board: ");
        int numCols = scanner.nextInt();

        char[][] boggle = new char[numRows][numCols];
        System.out.println("Enter the letters for the Boggle board:");
        for (int i = 0; i < numRows; i++) {
            for (int j = 0; j < numCols; j++) {
                boggle[i][j] = scanner.next().charAt(0);
            }
        }

        System.out.print("Enter the number of words in the dictionary: ");
        int numWords = scanner.nextInt();
        String[] dictionary = new String[numWords];
        System.out.println("Enter the words in the dictionary:");
        for (int i = 0; i < numWords; i++) {
            dictionary[i] = scanner.next();
        }

        System.out.println("Following words of dictionary are present:");
        wordBoggle(boggle, dictionary);

        scanner.close();
    }
}
