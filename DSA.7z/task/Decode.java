import java.util.*;
class Decode{
	public static void main(String[] args){
		int i =0;
		String s = "";
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the encoded message");
		s = sc.next();
		int n = s.length();
		int[] dp = new int[n];
		for(i=0;i<n;i++){
			dp[i] = -1;
		}
		System.out.println(num_decode(s, 0, dp));		
	}

	private static int num_decode(String s, int i, int[] dp) {
		int n = s.length();
		if (i == n)
			return 1;
		if (s.charAt(i) == '0')
			return 0;
		if (dp[i] != -1)
			return dp[i];
		int count = num_decode(s, i + 1, dp);
		if (i < n - 1 && ((s.charAt(i) - '0') * 10 + (s.charAt(i + 1) - '0')) < 27) {
			count += num_decode(s, i + 2, dp);
		}
			return dp[i] = count;
	}
}
