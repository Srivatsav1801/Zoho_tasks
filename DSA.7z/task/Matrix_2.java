import java.util.*;
class Matrix_2{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Size of the array");
		int n = sc.nextInt();
		int[] mat = new int[n];
		System.out.println("Enter the array elements: ");
		for(int i =0;i<n;i++){
			mat[i] = sc.nextInt();
		}
		System.out.println(sumOddLengthSubarrays(mat));

	}
    public static int sumOddLengthSubarrays(int[] arr) {
		int total = 0;
		for (int windowSize = 1; windowSize <= arr.length; windowSize += 2) {
			int windowSum = 0;
			for (int i = 0; i < windowSize; i++)
				windowSum += arr[i];
			total += windowSum;

			for (int i = 1; i + windowSize <= arr.length; i++) {
				windowSum = windowSum - arr[i - 1] + arr[i + windowSize - 1];
				total += windowSum;
			}
		}
		return total;
	}
}



