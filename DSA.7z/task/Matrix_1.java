import java.util.*;
class Matrix_1{
public static void main(String[] args){
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter the Size of the matrix");
	int n = sc.nextInt();
	int[][] mat = new int[n][n];
	System.out.println("Enter the matrix elements: ");
	for(int i =0;i<n;i++){
		for(int j = 0; j<n;j++){
			mat[i][j] = sc.nextInt();
		}
	}
	System.out.println(diagonalSum(mat,n));

}
    static int diagonalSum(int[][] mat,int n) {
        int ans=0;
        int mid=n/2;
        
            for(int i=0;i<n;i++)
            {
                ans+=mat[i][i]+mat[i][n-i-1];
            }
            if(n%2==1)
            {
              ans-=mat[mid][mid];
            }
            return ans;
    }
};