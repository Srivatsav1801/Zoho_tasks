import java.util.*;
class Longest_valid_par{
	public static void main(String[] args){
		String s = "";
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string");
		s = sc.next();
		System.out.println(longestValidParentheses(s));		
	}
	


	public static int longestValidParentheses(String s) {
			int[] dp = new int[s.length()];
			int res = 0;
			int leftCount = 0, rightCount = 0;

			for (int i = 0; i < s.length(); i++) {
				if (s.charAt(i) == '(') {
					leftCount++;
				} else if (rightCount < leftCount) {
					rightCount++;
					dp[i] = dp[i - 1] + 2;
					dp[i] += (i - dp[i]) >= 0 ? dp[i - dp[i]] : 0;
					res = Math.max(res, dp[i]);
				} 
				else {
					leftCount = 0;
					rightCount = 0;
					dp[i] = 0;
				}
			}
			return res;
		}
}