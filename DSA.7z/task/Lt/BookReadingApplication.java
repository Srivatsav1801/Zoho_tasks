import java.io.*;
import java.util.Scanner;

interface UserInterface {
    void register();
    void requestAccess();
}

interface AdminInterface {
    void approveAccess();
}

class Book {
    private String title;
    private String author;
    private String content;

    public Book(String title, String author, String content) {
        this.title = title;
        this.author = author;
        this.content = content;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getContent() {
        return content;
    }
}
class User implements UserInterface {
    private String name;
    private String userId;
    private String email;
    private String mobileNumber;
    private String accessPassword;

    public User(String name, String userId, String email, String mobileNumber) {
        this.name = name;
        this.userId = userId;
        this.email = email;
        this.mobileNumber = mobileNumber;
        this.accessPassword = "";
    }

    public void register() {
        System.out.println("User Registration:");
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your name: ");
        name = scanner.nextLine();
        System.out.print("Enter your user ID: ");
        userId = scanner.nextLine();
        System.out.print("Enter your email ID: ");
        email = scanner.nextLine();
        System.out.print("Enter your mobile number: ");
        mobileNumber = scanner.nextLine();
        System.out.println("Registration successful!");
    }

    public void requestAccess() {
        System.out.println("Access Request Sent to Admin.");
    }

    public void setAccessPassword(String password) {
        this.accessPassword = password;
    }

    public String getAccessPassword() {
        return accessPassword;
    }
}

class Admin implements AdminInterface {
    private String password;

    public Admin(String password) {
        this.password = password;
    }

    public void approveAccess() {
        System.out.println("Access Approved! Enter the access password for the user: ");
        Scanner scanner = new Scanner(System.in);
        password = scanner.nextLine();
    }

    public boolean checkAdminPassword(String enteredPassword) {
        return enteredPassword.equals(password);
    }
}

public class BookReadingApplication {
    public static void main(String[] args) {
        Book book1 = new Book("Book 1", "Author 1", "Content of Book 1");
        Book book2 = new Book("Book 2", "Author 2", "Content of Book 2");
        Book book3 = new Book("Book 3", "Author 3", "Content of Book 3");

        writeBookToFile(book1, "book1.txt");
        writeBookToFile(book2, "book2.txt");
        writeBookToFile(book3, "book3.txt");

        User user = new User("", "", "", "");
        Admin admin = new Admin("admin123");

        user.register();

        user.requestAccess();

        System.out.println("Enter Admin Password to approve access: ");
        Scanner scanner = new Scanner(System.in);
        String adminPassword = scanner.nextLine();
        if (admin.checkAdminPassword(adminPassword)) {
            admin.approveAccess();
            user.setAccessPassword(admin.getAccessPassword());
            System.out.println("Access password set for the user: " + user.getAccessPassword());
        } else {
            System.out.println("Admin Password Incorrect. Access Denied.");
        }
    }

    private static void writeBookToFile(Book book, String filename) {
        try (PrintWriter writer = new PrintWriter(filename)) {
            writer.println("Title: " + book.getTitle());
            writer.println("Author: " + book.getAuthor());
            writer.println("Content:\n" + book.getContent());
        } catch (FileNotFoundException e) {
            System.out.println("Error writing to file: " + e.getMessage());
        }
    }
}
