class Vehicle {
    double mileage;
    double price;

    public Vehicle(double mileage, double price) {
        this.mileage = mileage;
        this.price = price;
    }
}

class Car extends Vehicle {
    double ownershipCost;
    int warranty;
    int seatingCapacity;
    String fuelType;

    public Car(double mileage, double price, double ownershipCost, int warranty, int seatingCapacity, String fuelType) {
        super(mileage, price);
        this.ownershipCost = ownershipCost;
        this.warranty = warranty;
        this.seatingCapacity = seatingCapacity;
        this.fuelType = fuelType;
    }
}

class Bike extends Vehicle {
    int cylinders;
    int gears;
    String coolingType;
    String wheelType;
    double fuelTankSize;

    public Bike(double mileage, double price, int cylinders, int gears, String coolingType, String wheelType, double fuelTankSize) {
        super(mileage, price);
        this.cylinders = cylinders;
        this.gears = gears;
        this.coolingType = coolingType;
        this.wheelType = wheelType;
        this.fuelTankSize = fuelTankSize;
    }
}

class Audi extends Car {
    String modelType;

    public Audi(double mileage, double price, double ownershipCost, int warranty, int seatingCapacity, String fuelType, String modelType) {
        super(mileage, price, ownershipCost, warranty, seatingCapacity, fuelType);
        this.modelType = modelType;
    }
}

class Ford extends Car {
    String modelType;

    public Ford(double mileage, double price, double ownershipCost, int warranty, int seatingCapacity, String fuelType, String modelType) {
        super(mileage, price, ownershipCost, warranty, seatingCapacity, fuelType);
        this.modelType = modelType;
    }
}

class Bajaj extends Bike {
    String makeType;

    public Bajaj(double mileage, double price, int cylinders, int gears, String coolingType, String wheelType, double fuelTankSize, String makeType) {
        super(mileage, price, cylinders, gears, coolingType, wheelType, fuelTankSize);
        this.makeType = makeType;
    }
}

class TVS extends Bike {
    String makeType;

    public TVS(double mileage, double price, int cylinders, int gears, String coolingType, String wheelType, double fuelTankSize, String makeType) {
        super(mileage, price, cylinders, gears, coolingType, wheelType, fuelTankSize);
        this.makeType = makeType;
    }
}

public class Transports {
    public static void main(String[] args) {
        Audi audi = new Audi(25, 50000, 3000, 3, 5, "petrol", "A6");
        Ford ford = new Ford(20, 45000, 2800, 2, 4, "diesel", "Fusion");

        Bajaj bajaj = new Bajaj(50, 20000, 4, 6, "air", "alloys", 15, "Pulsar");
        TVS tvs = new TVS(45, 18000, 3, 5, "liquid", "spokes", 14, "Apache");

        System.out.println("Audi Information:");
        System.out.println("Model Type: " + audi.modelType);
        System.out.println("Ownership Cost: " + audi.ownershipCost);
        System.out.println("Warranty: " + audi.warranty + " years");
        System.out.println("Seating Capacity: " + audi.seatingCapacity);
        System.out.println("Fuel Type: " + audi.fuelType);
        System.out.println("Mileage: " + audi.mileage);
        System.out.println("Price: " + audi.price);
        System.out.println();

        System.out.println("Ford Information:");
        System.out.println("Model Type: " + ford.modelType);
        System.out.println("Ownership Cost: " + ford.ownershipCost);
        System.out.println("Warranty: " + ford.warranty + " years");
        System.out.println("Seating Capacity: " + ford.seatingCapacity);
        System.out.println("Fuel Type: " + ford.fuelType);
        System.out.println("Mileage: " + ford.mileage);
        System.out.println("Price: " + ford.price);
        System.out.println();

        System.out.println("Bajaj Information:");
        System.out.println("Make Type: " + bajaj.makeType);
        System.out.println("Number of Cylinders: " + bajaj.cylinders);
        System.out.println("Number of Gears: " + bajaj.gears);
        System.out.println("Cooling Type: " + bajaj.coolingType);
        System.out.println("Wheel Type: " + bajaj.wheelType);
        System.out.println("Fuel Tank Size: " + bajaj.fuelTankSize + " inches");
        System.out.println("Mileage: " + bajaj.mileage);
        System.out.println("Price: " + bajaj.price);
        System.out.println();

        System.out.println("TVS Information:");
        System.out.println("Make Type: " + tvs.makeType);
        System.out.println("Number of Cylinders: " + tvs.cylinders);
        System.out.println("Number of Gears: " + tvs.gears);
        System.out.println("Cooling Type: " + tvs.coolingType);
        System.out.println("Wheel Type: " + tvs.wheelType);
        System.out.println("Fuel Tank Size: " + tvs.fuelTankSize + " inches");
        System.out.println("Mileage: " + tvs.mileage);
        System.out.println("Price: " + tvs.price);
    }
}
