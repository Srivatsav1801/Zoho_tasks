import java.util.Scanner;

class MyString {
    private char[] string;
    private int length;

    public MyString(String str) {
        this.string = str.toCharArray();
        this.length = str.length();
    }

    public int length() {
        return length;
    }

    public MyString concatenate(MyString other) {
        char[] result = new char[length + other.length];
        System.arraycopy(string, 0, result, 0, length);
        System.arraycopy(other.string, 0, result, length, other.length);
        return new MyString(new String(result));
    }

    public int compareTo(MyString other) {
        for (int i = 0; i < Math.min(length, other.length); i++) {
            if (string[i] != other.string[i]) {
                return string[i] - other.string[i];
            }
        }
        return length - other.length;
    }

    public MyString reverse() {
        char[] reversed = new char[length];
        for (int i = 0; i < length; i++) {
            reversed[i] = string[length - 1 - i];
        }
        return new MyString(new String(reversed));
    }

    public int indexOf(char ch) {
        for (int i = 0; i < length; i++) {
            if (string[i] == ch) {
                return i;
            }
        }
        return -1;
    }

    public void separateOddEven() {
        System.out.print("Characters at odd-indexed locations: ");
        for (int i = 0; i < length; i += 2) {
            System.out.print(string[i] + " ");
        }
        System.out.println();
        System.out.print("Characters at even-indexed locations: ");
        for (int i = 1; i < length; i += 2) {
            System.out.print(string[i] + " ");
        }
        System.out.println();
    }

    public MyString substring(int startIndex, int numChars) {
        char[] substr = new char[numChars];
        System.arraycopy(string, startIndex, substr, 0, numChars);
        return new MyString(new String(substr));
    }

    public boolean equals(MyString other) {
        if (length != other.length) {
            return false;
        }
        for (int i = 0; i < length; i++) {
            if (string[i] != other.string[i]) {
                return false;
            }
        }
        return true;
    }

    public boolean isEmpty() {
        return length == 0;
    }

    public char[] toCharArray() {
        return string;
    }

    public MyString toUpperCase() {
        char[] upperCase = new char[length];
        for (int i = 0; i < length; i++) {
            upperCase[i] = Character.toUpperCase(string[i]);
        }
        return new MyString(new String(upperCase));
    }

    public MyString trim() {
        int start = 0;
        int end = length - 1;
        while (start <= end && Character.isWhitespace(string[start])) {
            start++;
        }
        while (end >= start && Character.isWhitespace(string[end])) {
            end--;
        }
        char[] trimmed = new char[end - start + 1];
        System.arraycopy(string, start, trimmed, 0, end - start + 1);
        return new MyString(new String(trimmed));
    }

    // Method to display the string
    public void display() {
        System.out.println(new String(string));
    }
}

public class String_manpulation {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter a string: ");
        String input = scanner.nextLine();
        MyString str = new MyString(input);

        System.out.println("Length of the string: " + str.length());

        System.out.print("Enter another string to concatenate: ");
        String input2 = scanner.nextLine();
        MyString str2 = new MyString(input2);
        MyString concatenated = str.concatenate(str2);
        System.out.println("Concatenated string: ");
        concatenated.display();

        System.out.print("Enter a string to compare with the original string: ");
        String input3 = scanner.nextLine();
        MyString str3 = new MyString(input3);
        int comparison = str.compareTo(str3);
        if (comparison == 0) {
            System.out.println("Strings are equal.");
        } else if (comparison < 0) {
            System.out.println("Original string comes before the input string.");
        } else {
            System.out.println("Original string comes after the input string.");
        }

        MyString reversed = str.reverse();
        System.out.println("Reversed string: ");
        reversed.display();

        System.out.print("Enter a character to find its index: ");
        char ch = scanner.next().charAt(0);
        int index = str.indexOf(ch);
        if (index != -1) {
            System.out.println("Index of " + ch + ": " + index);
        } else {
            System.out.println("Character not found.");
        }

        System.out.println("Separating characters from odd and even-indexed locations:");
        str.separateOddEven();

        System.out.print("Enter the starting index of the substring: ");
        int startIndex = scanner.nextInt();
        System.out.print("Enter the number of characters in the substring: ");
        int numChars = scanner.nextInt();
        MyString substring = str.substring(startIndex, numChars);
        System.out.println("Substring: ");
        substring.display();

        System.out.print("Enter a string to compare with the original string: ");
        String input4 = scanner.next();
        MyString str4 = new MyString(input4);
        boolean isEqual = str.equals(str4);
        System.out.println("Strings are equal: " + isEqual);

        System.out.println("Is the original string empty: " + str.isEmpty());

        char[] charArray = str.toCharArray();
        System.out.println("Character array representation of the string: ");
        System.out.println(charArray);

        MyString upperCaseStr = str.toUpperCase();
        System.out.println("Uppercase string: ");
        upperCaseStr.display();

        MyString trimmedStr = str.trim();
        System.out.println("Trimmed string: ");
        trimmedStr.display();
    }
}
