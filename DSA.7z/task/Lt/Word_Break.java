import java.util.*;

public class Word_Break {
   
    static boolean wordBreak(List<String> wordList, String word) {
        
        if (word.isEmpty()) {
            return true;
        }

        int wordLen = word.length();

        for (int i = 1; i <= wordLen; ++i) {
            String prefix = word.substring(0, i);

            if (wordList.contains(prefix) && wordBreak(wordList, word.substring(i))) {
                return true;
            }
        }

        return false;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the word list (separate words by spaces):");
        String[] wordArray = scanner.nextLine().split("\\s+");
        List<String> wordList = Arrays.asList(wordArray);

        System.out.println("Enter the word to be checked:");
        String word = scanner.nextLine();

        boolean result = wordBreak(wordList, word);

        if(result){
			System.out.println("YES");
		}
		else{
			System.out.println("NO");
		}
    }
}
