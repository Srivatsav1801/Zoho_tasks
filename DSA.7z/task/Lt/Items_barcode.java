import java.util.Scanner;

class Item {
    private String barcode;
    private String itemName;

    public Item() {
        this.barcode = "";
        this.itemName = "";
    }

    public Item(String barcode, String itemName) {
        this.barcode = barcode;
        this.itemName = itemName;
    }

    public String getCode() {
        return barcode;
    }

    public void setCode(String barcode) {
        this.barcode = barcode;
    }

    public void scanner() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Barcode: ");
        this.barcode = scanner.nextLine();
        System.out.print("Enter Item Name: ");
        this.itemName = scanner.nextLine();
    }

    public void printer() {
        System.out.println("Barcode: " + barcode);
        System.out.println("Item Name: " + itemName);
    }
}

class PackedFood extends Item {
    private double unitPrice;

    public PackedFood() {
        super();
        this.unitPrice = 0.0;
    }

    public PackedFood(String barcode, String itemName, double unitPrice) {
        super(barcode, itemName);
        this.unitPrice = unitPrice;
    }

    public double getUnitPrice() {
        return unitPrice;
    }

    public void scanner() {
        super.scanner();
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Unit Price: ");
        this.unitPrice = scanner.nextDouble();
    }
}

class FreshFood extends Item {
    private double weight;
    private double pricePerKg;

    public FreshFood() {
        super();
        this.weight = 0.0;
        this.pricePerKg = 0.0;
    }

    public FreshFood(String barcode, String itemName, double weight, double pricePerKg) {
        super(barcode, itemName);
        this.weight = weight;
        this.pricePerKg = pricePerKg;
    }

    public double getWeight() {
        return weight;
    }

    public double getPricePerKg() {
        return pricePerKg;
    }

    
    public void scanner() {
        super.scanner();
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Weight: ");
        this.weight = scanner.nextDouble();
        System.out.print("Enter Price Per Kg: ");
        this.pricePerKg = scanner.nextDouble();
    }
}

public class Items_barcode {
    public static void main(String[] args) {
        Item item1 = new Item("12345", "Chocolate");
        Item item2 = new Item();
        item2.scanner();
		
        PackedFood packedFood1 = new PackedFood("67890", "Chips", 2.5);
        PackedFood packedFood2 = new PackedFood();
        packedFood2.scanner();

        FreshFood freshFood1 = new FreshFood("54321", "Apple", 1.5, 3.0);
        FreshFood freshFood2 = new FreshFood();
        freshFood2.scanner();

        System.out.println("\nItem 1:");
        item1.printer();
        System.out.println("\nItem 2:");
        item2.printer();
        System.out.println("\nPacked Food 1:");
        packedFood1.printer();
        System.out.println("\nPacked Food 2:");
        packedFood2.printer();
        System.out.println("\nFresh Food 1:");
        freshFood1.printer();
        System.out.println("\nFresh Food 2:");
        freshFood2.printer();
    }
}
