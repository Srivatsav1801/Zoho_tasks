public class Passenger
{
    static int id = 1;
    String name;
    int age;
    String berthPreference;
    int passengerId;
    String alloted;
    int number;
	int pnr ;
    public Passenger(String name,int age,String berthPreference,int pnr)
    {
		this.pnr = pnr;
        this.name = name;
        this.age = age;
        this.berthPreference = berthPreference;
        this.passengerId = id++;
        alloted = "";
        number = -1;
    }
}
