import java.util.*;

public class TicketBooker {
    // Total berths: 4 Lower, 4 Middle, 4 Upper, 2 Side Upper, 2 Side Lower
    static int availableLowerBerths = 4;
    static int availableMiddleBerths = 4;
    static int availableUpperBerths = 4;
    static int availableSideUpperBerths = 2;
    static int availableSideLowerBerths = 2;
    static int availableRacTickets = 4;
    static int availableWaitingList = 14;

    static Queue<Integer> waitingList = new LinkedList<>(); 
    static Queue<Integer> racList = new LinkedList<>(); 
    static List<Integer> bookedTicketList = new ArrayList<>(); 
    
	
    static List<Integer> lowerBerthsPositions = new ArrayList<>(Arrays.asList(1, 4, 9, 12));
    static List<Integer> middleBerthsPositions = new ArrayList<>(Arrays.asList(2,5,10,13));
    static List<Integer> upperBerthsPositions = new ArrayList<>(Arrays.asList(3,6,11,14));
    static List<Integer> sideUpperBerthsPositions = new ArrayList<>(Arrays.asList(8,16));
    static List<Integer> sideLowerBerthsPositions = new ArrayList<>(Arrays.asList(7,15));

    static List<Integer> racPositions = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18));
    static List<Integer> waitingListPositions = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10));

    static Map<Integer, Passenger> passengers = new HashMap<>(); 
    public void bookTicket(Passenger p, int berthInfo, String allotedBerth) {
        p.number = berthInfo;
        p.alloted = allotedBerth;
        passengers.put(p.pnr, p);
        bookedTicketList.add(p.pnr);
        System.out.println("--------------------------Booked Successfully");
    }

    public void addToRAC(Passenger p, int racInfo, String allotedRAC) {
        p.number = racInfo;
        p.alloted = allotedRAC;
        passengers.put(p.pnr, p);
        racList.add(p.pnr);
        availableRacTickets--;
        racPositions.remove(0);

        System.out.println("--------------------------Added to RAC Successfully");
    }

    public void addToWaitingList(Passenger p, int waitingListInfo, String allotedWL) {
        p.number = waitingListInfo;
        p.alloted = allotedWL;
        passengers.put(p.pnr, p);
        waitingList.add(p.pnr);
        availableWaitingList--;
        waitingListPositions.remove(0);

        System.out.println("--------------------------Added to Waiting List Successfully");
    }

    public void cancelTicket(int pnr) {
        Passenger p = passengers.get(pnr);
        passengers.remove(Integer.valueOf(pnr));
        bookedTicketList.remove(Integer.valueOf(pnr));

        int positionBooked = p.number;

        System.out.println("---------------Cancelled Successfully");

        switch (p.alloted) {
            case "L":
                availableLowerBerths++;
                lowerBerthsPositions.add(positionBooked);
                break;
            case "M":
                availableMiddleBerths++;
                middleBerthsPositions.add(positionBooked);
                break;
            case "U":
                availableUpperBerths++;
                upperBerthsPositions.add(positionBooked);
                break;
            case "SU":
                availableSideUpperBerths++;
                sideUpperBerthsPositions.add(positionBooked);
                break;
            case "SL":
                availableSideLowerBerths++;
                sideLowerBerthsPositions.add(positionBooked);
                break;
        }

        if (racList.size() > 0) {
            Passenger passengerFromRAC = passengers.get(racList.poll());
            int positionRac = passengerFromRAC.number;
            racPositions.add(positionRac);
            racList.remove(Integer.valueOf(passengerFromRAC.pnr));
            availableRacTickets++;

            if (waitingList.size() > 0) {
                Passenger passengerFromWaitingList = passengers.get(waitingList.poll());
                int positionWL = passengerFromWaitingList.number;
                waitingListPositions.add(positionWL);
                waitingList.remove(Integer.valueOf(passengerFromWaitingList.pnr));

                passengerFromWaitingList.number = racPositions.get(0);
                passengerFromWaitingList.alloted = "RAC";
                racPositions.remove(0);
                racList.add(passengerFromWaitingList.pnr);

                availableWaitingList++;
                availableRacTickets--;
            }
            bookTicket(passengerFromRAC, positionBooked, p.alloted);
        }
    }

    public void printAvailable() {
        System.out.println("Available Lower Berths " + availableLowerBerths);
        System.out.println("Available Middle Berths " + availableMiddleBerths);
        System.out.println("Available Upper Berths " + availableUpperBerths);
        System.out.println("Available Side Upper Berths " + availableSideUpperBerths);
        System.out.println("Available Side Lower Berths " + availableSideLowerBerths);
        System.out.println("Available RACs " + availableRacTickets);
        System.out.println("Available Waiting List " + availableWaitingList);
        System.out.println("--------------------------");
    }

    public void printPassengers() {
        if (passengers.size() == 0) {
            System.out.println("No details of passengers");
            return;
        }
		System.out.println("PNR\tBerth No\tCurrent Status\tBerth Type\tName\tAge");
        for (Passenger p : passengers.values()) {
			String Status ;
			if(p.alloted == "L"||p.alloted == "M"||p.alloted =="SU"||p.alloted == "SL"){
				Status = "CNF";
				}
			else{
				Status = p.alloted+p.number;
			}
            System.out.println(p.pnr+"\t"+p.number+"\t"+ Status +"\t"+p.alloted+"\t"+p.name+"\t"+p.age);
        }
    }
	
	public static void updateBerthPositions() {
        lowerBerthsPositions = new ArrayList<>(Arrays.asList(1, 4, 9, 12, 15, 18));
        middleBerthsPositions = new ArrayList<>(Arrays.asList(2, 5, 10, 13, 16, 19));
        upperBerthsPositions = new ArrayList<>(Arrays.asList(3, 6, 11, 14, 17, 20));
        sideUpperBerthsPositions = new ArrayList<>(Arrays.asList(8, 16, 24, 32));
        sideLowerBerthsPositions = new ArrayList<>(Arrays.asList(7, 15, 23, 31));
		
		
    }
	
	public static void addCoaches(int numberOfCoaches) {
        for (int i = 0; i < numberOfCoaches; i++) {
            updateBerthPositions();
        }
		int totalLowerBerths = lowerBerthsPositions.size();
        int totalMiddleBerths = middleBerthsPositions.size();
        int totalUpperBerths = upperBerthsPositions.size();
        int totalSideUpperBerths = sideUpperBerthsPositions.size();
        int totalSideLowerBerths = sideLowerBerthsPositions.size();

        availableLowerBerths += (totalLowerBerths - 4) * numberOfCoaches; 
        availableMiddleBerths += (totalMiddleBerths - 4) * numberOfCoaches;
        availableUpperBerths += (totalUpperBerths - 4) * numberOfCoaches; 
        availableSideUpperBerths += (totalSideUpperBerths - 2) * numberOfCoaches; 
        availableSideLowerBerths += (totalSideLowerBerths - 2) * numberOfCoaches; 
        availableRacTickets += 4 * numberOfCoaches; 
        availableWaitingList += 14 * numberOfCoaches;
    }
	
	public static void add_Two_Coaches_main(){
		  addCoaches(2);
	}
	
}
