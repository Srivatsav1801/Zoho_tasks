import java.util.*;
class Matrix_3{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Size of the array");
		int n = sc.nextInt();
		String[] words = new String[n];
		System.out.println("Enter the array elements: ");
		for(int i =0;i<n;i++){
			words[i] = sc.next();
		}
		System.out.println("Enter the prefix: ");
		String pre = sc.next();
		System.out.println(prefixCount(words,pre));

	}
    public static int prefixCount(String[] words, String pre) {
    int c = 0;
    for(String s : words) {
        if(s.indexOf(pre)==0) 
            c++;
    }
    return c; 
    }
}



