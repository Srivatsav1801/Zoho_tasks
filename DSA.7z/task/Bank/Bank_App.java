import java.io.*;
import java.util.*;


class Customer {
    private int custId;
    private int accountNo;
    private String name;
    private int balance;
    private String encryptedPwd;

    public Customer(int custId, int accountNo, String name, int balance, String encryptedPwd) {
        this.custId = custId;
        this.accountNo = accountNo;
        this.name = name;
        this.balance = balance;
        this.encryptedPwd = encryptedPwd;
    }

    public int getCustId() {
        return custId;
    }

    public int getAccountNo() {
        return accountNo;
    }

    public String getName() {
        return name;
    }

    public int getBalance() {
        return balance;
    }

    public String getEncryptedPwd() {
        return encryptedPwd;
    }

    public void deposit(int amount) {
        balance += amount;
    }
	
    public boolean withdraw(int amount) {
		Scanner scanner = new Scanner(System.in);
        if (balance >= amount) {
            balance -= amount;
			System.out.println("The amount withdrawn: "+amount +" The Balance available: "+balance);
			System.out.println("Press any key to continue!....");
			scanner.nextLine();
            return true;
        }
        return false;
    }
}

public class Bank_App {
    private Map<Integer, Customer> customers;

    public Bank_App() {
        customers = new HashMap<>();
    }

    public Customer authenticateCustomer(int accountNo, String password) {
        for (Customer customer : customers.values()) {
            if (customer.getAccountNo() == accountNo) {
                String decryptedPwd = decrypt(customer.getEncryptedPwd());
                if (password.equals(decryptedPwd)) {
                    return customer;
                }
            }
        }
        return null;
    }
	
	public static void clearScreen() {  
        try {
            new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        }
		catch(Exception e){
            System.out.println(e);
        }
    }  

    public boolean deposit(int custId, int amount) {
        if (customers.containsKey(custId)) {
            customers.get(custId).deposit(amount);
            return true;
        }
        return false;
    }

    public boolean withdraw(int custId, int amount) {
        if (customers.containsKey(custId)) {
            return customers.get(custId).withdraw(amount);
        }
        return false;
    }
	
    

    public int getBalance(String custId) {
        if (customers.containsKey(custId)) {
            return customers.get(custId).getBalance();
        }
        return -1;
    }    
	
	public void loadCustomersFromFile(String filename) {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split("\t");
                int custId = Integer.parseInt(parts[0]);
                int accountNo = Integer.parseInt(parts[1]);
                String name = parts[2];
                int balance = Integer.parseInt(parts[3]);
                String encryptedPwd = parts[4];
                customers.put(custId, new Customer(custId, accountNo, name, balance, decrypt(encryptedPwd)));
            }
        } catch (IOException e) {
            System.out.println(e);
        }
    }


    public void addCustomer(String name, String password) {
		int custId = generateCustomerId();
		int accountNo = generateAccountNumber();

		Scanner scanner = new Scanner(System.in);
		String reTypedPassword;
		do {
			System.out.print("Please re-type your password: ");
			reTypedPassword = scanner.nextLine();
			if (!password.equals(reTypedPassword)) {
				System.out.println("Passwords do not match. Please try again.");
			}
		} while (!password.equals(reTypedPassword));

		System.out.println("Your accountNo is: " + accountNo);
		System.out.println("Press any key to continue...");
		scanner.nextLine();

		int balance = 10000;

		String encryptedPwd = encrypt(password);

		Customer newCustomer = new Customer(custId, accountNo, name, balance, encryptedPwd);

		customers.put(custId, newCustomer);

		try (BufferedWriter writer = new BufferedWriter(new FileWriter("bank_db.txt", true))) {
			writer.write(custId + "\t" + accountNo + "\t" + name + "\t" + balance + "\t" + encryptedPwd + "\n");
		} catch (IOException e) {
			System.out.println(e);
		}
	}
	
	private String encrypt(String password) {
		StringBuilder encryptedPwd = new StringBuilder();
		for (char c : password.toCharArray()) {
			if (Character.isLetter(c)) {
				if (c == 'z') {
					encryptedPwd.append('a');
				} else if (c == 'Z') {
					encryptedPwd.append('A');
				} else {
					encryptedPwd.append((char) (c + 1));
				}
			} else if (Character.isDigit(c)) {
				if (c == '9') {
					encryptedPwd.append('0');
				} else {
					encryptedPwd.append((char) (c + 1));
				}
			} else {
				encryptedPwd.append(c);
			}
		}
		return encryptedPwd.toString();
	}



    private String decrypt(String encryptedPwd) {
		StringBuilder decryptedPwd = new StringBuilder();
		for (char c : encryptedPwd.toCharArray()) {
			if (Character.isLetter(c)) {
				if (c == 'a') {
					decryptedPwd.append('z');
				} else if (c == 'A') {
					decryptedPwd.append('Z');
				} else {
					decryptedPwd.append((char) (c - 1));
				}
			} else if (Character.isDigit(c)) {
				if (c == '0') {
					decryptedPwd.append('9');
				} else {
					decryptedPwd.append((char) (c - 1));
				}
			} else {
				decryptedPwd.append(c);
			}
		}
		return decryptedPwd.toString();
	}

	private int generateCustomerId() {
        Random rand = new Random();
        return rand.nextInt(99);
    }

    private int generateAccountNumber() {
        Random rand = new Random();
        return rand.nextInt(99999);
    }

	
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Bank_App bank = new Bank_App();
		bank.loadCustomersFromFile("bank_db.txt");
		boolean exit = false;
		while (!exit) {
			clearScreen();
			System.out.println("Choose from following option:");
			System.out.println("1.Login\n2.Register\n3.Exit");
			System.out.print("Enter your choice: ");
			int choice = scanner.nextInt();
			switch (choice) {
				case 1:
					System.out.print("Enter Account Number: ");
					int accountNo = scanner.nextInt();
					System.out.print("Enter Password: ");
					String password = scanner.next();
					Customer customer = bank.authenticateCustomer(accountNo, password);
					if (customer != null) {
						System.out.println("Authentication successful!");
						System.out.println("Customer Name: " + customer.getName());
						System.out.println("Account Balance: " + customer.getBalance());
						System.out.println("Press any key to continue...");
						scanner.nextLine();
						home(customer);
					} else {
						System.out.println("Authentication failed.");
						System.out.println("Press any key to continue...");
						scanner.nextLine();
					}
					break;

				case 2:
					System.out.println("Account Registration");
					System.out.print("Enter Your Name: ");
					String name = scanner.next();
					System.out.print("Enter Your Password: ");
					password = scanner.next();
					bank.addCustomer(name, password);
					break;

				case 3:
					System.out.println("Closing the app...");
					exit = true;
					break;

				default:
					System.out.println("Invalid choice.");
			}

		}
	}
	
	private static void home(Customer customer) {
		int choice;
		boolean exit = false;
		while (!exit) {
			clearScreen();
			System.out.println("Choose from following option:");
			System.out.println("1.ATM withdrawal\n2.Cash deposit\n3.Account Transfer\n4.Logout");
			System.out.print("Enter your choice: ");
			Scanner scanner = new Scanner(System.in);
			choice = scanner.nextInt();
			switch (choice) {
				case 1:
					clearScreen();
					System.out.println("ATM withdrawal");
					System.out.print("Enter the amount to be withdrawn: ");
					int amount = scanner.nextInt();
					customer.withdraw(amount);
					break;
				case 2:
					System.out.println("Cash deposit");
					break;
				case 3:
					System.out.println("Account Transfer");
					break;
				case 4:
					System.out.println("Logging out...");
					System.out.println("Press any key to continue...");
					scanner.nextLine();
					exit = true;
					break;
				default:
					System.out.println("Invalid choice. Please try again.");
					System.out.println("Press any key to continue...");
					scanner.nextLine();
					break;
			}
		}
	}

        
	
	

}
