import java.util.*;
class Min_jump{
	public static void main(String[] args){
		int i,n;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of the jump array");
		n = sc.nextInt();
		int[] array = new int[n];
		System.out.println("Enter the array elements:");
		for(i = 0;i<n;i++){
			array[i] = sc.nextInt();
		}
		System.out.println(jump(array));
		
	}
	
	public static int jump(int[] array) {
		int i,n,j;
		n=array.length;
		int [] dp = new int[n];
		for(i=0;i<n;i++)
		{
			dp[i] = Integer.MAX_VALUE;
		}		
		dp[0] = 0;
		for(i=0;i<n;i++)
		{
			for(j=i;j<=i+array[i] && j<n;j++)
			{
				dp[j] = Math.min(dp[j], dp[i]+1);
			}
		}
		return dp[n-1];
	}
}