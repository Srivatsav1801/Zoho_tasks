import java.util.*;

public class DungeonV2 {

    static class Point {
    
		int row;
        
		int col;

        public Point(int row, int col) {
        
			this.row = row;
            
			this.col = col;
        }
    }

    public static int minStepsToGoldWithPath(int[][] dungeon, Point adventurer, Point monster, Point gold, StringBuilder pathBuilder) {
        
		int rows = dungeon.length;
        
		int cols = dungeon[0].length;
        
		boolean[][] visited = new boolean[rows][cols];
        
		Point[][] prev = new Point[rows][cols]; 

        Queue<Point> adventurerQueue = new LinkedList<>();
        
		Queue<Point> monsterQueue = new LinkedList<>();

        adventurerQueue.add(adventurer);
        
		monsterQueue.add(monster);

        visited[adventurer.row][adventurer.col] = true;

        int[] dRow = {-1, 1, 0, 0}; 
        
		int[] dCol = {0, 0, -1, 1};

        int steps = 0;

        while (!adventurerQueue.isEmpty() && !monsterQueue.isEmpty()) {

            int adventurerQueueSize = adventurerQueue.size();

            while (adventurerQueueSize-- > 0) {

                Point adventurerCurrent = adventurerQueue.poll();

                int row = adventurerCurrent.row;

                int col = adventurerCurrent.col;

                if (row == gold.row && col == gold.col) {

                    Point current = new Point(row, col);

                    while (current != null) {

                        pathBuilder.insert(0, "(" + (current.row + 1) + "," + (current.col + 1) + ")");

                        if (prev[current.row][current.col] != null) {

                            pathBuilder.insert(0, " -> ");
                        }
                        current = prev[current.row][current.col];
                    }
                    return steps;
                }

                for (int i = 0; i < 4; i++) {

                    int newRow = row + dRow[i];

                    int newCol = col + dCol[i];

                    if (newRow >= 0 && newRow < rows && newCol >= 0 && newCol < cols && !visited[newRow][newCol] && dungeon[newRow][newCol] != -1) {

                        adventurerQueue.add(new Point(newRow, newCol));

                        visited[newRow][newCol] = true;

                        prev[newRow][newCol] = adventurerCurrent; 
                    }
                }
            }

            int monsterQueueSize = monsterQueue.size();

            while (monsterQueueSize-- > 0) {

                Point monsterCurrent = monsterQueue.poll();

                int row = monsterCurrent.row;

                int col = monsterCurrent.col;

                if (row == gold.row && col == gold.col) {

                    return -1;
                }


                for (int i = 0; i < 4; i++) {

                    int newRow = row + dRow[i];

                    int newCol = col + dCol[i];

                    if (newRow >= 0 && newRow < rows && newCol >= 0 && newCol < cols && !visited[newRow][newCol] && dungeon[newRow][newCol] != -1) {

                        monsterQueue.add(new Point(newRow, newCol));

                        visited[newRow][newCol] = true;
                    }
                }
            }

            steps++; 
        }

        return -1;
    }

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter dimensions of the dungeon (Row x Column):");

        int rows = scanner.nextInt();

        int cols = scanner.nextInt();

        scanner.nextLine(); 

        int[][] dungeon = new int[rows][cols];

        System.out.println("Enter position of adventurer:");

        int advRow = scanner.nextInt() - 1; 

        int advCol = scanner.nextInt() - 1;
        scanner.nextLine(); 

        System.out.println("Enter position of monster:");

        int monsterRow = scanner.nextInt() - 1;

        int monsterCol = scanner.nextInt() - 1;

        scanner.nextLine(); 

        System.out.println("Enter position of gold:");
       
		int goldRow = scanner.nextInt() - 1; 

        int goldCol = scanner.nextInt() - 1;
        

        for (int i = 0; i < rows; i++) {

            for (int j = 0; j < cols; j++) {

                dungeon[i][j] = 0; 
            }
        }
        dungeon[goldRow][goldCol] = 1; 

        dungeon[monsterRow][monsterCol] = -1; 

        Point adventurer = new Point(advRow, advCol);

        Point monster = new Point(monsterRow, monsterCol);

        Point gold = new Point(goldRow, goldCol);

        StringBuilder pathBuilder = new StringBuilder();

        int minSteps = minStepsToGoldWithPath(dungeon, adventurer, monster, gold, pathBuilder);

        if (minSteps == -1) {

            System.out.println("No possible solution");

        } else {

            System.out.println("Minimum number of steps: " + minSteps);

            System.out.println("Path: " + pathBuilder.toString());
        }
    }
}