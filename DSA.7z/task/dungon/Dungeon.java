import java.util.*;

public class Dungeon {
    static class State {
        int a1, a2, m1, m2, steps;
        String path;

        State(int a1, int a2, int m1, int m2, int steps, String path) {
            this.a1 = a1;
            this.a2 = a2;
            this.m1 = m1;
            this.m2 = m2;
            this.steps = steps;
            this.path = path;
        }
    }

    public static String findMinSteps(int m, int n, int a1, int a2, int m1, int m2, int g1, int g2) {
        int[][][][] visited = new int[m][n][m][n];
        Queue<State> queue = new LinkedList<>();
        queue.offer(new State(a1, a2, m1, m2, 0, "(" + (a1 + 1) + "," + (a2 + 1) + ")"));

        while (!queue.isEmpty()) {
            State state = queue.poll();
            int x = state.a1, y = state.a2, mx = state.m1, my = state.m2, steps = state.steps;
            String path = state.path;

            if (x == g1 && y == g2)
                return "Minimum number of steps: " + steps + "\nPath: " + path;

            if (visited[x][y][mx][my] == 1)
                continue;

            visited[x][y][mx][my] = 1;

            int[] dx = {-1, 1, 0, 0};
            int[] dy = {0, 0, -1, 1};

            for (int i = 0; i < 4; i++) {
                int newM1 = mx + dx[i];
                int newM2 = my + dy[i];

                if (newM1 == x && newM2 == y) {
                    mx = state.m1;
                    my = state.m2;
                    break;
                }
            }
			
            for (int i = 0; i < 4; i++) {
                int newA1 = x + dx[i];
                int newA2 = y + dy[i];

                if (newA1 >= 0 && newA1 < m && newA2 >= 0 && newA2 < n && (newA1 != mx || newA2 != my)) {
                    String newPath = path + " -> (" + (newA1 + 1) + "," + (newA2 + 1) + ")";
                    queue.offer(new State(newA1, newA2, mx, my, steps + 1, newPath));
                }
            }

            queue.offer(new State(x, y, mx, my, steps + 1, path));
        }

        return "No possible solution"; 
    }

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int m, n, a1, a2, m1, m2, g1, g2;
        System.out.println("Dimensions of the dungeon (Row x Column):");
        m = scan.nextInt();
        n = scan.nextInt();
        System.out.println("Position of adventurer:");
        a1 = scan.nextInt();
        a2 = scan.nextInt();
        System.out.println("Position of monster:");
        m1 = scan.nextInt();
        m2 = scan.nextInt();
        System.out.println("Position of gold:");
        g1 = scan.nextInt();
        g2 = scan.nextInt();

        String result = findMinSteps(m, n, a1 - 1, a2 - 1, m1 - 1, m2 - 1, g1 - 1, g2 - 1);

        System.out.println(result);
    }
}
