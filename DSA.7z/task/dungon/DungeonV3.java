import java.util.*;


public class DungeonV3 {

    static class Point {
       
		int row;
        int col;

        public Point(int row, int col) {
			this.row = row;
            this.col = col;
        }
    }

    public static int findMinimumStepsToGoldWithTrigger(int[][] dungeon, Point adventurer, Point monster, Point trigger, Point gold) {
        
		int rows = dungeon.length;
        int cols = dungeon[0].length;

        int stepsToTrigger = findMinimumStepsToGold(dungeon, adventurer, trigger);

        if (stepsToTrigger == -1) {
			return -1;
        }

        int stepsFromTriggerToGold = findMinimumStepsToGold(dungeon, trigger, gold);

        int stepsToMonsterFromTrigger = findMinimumStepsToGold(dungeon, trigger, monster);

        if (stepsToMonsterFromTrigger != -1) {
            int stepsToGoldAfterMonster = findMinimumStepsToGold(dungeon, monster, gold);
            if (stepsToGoldAfterMonster == -1) {
                return -1;
            }
            return stepsToTrigger + stepsToMonsterFromTrigger + stepsToGoldAfterMonster;
        }

        return stepsToTrigger + stepsFromTriggerToGold;
    }

    public static int findMinimumStepsToGold(int[][] dungeon, Point start, Point end) {
        
		int rows = dungeon.length;
        int cols = dungeon[0].length;
        boolean[][] visited = new boolean[rows][cols];
        Queue<Point> queue = new LinkedList<>();

        queue.add(start);
        visited[start.row][start.col] = true;

        int[] dRow = {-1, 1, 0, 0}; 
        int[] dCol = {0, 0, -1, 1};
        int steps = 0;

        while (!queue.isEmpty()) {
            int size = queue.size();

            while (size-- > 0) {
                Point current = queue.poll();
                int row = current.row;
                int col = current.col;

                if (row == end.row && col == end.col) {
                    return steps;
                }

                for (int i = 0; i < 4; i++) {
                    int newRow = row + dRow[i];
                    int newCol = col + dCol[i];

                    if (newRow >= 0 && newRow < rows && newCol >= 0 && newCol < cols && !visited[newRow][newCol] && dungeon[newRow][newCol] != -1) {
                        queue.add(new Point(newRow, newCol));
                        visited[newRow][newCol] = true;
                    }
                }
            }
            steps++;
        }

        return -1;
    }

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter dimensions of the dungeon (Row x Column):");

        int rows = scanner.nextInt();
        int cols = scanner.nextInt();

        int[][] dungeon = new int[rows][cols];

        System.out.println("Enter position of adventurer:");

        int advRow = scanner.nextInt() - 1; 
        int advCol = scanner.nextInt() - 1;

        System.out.println("Enter position of monster:");

        int monsterRow = scanner.nextInt() - 1; 
        int monsterCol = scanner.nextInt() - 1;

        System.out.println("Enter position of trigger:");

        int triggerRow = scanner.nextInt() - 1;
        int triggerCol = scanner.nextInt() - 1;

        System.out.println("Enter position of gold:");
		
		int goldRow = scanner.nextInt() - 1;
        int goldCol = scanner.nextInt() - 1;

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                dungeon[i][j] = 0; 
            }
        }
        dungeon[goldRow][goldCol] = 1;
        dungeon[monsterRow][monsterCol] = -1; 
        dungeon[triggerRow][triggerCol] = -2; 

        Point adventurer = new Point(advRow, advCol);
        Point monster = new Point(monsterRow, monsterCol);
        Point trigger = new Point(triggerRow, triggerCol);
        Point gold = new Point(goldRow, goldCol);

        int minSteps = findMinimumStepsToGoldWithTrigger(dungeon, adventurer, monster, trigger, gold);

        if (minSteps == -1) {
            System.out.println("No possible solution");
        } else {
            System.out.println("Minimum number of steps: " + minSteps);
        }
    }
}
