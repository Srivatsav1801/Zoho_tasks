import java.util.*;
class Min_path{
	public static void main(String[] args){
		int i,j,n,m;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number of rows in array");
		n = sc.nextInt();
		System.out.println("Enter number of col in array");
		m = sc.nextInt();
		
		int[][] array = new int[n][m];
		System.out.println("Enter the array elements:");
		for(i = 0;i<n;i++){
			for(j=0;j<m;j++){
				array[i][j] = sc.nextInt();
			}
			
		}
		System.out.println(minPath(array));
		
	}
	
	public static int minPath(int[][] array) {
        int m = array.length, n = array[0].length;
        int[] cur = new int[m];
        cur[0] = array[0][0];
        
        for (int i = 1; i < m; i++)
            cur[i] = cur[i - 1] + array[i][0];
        
        for (int j = 1; j < n; j++) {
            cur[0] += array[0][j];
            for (int i = 1; i < m; i++)
                cur[i] = Math.min(cur[i - 1], cur[i]) + array[i][j];
        }
        return cur[m - 1];
    }
}