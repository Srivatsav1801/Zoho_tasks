import java.util.*;
public class Candy {
	public static void main(String[] args){
		int n ;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of the array: ");
		n = sc.nextInt();
		int[] array = new int[n];
		for(int i = 0;i < n; i++){
			array[i] = sc.nextInt();
		}
		System.out.println(candy(array));
		
	}
	
    public static int candy(int[] A) {
        if (A.length == 0) {
            return 0;
        }
        int max = 1;
        int decStart = 0, incStart = 0;
        int candies = 1;
        for (int i = 1; i < A.length; i++) {
            if (A[i] == A[i - 1]) {
                decStart = i;
                incStart = i;
                max = 1;
                candies++;
            } else if (A[i] > A[i - 1]) {
                decStart = i;
                max = (i - incStart) + 1;
                candies += max;
            } else {
                incStart = i;
                int n = (i - decStart);
                if (n > max - 1) n++;
                candies += n;
            }
        }
        return candies;
    }
}

