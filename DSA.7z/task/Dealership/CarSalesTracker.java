import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class CarSalesTracker {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
		
        try {
            Scanner inventoryScanner = new Scanner(new File("inventory.txt"));

            int[] inventory = new int[12];
            for (int brand = 0; brand < 12; brand++) {
                inventory[brand] = inventoryScanner.nextInt();
            }

            Scanner salesScanner = new Scanner(new File("sales.txt"));

            int[] sales = new int[12];
            for (int brand = 0; brand < 12; brand++) {
                sales[brand] = salesScanner.nextInt();
                inventory[brand] -= sales[brand]; 
            }

            inventoryScanner.close();
            salesScanner.close();

            FileWriter writer = new FileWriter("inventory.txt");
            for (int brand = 0; brand < 12; brand++) {
                writer.write(inventory[brand] + "\n");
            }
            writer.close();

            FileWriter reportWriter = new FileWriter("report.txt");
            reportWriter.write("Daily Report:\n");
            for (int brand = 0; brand < 12; brand++) {
                int brandNo = brand + 1;
                reportWriter.write("\nBrand #: " + brandNo + "\n");
                reportWriter.write("----------\n");
                reportWriter.write("Inventory at day's start: " + (inventory[brand] + sales[brand]) + "\n");
                reportWriter.write("Total sales: " + sales[brand] + "\n");
                reportWriter.write("Inventory at day's end: " + inventory[brand] + "\n");
                double percentage = (double) sales[brand] / (inventory[brand] + sales[brand]) * 100;
                reportWriter.write("Sales as percentage of inventory: " + percentage + "\n");
            }
            System.out.println("Inventory updated successfully!");
            System.out.println("Report generated successfully!");

            reportWriter.close();
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
