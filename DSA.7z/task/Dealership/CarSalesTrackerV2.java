import java.io.*;
import java.time.LocalDate;
import java.util.Scanner;

public class CarSalesTrackerV2 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            System.out.print("Enter the file name for inventory and sales data: ");
            String fileName = scanner.next();
            Scanner fileScanner = new Scanner(new File(fileName));

            int[] inventory = new int[12];
            int[] sales = new int[12];
			String line = fileScanner.nextLine();
            while (fileScanner.hasNextLine()) {
                line = fileScanner.nextLine();
                String[] parts = line.split("\\s+");
                int brand = Integer.parseInt(parts[0]) - 1;
                inventory[brand] = Integer.parseInt(parts[1]);
                sales[brand] = Integer.parseInt(parts[2]);
            }

            fileScanner.close();

            for (int brand = 0; brand < 12; brand++) {
                inventory[brand] -= sales[brand];
            }

            LocalDate currentDate = LocalDate.now();
            String outputFileName = "input_" + currentDate + ".txt";
            FileWriter writer = new FileWriter(outputFileName);
			writer.write("car brand no.|No. Of cars in stock|No. Of cars sold");
            for (int brand = 0; brand < 12; brand++) {
                writer.write((brand + 1) + " " + inventory[brand] + " " + 0 + "\n");
            }
            writer.close();

            FileWriter reportWriter = new FileWriter("output.txt");
            reportWriter.write("Daily Report:\n");
            for (int brand = 0; brand < 12; brand++) {
                int brandNo = brand + 1;
                reportWriter.write("\nBrand #: " + brandNo + "\n");
                reportWriter.write("----------\n");
                reportWriter.write("Inventory at day's start: " + (inventory[brand] + sales[brand]) + "\n");
                reportWriter.write("Total sales: " + sales[brand] + "\n");
                reportWriter.write("Inventory at day's end: " + inventory[brand] + "\n");
                double percentage = (double) sales[brand] / (inventory[brand] + sales[brand]) * 100;
                reportWriter.write("Sales as percentage of inventory: " + percentage + "\n");
            }
            System.out.println("Inventory updated successfully!");
            System.out.println("Report generated successfully!");

            reportWriter.close();
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
