import java.io.*;
import java.util.*;
import java.util.regex.*;


public class Facebook{
    public static void clearScreen() {  
        try {
            new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        }
		catch(Exception e){
            System.out.println(e);
        }
    }  
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;
        boolean exit = false;

        while (!exit) {
            clearScreen();
            System.out.println("----------------------------------------------------");
            System.out.println("\t\tWELCOME TO FACEBOOK!!!\t\t");
            System.out.println("\n\nCreate a New Account Here!!! Press 1");
            System.out.println("\n\n\t\t\tAlready have an Account? Press 2 to Login\t");
            System.out.println("\t\t\tPress 2 to Login");
            System.out.println("\n\nPress 3 to Close the App");
            System.out.println("----------------------------------------------------");
            System.out.print("\n\n\nEnter Your Choice: ");
            choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1:
                    register();
                    break;
                case 2:
                    String currentUserUsername = login();
					if (currentUserUsername != null) {
						home(currentUserUsername);
					}
                    break;
                case 3:
                    System.out.println("Closing the app...");
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }
    }

    private static void register() {
        clearScreen();
        Scanner scanner = new Scanner(System.in);
        System.out.println("==========================================");
        System.out.println("SIGN UP");
        System.out.println("It's quick and easy.");
        System.out.println("==========================================");
        System.out.print("\nFirst Name: ");
        String firstName = scanner.nextLine();
        System.out.print("\nLast Name: ");
        String lastName = scanner.nextLine();

        String email;
        do {
            System.out.print("\nEmail: ");
            email = scanner.nextLine();
            if (!isValidEmail(email)) {
                System.out.println("Invalid email format. Please try again.");
            }
        } while (!isValidEmail(email));

        long mobileNumber;
        do {
            System.out.print("\nMobile Number: ");
            mobileNumber = scanner.nextLong();
            scanner.nextLine();
            if (!isValidMobileNumber(mobileNumber)) {
                System.out.println("Invalid mobile number format. Please try again.");
            }
        } while (!isValidMobileNumber(mobileNumber));

        String username;
        do {
            System.out.print("\nEnter a Username: ");
            username = scanner.nextLine();
            if (isUsernameTaken(username)) {
                System.out.println("Username already taken. Please choose another one.");
            }
        } while (isUsernameTaken(username));

        String password;
        do {
            System.out.print("\nCreate a Password (at least 8 characters, including letters and numbers): ");
            password = scanner.nextLine();
            if (!isValidPassword(password)) {
                System.out.println("Invalid password format. Please try again.");
            }
        } while (!isValidPassword(password));

        String gender;
        do {
            System.out.print("\nGender (Male/Female/Other): ");
            gender = scanner.nextLine().toLowerCase(); 
            if (!isValidGender(gender)) {
                System.out.println("Invalid gender. Please enter Male, Female, or Other.");
            }
        } while (!isValidGender(gender));

        String dateOfBirth;
        do {
            System.out.print("\nDate of Birth (YYYY-MM-DD): ");
            dateOfBirth = scanner.nextLine();
            if (!isValidDateOfBirth(dateOfBirth)) {
                System.out.println("Invalid date of birth format. Please enter in YYYY-MM-DD format.");
            }
        } while (!isValidDateOfBirth(dateOfBirth));

        saveUserData(firstName, lastName, email, mobileNumber, username, password, gender, dateOfBirth);
    }

    private static boolean isValidGender(String gender) {
        return gender.equals("male") || gender.equals("female") || gender.equals("other");
    }

    private static boolean isValidDateOfBirth(String dateOfBirth) {
        String dateRegex = "^\\d{4}-\\d{2}-\\d{2}$"; 
        return dateOfBirth.matches(dateRegex);
    }

    private static boolean isUsernameTaken(String username) {
        try (BufferedReader reader = new BufferedReader(new FileReader("userdata.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] userData = line.split(",");
                if (userData.length >= 5 && userData[4].equals(username)) {
                    return true;
                }
            }
        } catch (IOException e) {
            System.out.println("Error reading user data: " + e.getMessage());
        }
        return false;
    }

    private static void saveUserData(String firstName, String lastName, String email, long mobileNumber, String username, String password, String gender, String dateOfBirth) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("userdata.txt", true))) {
            writer.write(firstName + "," + lastName + "," + email + "," + mobileNumber + "," + username + "," + password + "," + gender + "," + dateOfBirth);
            writer.newLine();
        } catch (IOException e) {
            System.out.println("Error saving user data: " + e.getMessage());
        }
    }


    private static boolean isValidPassword(String password) {
        return password.length() >= 8 && password.matches(".*[a-zA-Z]+.*") && password.matches(".*\\d+.*");
    }

    private static boolean isValidEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        Pattern pattern = Pattern.compile(emailRegex);
        Matcher matcher = pattern.matcher(email);
        return matcher.matches();
    }

    private static boolean isValidMobileNumber(long mobileNumber) {
		String mobileNumberRegex = "^[6-9][0-9]{9}$";
		return String.valueOf(mobileNumber).matches(mobileNumberRegex);
	}

	private static String login() {
		clearScreen();
		Scanner scanner = new Scanner(System.in);
		System.out.println("\t\t\t\t\t-----------------------------------\t\t\t\t\t\t");
		System.out.println("\t\t\t\t\t\tFACEBOOK LOGIN\t\t\t\t\t");
		System.out.println("\t\t\t\t\t-----------------------------------\t\t\t\t\t\t");
		System.out.print("\n\t\t\tUsername: ");
		String username = scanner.nextLine();
		System.out.print("\n\t\t\tPassword: ");
		String password = scanner.nextLine();

		if (validateCredentials(username, password)) {
			return username;
		} else {
			System.out.println("\n\t\t\tInvalid username or password. Please try again.");
			System.out.println("\n\t\t\tPress Enter to return to the main menu...");
			scanner.nextLine();
			return null;
		}
	}
	
	private static boolean validateCredentials(String username, String password) {
		try (BufferedReader reader = new BufferedReader(new FileReader("userdata.txt"))) {
			String line;
			while ((line = reader.readLine()) != null) {
				String[] userData = line.split(",");
				if (userData.length >= 6 && userData[4].equals(username) && userData[5].equals(password)) {
					return true;
				}
			}
		} catch (IOException e) {
			System.out.println("Error reading user data: " + e.getMessage());
		}
		return false;
	}

	
	private static void home(String currentUserUsername){
		int choice;
		boolean exit = false;
		while (!exit) {
			clearScreen();
			Scanner scanner = new Scanner(System.in);
			System.out.println("\t\t\t\t\t-------------------------------\t\t\t\t\t\t");
			System.out.println("\t\t\t\t\t\tWhats on your mind?\t\t\t\t\t\t");
			System.out.println("\t\t\t\t\t-------------------------------\t\t\t\t\t\t");
			System.out.println("\t\t\t1.Send Friend Request\t\t\t\t\t\t");
			System.out.println("\t\t\t2.Show Friend List\t\t\t\t\t\t");
			System.out.println("\t\t\t3.Show Pending Request\t\t\t\t\t\t");
			System.out.println("\t\t\t4.Remove Friend\t\t\t\t\t\t");
			System.out.println("\t\t\t5.Search\t\t\t\t\t\t");
			System.out.println("\t\t\t6.Your Profile\t\t\t\t\t\t");
			System.out.println("\t\t\t\t\t\t\t\t\t\t\t7.Logout");
			choice = scanner.nextInt();
			switch (choice) {
					case 1:
						sendFriendRequest(currentUserUsername);
						break;
					case 2:
						friend_list(currentUserUsername);
						break;
					case 3:
						friend_req_pending(currentUserUsername); 
						break;
					case 4:
						removeFriend(currentUserUsername);
						break;
					case 5:
						search(currentUserUsername);
						break;
					case 6:
						profile(currentUserUsername);
						break;
					case 7:
						System.out.println("Closing the app...");
						exit = true;
						break;
					default:
						System.out.println("Invalid choice. Please try again.");
						break;
				}
		}
	}
	
	private static void sendFriendRequest(String senderUsername) {
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter the username of the person you want to send a friend request to: ");
		String receiverUsername = scanner.nextLine();

		if (isUsernameTaken(receiverUsername)) {
			if (!senderUsername.equals(receiverUsername)) {
				try (BufferedWriter writer = new BufferedWriter(new FileWriter("friendrequests.txt", true))) {
					writer.write(senderUsername + "," + receiverUsername);
					writer.newLine();
					System.out.println("Friend request sent to " + receiverUsername);
				} catch (IOException e) {
					System.out.println("Error sending friend request: " + e.getMessage());
				}
			} else {
				System.out.println("You cannot send a friend request to yourself.");
			}
		} else {
			System.out.println("User with username '" + receiverUsername + "' does not exist.");
		}
	}
	
	private static void friend_list(String currentUserUsername) {
		clearScreen();		
		System.out.println("\t\t\t\t\t-------------------------------\t\t\t\t\t\t");
		System.out.println("\t\t\t\t\t\tFriend List\t\t\t\t\t\t");
		System.out.println("\t\t\t\t\t-------------------------------\t\t\t\t\t\t");
		Scanner scanner = new Scanner(System.in);
		try (BufferedReader reader = new BufferedReader(new FileReader("friendlist.txt"))) {
			String line;
			System.out.println("Friend List:");
			while ((line = reader.readLine()) != null) {
				String[] data = line.split(",");
				if (data[0].equals(currentUserUsername)) {
					System.out.println(data[1]);
				}
			}
			System.out.println("press any key......");
			scanner.nextLine();
		} catch (IOException e) {
			System.out.println("Error reading friend list: " + e.getMessage());
		}
	}
	
	private static void friend_req_pending(String currentUserUsername) {
		Scanner scanner = new Scanner(System.in);
		clearScreen();		
		System.out.println("\t\t\t\t\t-------------------------------\t\t\t\t\t\t");
		System.out.println("\t\t\t\t\t\tFriend Request Pending\t\t\t\t\t\t");
		System.out.println("\t\t\t\t\t-------------------------------\t\t\t\t\t\t");
		try (BufferedReader reader = new BufferedReader(new FileReader("friendrequests.txt"))) {
			String line;
			List<String> requests = new ArrayList<>();
			while ((line = reader.readLine()) != null) {
				String[] data = line.split(",");
				if (data[1].equals(currentUserUsername)) {
					requests.add(data[0]);
				}
			}
			if (requests.isEmpty()) {
				System.out.println("No pending friend requests.");
				System.out.println("Press any key to continue...");
				scanner.nextLine();
				
				return;
			}
			
			for (String request : requests) {
				System.out.println("You have a friend request from: " + request);
				System.out.print("Do you want to accept this friend request? (yes/no): ");
				String choice = scanner.nextLine();
				if (choice.equalsIgnoreCase("yes")) {
					acceptFriendRequest(currentUserUsername, request);
				} else if (choice.equalsIgnoreCase("no")) {
					System.out.println("Friend request from " + request + " rejected.");
				} else {
					System.out.println("Invalid choice. Please enter 'yes' or 'no'.");
				}
			}
		} catch (IOException e) {
			System.out.println("Error reading pending friend requests: " + e.getMessage());
		}
	}

	private static void acceptFriendRequest(String currentUserUsername, String senderUsername) {
		try {
			List<String> lines = new ArrayList<>();
			File file = new File("friendrequests.txt");
			BufferedReader reader = new BufferedReader(new FileReader(file));
			String line;
			while ((line = reader.readLine()) != null) {
				String[] data = line.split(",");
				if (!(data[0].equals(senderUsername) && data[1].equals(currentUserUsername))) {
					lines.add(line);
				}
			}
			reader.close();

			BufferedWriter writer = new BufferedWriter(new FileWriter(file));
			for (String newLine : lines) {
				writer.write(newLine);
				writer.newLine();
			}
			writer.close();
			
			BufferedWriter friendListWriter = new BufferedWriter(new FileWriter("friendlist.txt", true));
			friendListWriter.write(currentUserUsername + "," + senderUsername);
			friendListWriter.newLine();
			friendListWriter.write(senderUsername + "," + currentUserUsername);
			friendListWriter.newLine();
			friendListWriter.close();
			
			System.out.println("Friend request from " + senderUsername + " accepted.");
		} catch (IOException e) {
			System.out.println("Error accepting friend request: " + e.getMessage());
		}
	}

	
	
	private static void removeFriend(String currentUserUsername) {
		Scanner scanner = new Scanner(System.in);
		clearScreen();		
		System.out.println("\t\t\t\t\t-------------------------------\t\t\t\t\t\t");
		System.out.println("\t\t\t\t\t\t\t\tRemove Friend\t\t\t\t\t\t");
		System.out.println("\t\t\t\t\t-------------------------------\t\t\t\t\t\t");
		friend_list(currentUserUsername);
		System.out.print("Enter the username of the friend you want to remove: ");
		String friendUsername = scanner.nextLine();

		try {
			List<String> lines = new ArrayList<>();
			File file = new File("friendlist.txt");
			BufferedReader reader = new BufferedReader(new FileReader(file));
			String line;
			boolean found = false;
			while ((line = reader.readLine()) != null) {
				String[] data = line.split(",");
				if ((data[0].equals(currentUserUsername) && data[1].equals(friendUsername)) || (data[0].equals(friendUsername) && data[1].equals(currentUserUsername))) {
					found = true;
				} else {
					lines.add(line);
				}
			}
			reader.close();

			if (!found) {
				System.out.println("Friend not found.");
				return;
			}
			else{
				clearScreen();
				System.out.println("Friend found");
				System.out.println("Press any key to remove");
				scanner.nextLine();
			}

			BufferedWriter writer = new BufferedWriter(new FileWriter(file));
			for (String newLine : lines) {
				writer.write(newLine);
				writer.newLine();
			}
			writer.close();
			clearScreen();
			System.out.println("\t\t\t\t\t-------------------------------\t\t\t\t\t\t");
			System.out.println("\t\t\t\t\t\tFriendship with " + friendUsername + " removed Successfully.");
			System.out.println("\t\t\t\t\t-------------------------------\t\t\t\t\t\t");	
			System.out.println("Press any key to remove");
			scanner.nextLine();
			
		} catch (IOException e) {
			System.out.println("Error removing friend: " + e.getMessage());
		}
	}
	

	
	private static void search(String currentUserUsername) {
		Scanner scanner = new Scanner(System.in);
		clearScreen();		
		System.out.println("\t\t\t\t\t-------------------------------\t\t\t\t\t\t");
		System.out.println("\t\t\t\t\t\tSearch People\t\t\t\t\t\t");
		System.out.println("\t\t\t\t\t-------------------------------\t\t\t\t\t\t");
		System.out.print("Enter the username you want to search for: ");
		String searchUsername = scanner.nextLine();

		try (BufferedReader reader = new BufferedReader(new FileReader("userdata.txt"))) {
			String line;
			boolean userFound = false;
			while ((line = reader.readLine()) != null) {
				String[] userData = line.split(",");
				if (userData.length >= 5 && userData[4].equals(searchUsername)) {
					userFound = true;
					System.out.println("User found:");
					System.out.println("\t\t\t\t\tFirst Name: " + userData[0]);
					System.out.println("\t\t\t\t\tLast Name: " + userData[1]);
					System.out.println("\t\t\t\t\tEmail: " + userData[2]);
					System.out.println("\t\t\t\t\tMobile Number: " + userData[3]);
					System.out.println("\t\t\t\t\tGender: " + userData[6]);
					System.out.println("\t\t\t\t\tDate of Birth: " + userData[7]);
					System.out.println("Press any key to go back...");
					scanner.nextLine();
					break;
				}
				
			}
			if (!userFound) {
				System.out.println("\t\t\t\t\t-------------------------------\t\t\t\t\t\t");
				System.out.println("\t\t\t\t\t\tUser profile not found\t\t\t\t\t\t");
				System.out.println("\t\t\t\t\t-------------------------------\t\t\t\t\t\t");
				System.out.println("Press any key to go back...");
				scanner.nextLine();
			}
		} catch (IOException e) {
			System.out.println("Error searching for user: " + e.getMessage());
		}
	}
	
	private static void profile(String currentUserUsername) {
		clearScreen();
		Scanner scanner = new Scanner(System.in);
		try (BufferedReader reader = new BufferedReader(new FileReader("userdata.txt"))) {
			String line;
			boolean userFound = false;
			List<String> updatedUserData = new ArrayList<>();
			while ((line = reader.readLine()) != null) {
				String[] userData = line.split(",");
				if (userData.length >= 5 && userData[4].equals(currentUserUsername)) {
					userFound = true;
					System.out.println("\t\t\t\t\t-------------------------------\t\t\t\t\t\t");
					System.out.println("\t\t\t\t\t\tUser Profile\t\t\t\t\t\t");
					System.out.println("\t\t\t\t\t-------------------------------\t\t\t\t\t\t");
					System.out.println("\t\t\t\t\tFirst Name: " + userData[0]);
					System.out.println("\t\t\t\t\tLast Name: " + userData[1]);
					System.out.println("\t\t\t\t\tEmail: " + userData[2]);
					System.out.println("\t\t\t\t\tMobile Number: " + userData[3]);
					System.out.println("\t\t\t\t\tGender: " + userData[6]);
					System.out.println("\t\t\t\t\tDate of Birth: " + userData[7]);
					System.out.println("\t\t\t\t\t-------------------------------\t\t\t\t\t\t");
					System.out.println("\t\t\t\t\t1. Edit First Name");
					System.out.println("\t\t\t\t\t2. Edit Last Name");
					System.out.println("\t\t\t\t\t3. Edit Email");
					System.out.println("\t\t\t\t\t4. Edit Mobile Number");
					System.out.println("\t\t\t\t\t5. Edit Gender");
					System.out.println("\t\t\t\t\t6. Edit Date of Birth");
					System.out.println("\t\t\t\t\t7. Change Password");
					System.out.println("\t\t\t\t\t8. Go Back");
					System.out.print("\t\t\t\t\tEnter your choice: ");
					int choice = scanner.nextInt();
					scanner.nextLine();
					
					switch (choice) {
						case 1:
							System.out.print("Enter new First Name: ");
							String newFirstName = scanner.nextLine();
							userData[0] = newFirstName;
							break;
						case 2:
							System.out.print("Enter new Last Name: ");
							String newLastName = scanner.nextLine();
							userData[1] = newLastName;
							break;
						case 3:
							System.out.print("Enter new Email: ");
							String newEmail = scanner.nextLine();
							userData[2] = newEmail;
							break;
						case 4:
							long newMobileNumber;
							do {
								System.out.print("Enter new Mobile Number: ");
								newMobileNumber = scanner.nextLong();
								scanner.nextLine(); 
								if (!isValidMobileNumber(newMobileNumber)) {
									System.out.println("Invalid mobile number format. Please try again.");
								}
							} while (!isValidMobileNumber(newMobileNumber));
							userData[3] = String.valueOf(newMobileNumber);
							break;
						case 5:
							String newGender;
							do {
								System.out.print("Enter new Gender (Male/Female/Other): ");
								newGender = scanner.nextLine().toLowerCase();
								if (!isValidGender(newGender)) {
									System.out.println("Invalid gender. Please enter Male, Female, or Other.");
								}
							} while (!isValidGender(newGender));
							userData[6] = newGender;
							break;
						case 6:
							String newDateOfBirth;
							do {
								System.out.print("Enter new Date of Birth (YYYY-MM-DD): ");
								newDateOfBirth = scanner.nextLine();
								if (!isValidDateOfBirth(newDateOfBirth)) {
									System.out.println("Invalid date of birth format. Please enter in YYYY-MM-DD format.");
								}
							} while (!isValidDateOfBirth(newDateOfBirth));
							userData[7] = newDateOfBirth;
							break;
						case 7:
							String newPassword;
							do {
								System.out.print("Enter new Password (at least 8 characters, including letters and numbers): ");
								newPassword = scanner.nextLine();
								if (!isValidPassword(newPassword)) {
									System.out.println("Invalid password format. Please try again.");
								}
							} while (!isValidPassword(newPassword));
							userData[5] = newPassword;
							break;
						case 8:
							return;
						default:
							System.out.println("Invalid choice. Please try again.");
							break;
					}
					updatedUserData.add(String.join(",", userData));
				} else {
					updatedUserData.add(line);
				}
			}
			if (!userFound) {
				System.out.println("\t\t\t\t\t-------------------------------\t\t\t\t\t\t");
				System.out.println("\t\t\t\t\t\tUser profile not found\t\t\t\t\t\t");
				System.out.println("\t\t\t\t\t-------------------------------\t\t\t\t\t\t");
				System.out.println("Press any key to go back...");
				scanner.nextLine();
				return;
			}

			try (BufferedWriter writer = new BufferedWriter(new FileWriter("userdata.txt"))) {
				for (String userData : updatedUserData) {
					writer.write(userData);
					writer.newLine();
				}
				System.out.println("Profile updated successfully.");
				System.out.println("Press any key to go back...");
				scanner.nextLine();
			} catch (IOException e) {
				System.out.println("Error updating user data: " + e.getMessage());
			}
		} catch (IOException e) {
			System.out.println("Error fetching user profile: " + e.getMessage());
		}
	}

}
