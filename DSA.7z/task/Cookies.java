public class Cookies {
	public static void main(String[] args){
		int n ,m ,i;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of the greed factor array: ");
		n = sc.nextInt();
		System.out.println("Enter the size of the children array: ");
		m = sc.nextInt();
		System.out.println("Enter the greed factor array: ");
		int[] g = new int[n];
		int[] s = new int[m];
		for(i = 0;i < n; i++){
			g[i] = sc.nextInt();
		}
		System.out.println("Enter the children array: ");
		for(j = 0;j < n; j++){
			s[j] = sc.nextInt();
		}
		System.out.println(cal(g,s));
		
	}
	
    public int cal(int[] g, int[] s) {
        Arrays.sort(g);
        Arrays.sort(s);
        
        int j = 0;
        for (int i = 0; j < g.length && i < s.length; i ++) {
            if (s[i] >= g[j]) {
                j ++;
            }
        }
        
        return j;
    }
}