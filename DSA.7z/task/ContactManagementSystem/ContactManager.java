import java.io.*;
import java.util.*;
import java.text.SimpleDateFormat;
import java.util.regex.*;

class Contact {
		private String contactName;
		private String mobileNumber;
		private String companyNumber;
		private String companyName; 
		private String emailId;

		public Contact(String contactName, String mobileNumber, String emailId) {
			this.contactName = contactName;
			this.mobileNumber = mobileNumber;
			this.emailId = emailId;
		}
		
		public String getContactName() {
        return contactName;
		}

		public void setContactName(String contactName) {
			this.contactName = contactName;
		}

		public String getMobileNumber() {
			return mobileNumber;
		}

		public void setMobileNumber(String mobileNumber) {
			this.mobileNumber = mobileNumber;
		}

		public String getEmailId() {
			return emailId;
		}

		public void setEmailId(String emailId) {
			this.emailId = emailId;
		}
		
		public String getCompanyNumber() {
        return companyNumber;
		}

		public void setCompanyNumber(String companyNumber) {
			this.companyNumber = companyNumber;
		}

		public String getCompanyName() {
			return companyName;
		}

		public void setCompanyName(String companyName) {
			this.companyName = companyName;
		}
	}

public class ContactManager {
		private static final Pattern Mobile_number_pattern = Pattern.compile("^[6-9]\\d{9}$");
		private static final Pattern email_pattern = Pattern.compile("^[\\w.-]+@[\\w.-]+$");

		public static void createContact(Map<String, Contact> contacts) {
			Scanner scanner = new Scanner(System.in);

			System.out.println("Do you want to create a new contact or use an existing one? (new/existing): ");
			String choice = scanner.nextLine().toLowerCase();

			if (choice.equals("new")) {
				System.out.println("Enter first name: ");
				String firstName = scanner.nextLine();
				System.out.println("Enter last name: ");
				String lastName = scanner.nextLine();
				String contactName = createContactName(firstName, lastName);
				System.out.println("Enter mobile number: ");
				String mobileNumber = scanner.nextLine();
				validateMobileNumber(mobileNumber);
				System.out.println("Enter email address: ");
				String emailId = scanner.nextLine();
				if (!validateEmail(emailId)) {
					emailId = ""; 
				}
				contacts.put(contactName, new Contact(contactName, mobileNumber, emailId));
				System.out.println("Contact '" + contactName + "' created successfully!");
				System.out.println("Press any key to continue...");
				scanner.nextLine();
			} else if (choice.equals("existing")) {
				System.out.println("Enter existing contact name: ");
				String contactName = scanner.nextLine();
				if (contacts.containsKey(contactName)) {
					System.out.println("Enter second mobile number: ");
					String mobileNumber = scanner.nextLine();
					validateMobileNumber(mobileNumber);
					System.out.println("Is the second number a company number? (yes/no): ");
					String isCompanyNumber = scanner.nextLine().toLowerCase();
					if (isCompanyNumber.equals("yes")) { 
						System.out.println("Enter company name: ");
						String companyName = scanner.nextLine();
						System.out.println("Enter company number: ");
						String companyNumber = mobileNumber;
						validateMobileNumber(companyNumber);
						contacts.get(contactName).setCompanyName(companyName);
						contacts.get(contactName).setCompanyNumber(companyNumber);
						System.out.println("Company number added to contact '" + contactName + "' successfully!");
						System.out.println("Press any key to continue...");
						scanner.nextLine();
					}
					else{
						contacts.get(contactName).setMobileNumber(contacts.get(contactName).getMobileNumber() + " " + mobileNumber);
						System.out.println("Second mobile number added to contact '" + contactName + "' successfully!");
						System.out.println("Press any key to continue...");
						scanner.nextLine();
					}
				} else {
					System.out.println("Contact does not exist.");
					System.out.println("Press any key to continue...");
					scanner.nextLine();
				}
			} else {
				System.out.println("Invalid choice.");
				System.out.println("Press any key to continue...");
				scanner.nextLine();
			}
		}
		
		public static void addDummyContacts(Map<String, Contact> contacts) {
			Contact contact1 = new Contact("Rahul", "9845234456", "rahul@gmail.com");
			Contact contact2 = new Contact("Sakthi", "9876543210", "sakthi@yahoo.com");
			Contact contact3 = new Contact("Kishan", "9658439234", "kishan@gmail.com");

			contacts.put(contact1.getContactName(), contact1);
			contacts.put(contact2.getContactName(), contact2);
			contacts.put(contact3.getContactName(), contact3);
		}

		public static String createContactName(String firstName, String lastName) {
			String[] names = (firstName + " " + lastName).split(" ");
			StringBuilder contactNameBuilder = new StringBuilder();
			for (String name : names) {
				contactNameBuilder.append(name.substring(0, 1).toUpperCase()).append(name.substring(1).toLowerCase());
			}
			return contactNameBuilder.toString();
		}

		public static void validateMobileNumber(String mobileNumber) {
			if (!Mobile_number_pattern.matcher(mobileNumber).matches()) {
				throw new IllegalArgumentException("Invalid mobile number. Please enter a 10-digit number starting with 6, 7, 8, or 9.");
			}
		}

		public static boolean validateEmail(String email) {
			if (!email.isEmpty()) {
				return email_pattern.matcher(email).matches();
			}
			return true; 
		}

		public static void clearScreen() {  
			try {
				new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
			}
			catch(Exception e){
				System.out.println(e);
			}
		}
		private static final SimpleDateFormat TIME_FORMAT = new SimpleDateFormat("mm:ss");
		public static void callContact(Map<String, Contact> contacts) {
			Scanner scanner = new Scanner(System.in);

			System.out.println("Enter the mobile number you want to call: ");
			String mobileNumber = scanner.nextLine();

			if (contacts.containsValue(mobileNumber)) {
				String contactName = getContactNameByNumber(contacts, mobileNumber);
				System.out.println("Speaking to the contact name: " + contactName);
			} else {
				System.out.println("Speaking to the contact number: " + mobileNumber);
			}

			System.out.println("Call duration:");
			long startTime = System.currentTimeMillis();
			while (true) {
				try {
					long currentTime = System.currentTimeMillis();
					long elapsedTime = currentTime - startTime;
					System.out.println(TIME_FORMAT.format(new Date(elapsedTime)));
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					long endTime = System.currentTimeMillis();
					long callDuration = endTime - startTime;
					System.out.println("Call duration is " + TIME_FORMAT.format(new Date(callDuration)));
					break;
				}
			}
		}

		public static String getContactNameByNumber(Map<String, Contact> contacts, String mobileNumber) {
			for (Contact contact : contacts.values()) {
				if (contact.getMobileNumber().equals(mobileNumber)) {
					return contact.getContactName();
				}
			}
			return mobileNumber;
		}

		
		public static void editContactDetails(Map<String, Contact> contacts) {
			Scanner scanner = new Scanner(System.in);

			System.out.println("Enter the contact name you want to edit: ");
			String contactName = scanner.next();

			if (contacts.containsKey(contactName)) {
				System.out.println("Enter the new mobile number: ");
				String newMobileNumber = scanner.next();
				contacts.get(contactName).setMobileNumber(newMobileNumber);
				Contact contact = contacts.get(contactName);
				if (contact.getCompanyName() != null && !contact.getCompanyName().isEmpty() &&
					contact.getCompanyNumber() != null && !contact.getCompanyNumber().isEmpty()) {
					System.out.println("Do you want to edit company details? (yes/no): ");
					String editCompany = scanner.nextLine().toLowerCase();
					if (editCompany.equals("yes")) {
						System.out.println("Enter the new company name: ");
						String newCompanyName = scanner.nextLine();
						System.out.println("Enter the new company number: ");
						String newCompanyNumber = scanner.nextLine();
						contacts.get(contactName).setCompanyName(newCompanyName);
						contacts.get(contactName).setCompanyNumber(newCompanyNumber);
					}
				}

				System.out.println("Contact details updated successfully.");
				System.out.println("Updated contact details:");
				System.out.println("Press any key to continue...");
				scanner.nextLine();
				displayContacts(contacts);
			} else {
				System.out.println("Contact does not exist.");
				System.out.println("Press any key to continue...");
				scanner.nextLine();
			}
		}

		
		public static void deleteNumber(Map<String, Contact> contacts) {
			Scanner scanner = new Scanner(System.in);

			System.out.println("Enter the contact name whose number you want to delete: ");
			String contactName = scanner.nextLine();

			if (contacts.containsKey(contactName)) {
				Contact contact = contacts.get(contactName);
				System.out.println("Current mobile number(s): " + contact.getMobileNumber());
				if (contact.getCompanyName() != null && !contact.getCompanyName().isEmpty() &&
					contact.getCompanyNumber() != null && !contact.getCompanyNumber().isEmpty()) {
					System.out.println("Current company number: " + contact.getCompanyNumber());
				}
				System.out.println("Enter the number you want to delete: ");
				String numberToDelete = scanner.nextLine();

				if (contact.getMobileNumber().equals(numberToDelete) || 
					(contact.getCompanyNumber() != null && contact.getCompanyNumber().equals(numberToDelete))) {
					System.out.println("Do you want to delete the contact? (yes/no): ");
					String confirm = scanner.nextLine();
					if (confirm.equals("yes")) {
						contacts.remove(contactName);
						System.out.println(contactName + " deleted.");
					} else {
						System.out.println("Contact not deleted.");
					}
				} else {
					String[] mobileNumbers = contact.getMobileNumber().split(" ");
					boolean found = false;
					for (int i = 1; i < mobileNumbers.length; i++) {
						if (mobileNumbers[i].equals(numberToDelete)) {
							mobileNumbers[i] = "";
							System.out.println("Number deleted.");
							contact.setMobileNumber(String.join(" ", mobileNumbers));
							found = true;
							break;
						}
					}
					if (!found && contact.getCompanyNumber() != null && contact.getCompanyNumber().equals(numberToDelete)) {
						contact.setCompanyNumber("");
						System.out.println("Company number deleted.");
						found = true;
					}
					if (!found) {
						System.out.println("Number not found.");
					}
				}
			} else {
				System.out.println("Contact does not exist.");
			}
			System.out.println("Press any key to continue...");
			scanner.nextLine();
			displayContacts(contacts);
		}

		
		public static void displayContacts(Map<String, Contact> contacts) {
			Scanner scanner = new Scanner(System.in);
			for (Map.Entry<String, Contact> entry : contacts.entrySet()) {
				System.out.println("Contact Name: " + entry.getKey());
				Contact contact = entry.getValue();
				System.out.println("Mobile Number(s): " + contact.getMobileNumber());
				if (contact.getCompanyName() != null && !contact.getCompanyName().isEmpty() &&
					contact.getCompanyNumber() != null && !contact.getCompanyNumber().isEmpty()) {
					System.out.println("Company Name: " + contact.getCompanyName());
					System.out.println("Company Number: " + contact.getCompanyNumber());
				}
				System.out.println("Email: " + contact.getEmailId());
				System.out.println();
			}
			System.out.println("Press any key to continue...");
			scanner.nextLine();
		}

		public static void displayAllContacts(Map<String, Contact> contacts) {
			System.out.println("All Contacts:");
			displayContacts(contacts);
		}

		
		public static void searchContact(Map<String, Contact> contacts) {
			Scanner scanner = new Scanner(System.in);

			System.out.println("Enter the contact name or mobile number to search: ");
			String searchString = scanner.nextLine().toLowerCase();

			boolean found = false;

			for (Map.Entry<String, Contact> entry : contacts.entrySet()) {
				Contact contact = entry.getValue();
				String contactName = contact.getContactName().toLowerCase();
				String mobileNumber = contact.getMobileNumber();

				if (contactName.contains(searchString) || mobileNumber.contains(searchString)) {
					System.out.println("Contact Name: " + contact.getContactName());
					System.out.println("Mobile Number: " + contact.getMobileNumber());
					System.out.println("Email: " + contact.getEmailId());
					found = true;
				}
				System.out.println("Press any key to continue...");
				scanner.nextLine();
			}

			if (!found) {
				System.out.println("No contact found matching the search criteria.");
				System.out.println("Press any key to continue...");
				scanner.nextLine();
			}
		}

		
		
		public static void main(String[] args) {
			Map<String, Contact> contacts = new HashMap<>();
			addDummyContacts(contacts);
			Scanner scanner = new Scanner(System.in);
			boolean exit = false;
			while (!exit) {
				clearScreen();
				System.out.println("Choose from following option:");
				System.out.println("a) call,\nb) create contact,\nc) search contact,\nd) delete contact,\ne) update contact,\nf) block a number,\ng) call history,\nh) display the contacts\ni)exit");
				System.out.print("Enter your choice: ");
				char choice = scanner.next().charAt(0);
				switch (choice) {
					case 'a':
						clearScreen();
						System.out.print("call\n");
						callContact(contacts);
						System.out.println("Press any key to continue...");
						scanner.nextLine();
						break;
					
					case 'b':
						clearScreen();
						System.out.print("create contact\n");
						createContact(contacts);
						System.out.println("Press any key to continue...");
						scanner.nextLine();
						break;
					
					case 'c':
						clearScreen();
						System.out.print("search contact\n");
						searchContact(contacts);
						System.out.println("Press any key to continue...");
						scanner.nextLine();
						break;
					
					case 'd':
						clearScreen();
						System.out.print("delete contact\n");
						deleteNumber(contacts);
						System.out.println("Press any key to continue...");
						scanner.nextLine();
						break;
					
					case 'e':
						clearScreen();
						System.out.print("update contact\n");
						editContactDetails(contacts);
						System.out.println("Press any key to continue...");
						scanner.nextLine();
						break;
					
					case 'f':
						clearScreen();
						System.out.print("block a number\n");
						System.out.println("Press any key to continue...");
						scanner.nextLine();
						break;
					
					case 'g':
						clearScreen();
						System.out.print("call history\n");
						System.out.println("Press any key to continue...");
						scanner.nextLine();
						break;
					
					case 'h':
						clearScreen();
						System.out.print("display the contacts\n");
						displayAllContacts(contacts);
						System.out.println("Press any key to continue...");
						scanner.nextLine();
						break;

					case 'i':
						clearScreen();
						System.out.println("Closing the app...");
						System.out.println("Press any key to continue...");
						scanner.nextLine();
						exit = true;
						break;

					default:
						System.out.println("Invalid choice.");
						System.out.println("Press any key to continue...");
						scanner.nextLine();
				}

			}
		}
	}
