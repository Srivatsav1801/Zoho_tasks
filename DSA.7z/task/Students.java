import java.io.*;

class Student implements Serializable {
    private static final long serialVersionUID = 1L;
    private String name;
    private int age;
    private String department;

    public Student(String name, int age, String department) {
        this.name = name;
        this.age = age;
        this.department = department;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getDepartment() {
        return department;
    }
}

public class Students {
    public static void main(String[] args) {
        Student student = new Student("Sri", 23, "Mechanical Engineering");

        serializeStudent(student);

        Student deserialized_Student = deserializeStudent();

		System.out.println("Deserialized Student:");
		System.out.println("Name: " + deserialized_Student.getName());
		System.out.println("Age: " + deserialized_Student.getAge());
		System.out.println("Department: " + deserialized_Student.getDepartment());
        
    }

    private static void serializeStudent(Student student) {
        try {
            FileOutputStream fileOut = new FileOutputStream("student.ser");
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject(student);
            out.close();
            fileOut.close();
            System.out.println("Student object has been serialized to student.ser");
        } catch(IOException e){
            System.out.println(e);
        }
    }

    private static Student deserializeStudent() {
        try {
            FileInputStream fileIn = new FileInputStream("student.ser");
            ObjectInputStream in = new ObjectInputStream(fileIn);
            Student student = (Student) in.readObject();
            in.close();
            fileIn.close();
            System.out.println("Student object has been deserialized from student.ser");
            return student;
        } catch(IOException | ClassNotFoundException e) {
            System.out.println(e);
            return null;
        }
    }
}
