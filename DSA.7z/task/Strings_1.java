import java.util.*;
class Strings_1{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Size of the character array");
		int n = sc.nextInt();
		char[] letters = new char[n];
		System.out.println("Enter the array elements: ");
		for(int i =0;i<n;i++){
			letters[i] = sc.next().charAt(0);
		}
		System.out.println("Before");
		for(int i =0;i<n;i++){
			System.out.print(letters[i]+" ");
		}
		reverseString(letters);
		System.out.println("\nAfter");
		for(int i =0;i<n;i++){
			System.out.print(letters[i]+" ");
		}

	}
    public static void reverseString(char[] s) {
        int i = 0;
        int j = s.length - 1;
        
        while(i <= j){
            char temp = s[i];
            s[i] = s[j];
            s[j] = temp;
            i++;
            j--;
        }
    }
}



