import java.util.*;
class Profit {
	public static void main(String[] args){
		int i,n;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of the price array");
		n = sc.nextInt();
		int[] prices = new int[n];
		System.out.println("Enter the prices:");
		for(i = 0;i<n;i++){
			prices[i] = sc.nextInt();
		}
		System.out.println("Max Profit: "+maxProfit(0,prices,false));
		
	}
	
    static int maxProfit(int idx, int[] prices, boolean canSell)
    {
        
        if (idx == prices.length)
            return 0;
        if (canSell) {
            
            return Math.max(
                prices[idx],
                maxProfit(idx + 1, prices, canSell));
        }
        else {
            
            return Math.max(
                -prices[idx]
                    + maxProfit(idx + 1, prices, true),
                maxProfit(idx + 1, prices, canSell));
        }
    }
}