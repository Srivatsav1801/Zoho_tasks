import java.util.Scanner;

public class Red_and_green{

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int n = scanner.nextInt();
        scanner.nextLine(); 

        char[][] grid = new char[n][n];
        for (int i = 0; i < n; i++) {
            String row = scanner.nextLine();
            for (int j = 0; j < n; j++) {
                grid[i][j] = row.charAt(j);
            }
        }

        int redAboveDiagonal = 0;
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                if (grid[i][j] == 'R') {
                    redAboveDiagonal++;
                }
            }
        }

        if (redAboveDiagonal > n * (n - 1) / 2) {
            System.out.println(-1); 
        } else {
            int moves = 0;
            for (int i = n - 1; i >= 0; i--) {
                if (redAboveDiagonal == 0) {
                    break;
                }
                moves++;
                for (int j = 0; j < i; j++) {
                    if (grid[j][i] == 'R') {
                        redAboveDiagonal--;
                    }
                }
            }
            System.out.println(moves);
        }
    }
}
