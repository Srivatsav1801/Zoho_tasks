import java.util.*;

class Astroid {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the number of asteroids: ");
        int n = scanner.nextInt();
		int count = n;
        int[] asteroids = new int[n];
        System.out.println("Enter the weights of the asteroids: ");
        for (int i = 0; i < n; i++) {
            asteroids[i] = scanner.nextInt();
        }
        while (count != 1&& count>0) {
            int first = asteroids[count - 1];
            int second = asteroids[count - 2];

            if (Math.abs(first) == Math.abs(second)) {
                n -= 2;
				count-=2;
            }else if(first < second){

				asteroids[count-1] = 0;
				n--;
				count--;
			}
			else{
				count--;
			}
        }
		for(int i= 0;i<n;i++){
			System.out.print(asteroids[i]+" ");
		}
    }
}