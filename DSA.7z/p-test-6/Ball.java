import java.util.*;
class Ball{
	public static void main(String[] args){
		int i,n,j;
		boolean flag = false;
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the size of the array: ");
		n = scanner.nextInt();
		int[] arr1 = new int[n];
		int[] arr2 = new int[n];
		System.out.println("Enter the arr1 elements(direction)");
		for(i = 0;i<n;i++){
			arr1[i] = scanner.nextInt();
		}
		System.out.println("Enter the arr2 elements(strength)");
		for(i = 0;i<n;i++){
			arr2[i] = scanner.nextInt();
		}
		for(i = 0;i<n-1;i++){
			if(arr1[i]>0 && arr1[i+1]<0 ){
				if(arr2[i]>arr2[i+1]){
					flag = true;
					System.out.println(i);
				}
				else{
					flag = true;
					System.out.println(i+1);
				}
			}
			else if(arr1[i+1]>0 && arr1[i]<0 ){
				System.out.println(i+1);
			}
		}
		if(!flag){
			for(i=0;i<n;i++){
				System.out.println(i);
			}
		}
		
	}
}