import java.util.*;
public class Divide_string {
    public static int findSmallestConcatenatedString(String s, String t) {
        
        if (!isDivisible(s, t)) {
            return -1;
        }

        String u = findSmallestString(s, t);

        int repetitions = s.length() / u.length();

        return u.length();
    }

    private static boolean isDivisible(String s, String t) {
        return s.length() % t.length() == 0 && s.startsWith(t);
    }

    private static String findSmallestString(String s, String t) {
        int lcm = lcm(s.length(), t.length());
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < lcm / t.length(); i++) {
            sb.append(t);
        }
        return sb.toString();
    }

    private static int lcm(int a, int b) {
        return (a * b) / gcd(a, b);
    }

    private static int gcd(int a, int b) {
        while (b != 0) {
            int temp = b;
            b = a % b;
            a = temp;
        }
        return a;
    }

    public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
        String s ="";
        String t ="";
		System.out.println("Enter the String s:");
		s = scanner.next();
		System.out.println("Enter the String t:");
		t = scanner.next();
        int result = findSmallestConcatenatedString(s, t);
        System.out.println("Length of smallest string u: " + result);
    }
}
