import java.util.*;
class Cylinders{
	public static void main(String[] args){
		Scanner scanner = new Scanner(System.in);
		int n1 = scanner.nextInt();
		int n2 = scanner.nextInt();
		int n3 = scanner.nextInt();
		int h1[] = new int[n1];
		int sum1 = 0;
		int sum2 = 0;
		int sum3 = 0;
		int i;
		for(i=0; i < n1; i++){
			h1[i] = scanner.nextInt();
			sum1 += h1[i];
		}
		int h2[] = new int[n2];
		for(i=0; i < n2; i++){
			h2[i] = scanner.nextInt();
			sum2 += h2[i];
		}
		int h3[] = new int[n3];
		for(i=0; i < n3; i++){
			h3[i] = scanner.nextInt();
			sum3 += h3[i];
		}
		boolean flag = false;
		int index1 = 0;
		int index2 = 0;
		int index3 = 0;
		while(!flag){
			if((sum1 == sum2) && ( sum1 == sum3)){
				flag = true;
			}
			else{
				if(sum1 > sum2){
					if(sum1 > sum3){
						 sum1 -= h1[index1];
						 index1++;
					}else{
						 sum3 -=h3[index3];
						 index3++;
					} 
				}
				else{
					if(sum2 > sum3){
						sum2 -= h2[index2];
						index2++;
					}else{
						sum3 -= h3[index3];
						index3++;
					} 
				}
			}
		}
		System.out.println(sum1);		
	}
}