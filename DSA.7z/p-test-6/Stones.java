import java.util.*;

class Stones {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the number of stones: ");
        int n = scanner.nextInt();
        
        int[] stones = new int[n];
        System.out.println("Enter the weights of the stones: ");
        for (int i = 0; i < n; i++) {
            stones[i] = scanner.nextInt();
        }

        System.out.println("Output: " + lastStoneWeight(stones));
    }

    public static int lastStoneWeight(int[] stones) {
		Stones stone = new Stones();
		int n = stones.length;
        stone.sort(stones,0,n-1);
        while (n > 1) {
            int first = stones[n - 1];
            int second = stones[n - 2];

            if (first == second) {
                n -= 2;
            } else {
                stones[n - 2] = first - second;
                n -= 1;
                stone.sort(stones, 0, n);
            }
        }

        if(n == 0 ){
			return 0;
		}else{
			return stones[0];
		}
    }
	
	void merge(int arr[], int l, int m, int r)
    {
        int n1 = m - l + 1;
        int n2 = r - m;

        int L[] = new int[n1];
        int R[] = new int[n2];

        for (int i = 0; i < n1; ++i)
            L[i] = arr[l + i];
        for (int j = 0; j < n2; ++j)
            R[j] = arr[m + 1 + j];

        int i = 0, j = 0;

        int k = l;
        while (i < n1 && j < n2) {
            if (L[i] <= R[j]) {
                arr[k] = L[i];
                i++;
            }
            else {
                arr[k] = R[j];
                j++;
            }
            k++;
        }

        while (i < n1) {
            arr[k] = L[i];
            i++;
            k++;
        }

        while (j < n2) {
            arr[k] = R[j];
            j++;
            k++;
        }
    }

   
    void sort(int arr[], int l, int r)
    {
        if (l < r) {

            int m = l + (r - l) / 2;

            sort(arr, l, m);
            sort(arr, m + 1, r);

            merge(arr, l, m, r);
        }
    }

}
